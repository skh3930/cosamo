/*
 * CLaser.h
 *
 *  Created on: Dec 29, 2015
 *      Author: moyakk
 */

#ifndef LASERDNN_CLASER_H_
#define LASERDNN_CLASER_H_

#include "frontend_api.h"
#include "liblaserdnn2.h"

#include "ETRIPP.h"
#include "Laser.h"
#include "iconv.h"

#include "CDefineDNN.h"
#include "CConfiguration.h"

#define clen 255

using namespace std ;

class CLaser {
private:
	string s_root ;

public:
	int n_version ;
	int n_cnt ;

	char sam[clen] ;
	char sfsm[clen] ;
	char sym[clen] ;

	char adapt[clen] ;
	char prior[clen] ;
	char lda[clen] ;

	char tagging[clen] ;
	char chunking[clen] ;
	char userDic[clen] ;

	char confEPD[clen] ;
	char confDNN[clen] ;

	char sttLaser[clen] ;

	int featdim_epd ;
	int featdim_dnn ;
	int mfcc_size ;
	int miniBatch ;
	int useGPU ;
	int idGPU ;

	float priorWeight ;
	float *m_psil ;

	Laser *pLaser ;
	LFrontEnd *feEPD ;
	LFrontEnd *feDNN ;

	CConfiguration *conf ;

	CLaser(CConfiguration *in_conf);
	virtual ~CLaser();

	int getMaster() ;
	int getMaster_yn() ;
	int getChild(Laser *pMaster) ;
	int getChild_yn(Laser *pMaster) ;

	void closeMaster() ;
	void closeMaster_yn() ;
	void closeChild() ;

	int setConfig() ;
	int setConfig_yn() ;
	int setFrontEnd() ;

	int createMaster() ;
	int createPostProc() ;
	int createChild(Laser *pMaster) ;

	int getEPD(short *buf, int n_buf_len, bool b_show_epdret) ;
	string getSTT(short *buf, int n_buf_len) ;
	string getSTT_yn(short *buf, int n_buf_len) ;

	void RemoveSpecialChar(char* pIn, char* pOut) ;
	void resetFrontEndEPD() ;
};

#endif /* LASERDNN_CLASER_H_ */
