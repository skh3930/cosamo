/*
 * CFILE.h
 *
 *  Created on: 2016. 7. 26.
 *      Author: cosamo01
 */

#ifndef INCLUDE_CFILE_H_
#define INCLUDE_CFILE_H_

#include <CSG.h>
#include <stdio.h>

#include "CSGUTIL.h"
#include "CBuffer.h"

class CFile {
private:
	string c_date;
	int n_file_cnt;

public:
	CFile(){
		c_date =  FN::yyyymmdd(0);
		n_file_cnt = 0;
	}
	virtual ~CFile(){
	}

	string savefile(CBuffer *p_voice){
		//파일명 설정
		string t_date = FN::yyyymmdd(0);
		if (!FN::equal(c_date, t_date)){
			c_date = t_date;
			n_file_cnt = 0 ;
		}

		string s_file_cnt = FN::itos(n_file_cnt);
		string s_pcm_path = SG::conf()->g_record.s_pcm_path ;
		string s_pcm_key  = FN::yyyymmddhhmmsss(0)+ "_" + s_file_cnt;
		string s_pcm_name = s_pcm_key + ".pcm" ;
		string s_pcm = s_pcm_path + s_pcm_name ;
		FN::checkDIR(s_pcm_path) ;
		FILE *fp = fopen(s_pcm.c_str(), "w+") ;
		for (int i=0; i< p_voice->size(); i++) {
			fwrite((((unsigned char *)p_voice->buf+i)), sizeof(unsigned char), 1, fp) ;
		}
		fflush(fp) ;
		fclose(fp) ;

		////	CONVERT PCM to WAV
		if (SG::conf()->g_record.b_wav) {
			string s_cmd = "" ;

			s_cmd = "" ;
			s_cmd += (" ffmpeg -nostats -loglevel 0 ") ;
			s_cmd += (" -f s16le -ar 8000 ") ;
			s_cmd += (" -i "+s_pcm_path+ s_pcm_key +".pcm ") ;
			s_cmd += (" -b:a 128k -ar 8000 "+s_pcm_path+ s_pcm_key +".wav ") ;
			printf(" PCM to WAV : %s", s_cmd.c_str()) ;
			try {
				int cmd_ret = FN::runCommand(s_cmd.c_str()) ;
				sgprintf(DEBUG, "CFile::savefile() - Convert PCM to WAV - %d \n", cmd_ret) ;
			} catch (exception & e) {
				sgprintf(ERROR, "CFile::savefile() - Fail to Convert PCM to WAV - %s \n", s_cmd.c_str()) ;
			}
		}

		return s_pcm_key+".wav" ;
	}
};

#endif /* INCLUDE_CFILE_H_ */
