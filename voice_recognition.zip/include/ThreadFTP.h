/*
 * ThreadFTP.h
 *
 *  Created on: 2016. 7. 27.
 *      Author: cosamo01
 */

#ifndef INCLUDE_THREADFTP_H_
#define INCLUDE_THREADFTP_H_

#include <sys/socket.h>
#include <arpa/inet.h>

#include "CSG.h"
#include "CLog.h"
#include "CSGUTIL.h"
#include <CBuffer.h>
#include <CThread.h>
#include <CLaserManager.h>

using namespace std ;

class ThreadFTP : public CThread {

private:
	bool b_run ;

	int n_udp_port ;
	int n_clnt_no ;
	int sock ;
	CBuffer *p_voice ;
	bool b_stt_flag;
	unsigned char *p_frame ;

	CLaser *p_child ;

public:
	ThreadFTP(int _tid, int _clnt_no ,int _udp_port) :
		CThread(_tid) {
		sgprintf(DEBUG, "ThreadFTP::ThreadFTP(%d) - Create", tid());
		b_run = true ;
		p_voice = NULL ;
		p_frame = NULL ;
		p_child = NULL ;
		b_stt_flag = false;
		sock = 0 ;
		n_udp_port = _udp_port ;
		n_clnt_no = _clnt_no ;
	}
	virtual ~ThreadFTP() {
		b_run = false;
		sgprintf(DEBUG, "ThreadFTP::~ThreadFTP(%d) - Destroy", tid());

		while(b_stt_flag){
			usleep(1000);
		}

		if(p_child != NULL)
			SG::getLaserManager()->push(p_child);
		if(p_frame)
			delete p_frame ;
		if(p_voice)
			delete p_voice ;
		close(sock);
	}
	virtual void* run() {
		sgprintf(DEBUG, "ThreadFTP::run(%d)", tid());
		this->work();
		return reinterpret_cast<void *>(tid());
	}
	void work();
};

#endif /* INCLUDE_THREADFTP_H_ */
