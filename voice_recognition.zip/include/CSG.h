/*
 * CGlobal.h
 *
 *  Created on: Apr 21, 2016
 *      Author: moyakk
 */

#ifndef INCLUDE_CSG_H_
#define INCLUDE_CSG_H_

#include <iostream>
using namespace std ;

enum LOG_TYPE {INFO, DEBUG, ERROR} ;
enum LOG_LEVEL {LOG_NEVER, LOG_STDOUT, LOG_FILE, LOG_ALL} ;

////////////////////////////////////////////////////////////
////
////	Forward Declarations
////

class CConfiguration ;
class CLog ;
class CLaserManager ;
class CSessionManager ;
class CFile ;

class SG {

private :
	static CConfiguration *p_conf ;
	static CLog *p_sgout ;
	static CLaserManager *p_laser_manager ;
	static CSessionManager *p_session_manager ;
	static CFile *p_file ;
public :
	static CConfiguration *conf() ;
	static CLog* getsgout() ;
	static CLaserManager *getLaserManager() ;
	static CSessionManager *getSessionManager() ;
	static CFile *getCFile() ;
} ;

#endif /* INCLUDE_CSG_H_ */
