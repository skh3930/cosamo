/*
 * ThreadQueue.h
 *
 *  Created on: Oct 1, 2015
 *      Author: solugate
 */

#ifndef THREADQUEUE_H_
#define THREADQUEUE_H_

#include <pthread.h>
#include <list>

using namespace std ;

template <typename T> class ThreadQueue {

private :
	int n_size ;
	list<T> m_queue ;
	pthread_mutex_t	m_mutex ;
	pthread_cond_t	m_condv ;

public :

	ThreadQueue() {
		n_size = 0 ;
		pthread_mutex_init(&m_mutex, NULL) ;
		pthread_cond_init(&m_condv, NULL) ;
	}
	~ThreadQueue() {
		// TODO clear m_queue manually !
		pthread_mutex_destroy(&m_mutex) ;
		pthread_cond_destroy(&m_condv) ;
	}

	void add(T item) {
		pthread_mutex_lock(&m_mutex) ;
		m_queue.push_back(item) ;
		n_size++ ;
		pthread_cond_signal(&m_condv) ;
		pthread_mutex_unlock(&m_mutex) ;
	}

	T remove() {
		pthread_mutex_lock(&m_mutex) ;
		while (m_queue.size() == 0) {
			pthread_cond_wait(&m_condv, &m_mutex) ;
		}
		T item = m_queue.front() ;
		m_queue.pop_front() ;
		n_size-- ;
		pthread_mutex_unlock(&m_mutex) ;
		return item ;
	}

	void remove(T item) {
		pthread_mutex_lock(&m_mutex) ;
		while (m_queue.size() == 0) {
			pthread_cond_wait(&m_condv, &m_mutex) ;
		}
		m_queue.remove(item) ;
		n_size-- ;
		pthread_mutex_unlock(&m_mutex) ;
	}

	void removeAt(int num) {
		pthread_mutex_lock(&m_mutex);
		while (m_queue.size() == 0) {
			pthread_cond_wait(&m_condv, &m_mutex);
		}
		int n_num = 0;
		for (typename list<T>::iterator i_list = m_queue.begin(); i_list != m_queue.end(); i_list++) {
			if (n_num == num) {
				i_list = m_queue.erase(i_list) ;
				n_size-- ;
			}
			n_num++;
		}
		pthread_mutex_unlock(&m_mutex);
	}

	T get() {
		pthread_mutex_lock(&m_mutex);
		while (m_queue.size() == 0) {
			pthread_cond_wait(&m_condv, &m_mutex);
		}
		T item = m_queue.front();
		pthread_mutex_unlock(&m_mutex);
		return item;
	}

	T getAt(int num) {
		pthread_mutex_lock(&m_mutex);
		while (m_queue.size() == 0) {
			pthread_cond_wait(&m_condv, &m_mutex);
		}
		T item ;
		int n_num = 0;
		for (typename list<T>::iterator i_list = m_queue.begin(); i_list != m_queue.end(); i_list++) {
			if (n_num == num) {
				item = *i_list ;
			}
			n_num++;
		}
		pthread_mutex_unlock(&m_mutex);
		return item;
	}

	int size() {
		// pthread_mutex_lock(&m_mutex);
		// n_size = m_queue.size() ;
		// pthread_mutex_unlock(&m_mutex);
		return n_size;
	}
};

#endif /* THREADQUEUE_H_ */
