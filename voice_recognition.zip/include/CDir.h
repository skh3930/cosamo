/*
 * CDir.h
 *
 *  Created on: Apr 19, 2016
 *      Author: moyakk
 */

#ifndef INCLUDE_CDIR_H_
#define INCLUDE_CDIR_H_

#ifndef IGUN
#define IGUN __attribute__ ((unused)) // ignore unused variable warning
#endif

#include <stdio.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>

#include <CLog.h>

using namespace std ;

static bool isDirectory(string s_path) {
	bool b_ret = false ;
	struct stat sb ;
	if (stat(s_path.c_str(), &sb) == 0) {
		if (S_ISDIR(sb.st_mode)) {
			b_ret = true ;
		} else {
			b_ret = false ;
		}
	} else {
		b_ret = false ;
	}
	return b_ret ;
}

IGUN static bool isFile(string s_path) {
	bool b_ret = false ;
	struct stat sb ;
	if (stat(s_path.c_str(), &sb) == 0) {
		if (S_ISREG(sb.st_mode)) {
			b_ret = true ;
		} else {
			b_ret = false ;
		}
	} else {
		b_ret = false ;
	}
	return b_ret ;
}

static bool isExists(string s_path) {
	bool b_ret = false ;
	if (access(s_path.c_str(), F_OK) == 0) {
		// sgprintf(DEBUG, "CDir::isExists() - File Exists- OK %s\n", s_path.c_str()) ;
		b_ret = true ;
	} else {
		sgprintf(ERROR, "CDir::isExists() - File Exists- Fail .. %s\n", s_path.c_str()) ;
		b_ret = false ;
	}
	return b_ret ;
}

IGUN static bool canWrite(string s_path) {
	bool b_ret = false ;
	if (isExists(s_path)) {
		if (access(s_path.c_str(), W_OK) == 0) {
			// sgprintf(DEBUG, "CDir::canWrite() - File Can Write - OK %s\n", s_path.c_str()) ;
			b_ret = true ;
		} else {
			sgprintf(ERROR, "CDir::canWrite() - File Can't Write %s\n", s_path.c_str()) ;
			b_ret = false ;
		}
	}
	return b_ret ;
}

IGUN static bool canRead(string s_path) {
	bool b_ret = false ;
	if (isExists(s_path)) {
		if (access(s_path.c_str(), R_OK) == 0) {
			// sgprintf(DEBUG, "CDir::canRead() - File Can Read - OK %s\n", s_path.c_str()) ;
			b_ret = true ;
		} else {
			sgprintf(ERROR, "CDir::canRead() - File Can't Read %s\n", s_path.c_str()) ;
			b_ret = false ;
		}
	}
	return b_ret ;
}

IGUN static bool fnRemove(string s_path) {
	bool b_ret = false ;
	int n_ret = remove(s_path.c_str()) ;
	if (n_ret < 0) {
		b_ret = false ;
	} else {
		b_ret = true ;
	}
	return b_ret ;
}

IGUN static bool checkPath(string s_path) {
	bool b_ret = false ;
	string sep = "/" ;
	string t_path = "/" ;
	int n_path_len = (s_path.length() + 2) ;
	char *p_path = new char[n_path_len] ;
	memset(p_path, 0x00, n_path_len) ;
	memcpy(p_path, s_path.c_str(), s_path.length()) ;
	char *p_myPath = strtok(p_path, (char *)sep.c_str()) ; // Splie
	while (p_myPath != NULL) {
		t_path += (p_myPath + sep) ;
		if (!isExists(t_path)) {
			sgprintf(DEBUG, "CDir::checkPath() - mkdir (%s)", t_path.c_str()) ;
			mkdir((char *)t_path.c_str(), 0700) ;
		} else {
			if (!isDirectory(t_path)) {
				sgprintf(DEBUG, "CDir::checkPath() - (%s) is a file", t_path.c_str()) ;
				break ;
			}
		}
		p_myPath = strtok(NULL, (char *)sep.c_str()) ;
	}
	if (isExists(s_path)) {
		b_ret = true ;
	}
	return b_ret ;
}

class CDir {

private :
	DIR *dir ;
	string path ;

public :
	CDir(string _path) {
		path = _path ;
		dir = NULL ;
		if (_path.length() > 0) {
			open() ;
		}
	}
	~CDir() {
		close() ;
	}

	void open() {
		if (!dir) {
			dir = opendir((char *)path.c_str()) ;
			if (dir) {
				sgprintf(INFO, "CDir::open() - success to open (%s)\n", path.c_str()) ;
			} else {
				sgprintf(ERROR, "CDir::open() - fail to open (%s)", path.c_str()) ;
			}
		}
	}

	void close() {
		if (dir) {
			closedir(dir) ;
			dir = NULL ;
		}
	}

	dirent *read() {
		dirent *pdir = NULL ;
		if (dir) {
			pdir = readdir(dir) ;
		}
		return pdir ;
	}

	bool isExtension(string s_name, string s_extension) {
		bool b_ret = false ;
		string s_file = s_name ;
		string s_ext = s_extension ;
		s_file = FN::tolower(s_file) ;
		s_ext = FN::tolower(s_ext) ;
		if (!FN::equal(s_ext.substr(0, 1), ".")) {
			s_ext = ("."+s_ext) ;
		}
		int n_pos = s_file.rfind(s_ext) ;
		if (n_pos > 0 && (n_pos == (int)s_file.find_last_of('.'))) {
			b_ret = true ;
		}
		return b_ret ;
	}

	int dateFromName(string s_name, string s_type) {
		int n_date = -1 ;
		if (FN::equal(s_type, "yyyymmdd")) {
			n_date = FN::stoi(s_name.substr(0, 8)) ;
		} else if (FN::equal(s_type, "yymmdd")) {
			n_date = FN::stoi(s_name.substr(0, 6)) ;
		}
		return n_date ;
	}
} ;

#endif /* INCLUDE_CDIR_H_ */
