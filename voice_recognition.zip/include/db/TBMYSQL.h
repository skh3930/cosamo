/*
 * TBMYSQL.h
 *
 *  Created on: Dec 29, 2015
 *      Author: moyakk
 */

#ifndef TBMYSQL_H_
#define TBMYSQL_H_

#include <CSG.h>
#include <CSGUTIL.h>
#include <iostream>
#include <stdio.h>
#include <unistd.h>
#include <mysql.h>
#include <string.h>

#define INT 1
#define STR 2

#define V2S(name) ({string s_name; s_name=#name;})

using namespace std ;

class TBMYSQL {
protected:
	int getRows(MYSQL_RES* mRS) ;
	int getCols(MYSQL_RES* mRS) ;
public:
	TBMYSQL();
	virtual ~TBMYSQL();

	string num(string s_input, int n_comma) ;
	string str(string s_input, int n_comma) ;
};

#endif /* TBMYSQL_H_ */
