/*
 * TBMYSQL.cpp
 *
 *  Created on: Dec 29, 2015
 *      Author: moyakk
 */

#include <db/TBMYSQL.h>

TBMYSQL::TBMYSQL() {
	//
}

TBMYSQL::~TBMYSQL() {
	//
}

int TBMYSQL::getRows(MYSQL_RES* mRS) {
	int n_ret = 0;
	try {
		n_ret = mysql_num_rows(mRS);
	} catch (exception &e) {
		printf("[T] GetRows error : %s \n", e.what());
		n_ret = 0;
	}
	return n_ret;
}

int TBMYSQL::getCols(MYSQL_RES* mRS) {
	int n_ret = 0;
	try {
		n_ret = mysql_num_fields(mRS);
	} catch (exception &e) {
		printf("[MYSQL] GetCols error : %s \n", e.what());
		n_ret = 0;
	}
	return n_ret;
}

string TBMYSQL::num(string s_input, int n_comma) {
	string s_output = s_input ;
	if (n_comma > 0) s_output = (", "+s_output) ;
	return s_output ;
}

string TBMYSQL::str(string s_input, int n_comma) {
	string s_output = "'"+s_input+"'" ;
	if (n_comma > 0) s_output = (", "+s_output) ;
	return s_output ;
}
