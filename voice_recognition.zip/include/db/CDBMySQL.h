/*
 * CDBMySQL.h
 *
 *  Created on: Sep 25, 2015
 *      Author: solugate
 */

#ifndef CDBMYSQL_H_
#define CDBMYSQL_H_

#include <iostream>
#include <stdio.h>
#include <unistd.h>
#include <mysql.h>
#include <pthread.h>

#include <CSG.h>
#include <CSGUTIL.h>
#include <CLog.h>
#include <CConfiguration.h>

using namespace std;

typedef struct _MYSQL_INFO {
	string s_ip;
	int n_port;
	string s_name;
	string s_id;
	string s_pw;
} MYSQL_INFO;

class CDBMySQL {

private:
	bool b_set ;
	pthread_mutex_t m_mutex ;

public:
	CDBMySQL() {
		pthread_mutex_init(&m_mutex, NULL) ;
		mConnection = NULL ;
		b_set = false ;
	}
	~CDBMySQL() {
		pthread_mutex_destroy(&m_mutex) ;
		while (true) {
			if (fnDisConnection()) {
				break ;
			}
		}
	}

	MYSQL_INFO conn_info;

	MYSQL *mConnection;
	MYSQL conn;

	void fnSetConnectionInfo();
	void fnSetConnectionInfo(CConfiguration *conf);
	void fnSetConnectionInfo(string s_ip, int n_port, string s_name, string s_id, string s_pw);
	bool fnGetConnection();
	bool fnDisConnection();

	MYSQL_RES* fnGetResultSet(string s_query);
	long fnGetRows(MYSQL_RES* mRS);
	int fnGetCols(MYSQL_RES* mRS);
	MYSQL_FIELD* fnGetFields(MYSQL_RES* mRS);

	bool fnExeQuery(string s_query);
};

#endif /* CDBMYSQL_H_ */
