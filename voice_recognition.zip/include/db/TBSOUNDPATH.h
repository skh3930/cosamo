/*
 * TBSOUNDPATH.h
 *
 *  Created on: jul 20, 2016
 *      Author: suhyun
 */

#ifndef INCLUDE_DB_TBSOUNDPATH_H_
#define INCLUDE_DB_TBSOUNDPATH_H_

#include <TBMYSQL.h>

class TBSOUNDPATH : public TBMYSQL {
public:
	string SP_TABLE ;
	string SP_NO ;
	string SP_FLAG ;
	string SP_PATH ;
	string SP_TIME ;

	TBSOUNDPATH();
	virtual ~TBSOUNDPATH();

	void getData(MYSQL_RES *mRS) ;
};

#endif /* INCLUDE_DB_TBESOUNDPATH_H_ */
