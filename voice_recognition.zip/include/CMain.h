/*
 * CMain.h
 *
 *  Created on: Apr 18, 2016
 *      Author: moyakk
 */

#ifndef INCLUDE_CMAIN_H_
#define INCLUDE_CMAIN_H_

#include <CSG.h>
#include <CSGUTIL.h>
#include <CThread.h>
#include <CDBMySQL.h>
#include <CLaserManager.h>
#include <ThreadManager.h>
#include <TBSOUNDPATH.h>

class CMain : public CThread {

private:
	bool b_run ;
	int n_status ;
	string s_date ;

	CDBMySQL *p_db ;

	CConfiguration *p_conf ;
	CLaserManager *p_dnnman ;
	ThreadManager *p_manager ;

private:
	void work() ;
	void workPrepare() ;
	void workRealtime() ;
	void workDaily(string t_date) ;

public:
	CMain(int _tid) : CThread(_tid) {
		sgprintf(DEBUG, "CSGMain::CSGMain(%d) - Create", tid()) ;
		b_run = true ;
		n_status = 0 ;
		s_date = FN::yyyymmdd(1) ;
		p_db = NULL ;
		p_conf = NULL ;
		p_dnnman = NULL ;
		p_manager = NULL ;
	}
	virtual ~CMain() {
		sgprintf(DEBUG, "CSGMain::~CSGMain(%d) - Destroy", tid()) ;
		b_run = false ;
		if (p_db) { delete p_db ; p_db = NULL ; }
		if (p_dnnman) { delete p_dnnman ; p_dnnman = NULL ; }
		if (p_conf) { delete p_conf ; p_conf = NULL ; }
		if (p_manager) { delete p_manager ; p_manager = NULL ; }
	}
	virtual void *run() {
		this->workPrepare() ;
		this->work() ;
		return reinterpret_cast<void *>(tid()) ;
	}
	void stop() {
		b_run = false ;
	}
	bool isRun() {
		return b_run ;
	}
} ;

#endif /* INCLUDE_CMAIN_H_ */
