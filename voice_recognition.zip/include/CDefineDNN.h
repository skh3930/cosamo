/*
 * CDefineDNN.h
 *
 *  Created on: Dec 24, 2015
 *      Author: moyakk
 */

#ifndef COMMON_CDEFINEDNN_H_
#define COMMON_CDEFINEDNN_H_

#define d_laser	"conf/stt_laser.cfg"
#define d_feEPD "conf/frontend_53.cfg"
#define d_feDNN "conf/frontend_dnn.cfg"

// Laser
#define	d_sam	"stt_images_dnn/stt_release.sam.bin"
#define	d_sfsm	"stt_images_dnn/stt_release.sfsm.bin"
#define	d_sym	"stt_images_dnn/stt_release.sym.bin"
// DNN
#define d_adapt	"stt_images_dnn/final.dnn.adapt"
#define	d_prior	"stt_images_dnn/final.dnn.prior.bin"
#define	d_lda	"stt_images_dnn/final.dnn.lda.bin"
//
#define	d_tagging	"stt_images_dnn/tagging.release.bin"
#define	d_chunking	"stt_images_dnn/chunking.release.bin"
#define	d_userDic	"stt_images_dnn/user_dic.txt"
//
#define NUM_CORES				1
#define MAX_MINIBATCH		1024
//

#endif /* COMMON_CDEFINEDNN_H_ */
