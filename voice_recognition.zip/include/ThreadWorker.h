/*
 * ThreadWorker.h
 *
 *  Created on: 2016. 7. 13.
 *      Author: moyakk
 */

#ifndef THREADWORKER_H_
#define THREADWORKER_H_

#include <CLaser.h>
#include <stdio.h>
#include <stdlib.h>

#include "CSGUTIL.h"
#include "CLog.h"
#include "CThreadQueue.h"
#include "CBuffer.h"
#include "ThreadFTP.h"

class ThreadWorker : public CThreadQueue {

private :
	bool b_run ;

	int n_clnt_no;
	int n_udp_port ;
	ThreadFTP *p_threadFTP ;

public:
	ThreadWorker(int _tid, int _clnt_no, int _udp_port, ThreadQueue<CThreadQueue *> &_threadq) : CThreadQueue(_tid, _threadq) {
		p_threadFTP = NULL;
		b_run = true ;
		n_clnt_no = _clnt_no;
		n_udp_port = _udp_port ;

		sgprintf(DEBUG, "ThreadWorker::ThreadWorker(tid : %d, client NO : %d) - Create", tid(), n_clnt_no) ;
	}
	virtual ~ThreadWorker() {
		sgprintf(DEBUG, "ThreadWorker::~ThreadWorker(%d) - Destroy", tid()) ;

		if(p_threadFTP != NULL){
			delete p_threadFTP ;
		}
		b_run = false ;

		stop() ;
	}
	virtual void* run() {
		sgprintf(DEBUG, "ThreadWorker::run(%d)", tid()) ;
		threadq.add(this) ;
		this->work() ;
		b_on = false ;
		return reinterpret_cast<void *>(tid()) ;
	}
	void stop() ;
	void work() ;
} ;

#endif /* THREADWORKER_H_ */
