/*
 * CThread.h
 *
 *  Created on: Dec 23, 2015
 *      Author: moyakk
 */

#ifndef CTHREAD_H_
#define CTHREAD_H_

#include <Thread.h>
#include <ThreadQueue.h>
#include <iostream>

using namespace std ;

class CThread : public Thread {

protected:
	int n_tid ;
	string s_name ;

public:
	CThread(int in_tid) {
		n_tid = in_tid ;
	} ;
	virtual ~CThread() {
		//
	}
	virtual void *run() {
		return reinterpret_cast<void *>(n_tid) ;
	}
	int tid() {
		return n_tid ;
	}
} ;

#endif /* CTHREAD_H_ */
