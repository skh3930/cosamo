/*
 * CLaserManager.h
 *
 *  Created on: Apr 20, 2016
 *      Author: moyakk
 */

#ifndef INCLUDE_CLASERMANAGER_H_
#define INCLUDE_CLASERMANAGER_H_

#include <pthread.h>
#include <ThreadQueue.h>

#include <CSG.h>
#include <CSGUTIL.h>
#include <CLog.h>
#include <CLaser.h>

class CLaserManager {

private :
	bool b_run ;
	int n_foreground ;
	int n_background ;

	CLaser *p_master[2] ;
	CLaser *p_master_yn ;

	ThreadQueue<CLaser*> childq ;
	pthread_mutex_t mutex ;

	void swapMaster() ;

public :
	CLaserManager() {
		pthread_mutex_init(&mutex, NULL) ;
		b_run = true ;
		p_master[0] = NULL ;
		p_master[1] = NULL ;
		p_master_yn = NULL ;
		n_foreground = 0 ;
		n_background = 1 ;
	}
	~CLaserManager() {
		pthread_mutex_destroy(&mutex) ;
		b_run = false ;
		closeChild() ;
		closeMaster() ;
	}
	void createMaster() ;
	void closeChild() ;
	void closeMaster() ;
	void closeMaster(int n_idx) ;
	void push(CLaser *p_child) ;
	CLaser *pop() ;
	CLaser *getChild_yn() {
		CLaser *pLaser_yn = new CLaser(SG::conf()) ;
		if ((pLaser_yn->getChild_yn(p_master_yn->pLaser)) < 0) {
			sgprintf(ERROR, " = laser.yn.c - fail to create child laser ..") ;
		} else {
			sgprintf(INFO, " = laser.yn.c - ready !") ;
		}
		return pLaser_yn ;
	}
} ;

#endif /* INCLUDE_CLASERMANAGER_H_ */
