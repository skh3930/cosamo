/*
 * ThreadManager.h
 *
 *  Created on: 2016. 7. 13.
 *      Author: moyakk
 */

#ifndef THREADMANAGER_H_
#define THREADMANAGER_H_

#include <CLog.h>
#include <CThread.h>
#include <CThreadQueue.h>
#include <CDBMySQL.h>
#include <CSG.h>
#include <CSGUTIL.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

#include <ThreadWorker.h>

class ThreadManager: public CThread {

private:
	bool b_run;
	int  n_tid_max;

	struct sockaddr_in serv_addr;
	struct sockaddr_in clnt_addr;
	int clnt_addr_size;

	int n_queue_max ;	//최대 접속 가능한 클라이언트 수

	CLog *p_log;
	CDBMySQL *p_db;

	ThreadQueue<CThreadQueue*> threadq;

public:
	ThreadManager(int _tid) :
		CThread(_tid) {
		sgprintf(DEBUG, "ThreadManager::ThreadManager(%d) - Create", tid());
		b_run = true;
		p_log = new CLog("ICS", SG::conf()->g_module.s_root);
		p_db = new CDBMySQL();

		n_tid_max = 100000;
		n_queue_max = SG::conf()->g_laser.n_channel;

		clnt_addr_size = 0;
	}
	virtual ~ThreadManager() {
		sgprintf(DEBUG, "ThreadManager::~ThreadManager(%d) - Destroy", tid());
		b_run = false;
		if (p_log) {
			delete p_log;
			p_log = NULL;
		}
		if (p_db) {
			delete p_db;
			p_db = NULL;
		}

	}
	virtual void* run() {
		sgprintf(DEBUG, "ThreadManager::run(%d)", tid());
		this->work();
		return reinterpret_cast<void *>(tid());
	}
	void work();
	bool pop();
};

#endif /* THREADMANAGER_H_ */
