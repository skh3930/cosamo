/*
 * CTime.h
 *
 *  Created on: Dec 22, 2015
 *      Author: moyakk
 */

#ifndef INCLUDE_CTIME_H_
#define INCLUDE_CTIME_H_

#include <iostream>
#include <cstdio>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>

class CTime {

public:
	timeval s_time ;
	timeval e_time ;

	CTime() {
		//
	}
	~CTime() {
		//
	}

	void swSTART() {
		gettimeofday(&s_time, NULL) ;
	}

	void swEND() {
		gettimeofday(&e_time, NULL) ;
	}

	bool swOK() {
		if (e_time.tv_sec > s_time.tv_sec) {
			if (e_time.tv_usec > s_time.tv_usec) {
				return true ;
			}
		}
		return false ;
	}

	timeval swGAP() {
		timeval in_time ;
		in_time.tv_sec = e_time.tv_sec - s_time.tv_sec ;
		in_time.tv_usec = e_time.tv_usec - s_time.tv_usec ;

		if (in_time.tv_usec < 0) {
			in_time.tv_usec = (1 - in_time.tv_usec) ;
			in_time.tv_sec-- ;
		}
		if (in_time.tv_sec < 0) {
			in_time.tv_sec *= -1 ;
		}
		if (in_time.tv_usec < 0) {
			in_time.tv_usec *= -1 ;
		}
		return in_time ;
	}
} ;

#endif /* INCLUDE_CTIME_H_ */
