/*
 * CSystemResource.h
 *
 *  Created on: 2016. 5. 11.
 *      Author: moyakk
 */

#ifndef SRC_CSYSTEMRESOURCE_H_
#define SRC_CSYSTEMRESOURCE_H_

#include <stdio.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <errno.h>

using namespace std ;

////////////////////////////////////////////////////////////

void getSystemResource(int n_type) {
	struct rusage rusage ;
	if (getrusage(n_type, &rusage) == -1) {
		printf("getrusage(%d) ", n_type) ;
		perror("error : ") ;
		return ;
	} else {
		printf(" . Maximum resident set size : %ld (in kilobytes) \n", rusage.ru_maxrss) ;
		printf(" . integral shared memory size : %ld (kilobyte-seconds) \n", rusage.ru_ixrss) ;
		printf(" . integral unshared data size : %ld (kilobyte-seconds) \n", rusage.ru_idrss) ;
		printf(" . integral unshared stack size : %ld (kilobyte-seconds) \n", rusage.ru_isrss) ;
	}
}

void fnSystemResource() {
	printf(" = Usage of Self \n") ;
	getSystemResource(RUSAGE_SELF) ;
	printf(" = Usage of Children \n") ;
	getSystemResource(RUSAGE_CHILDREN) ;
	printf(" = Usage of Thread \n") ;
	getSystemResource(RUSAGE_THREAD) ;
}

////////////////////////////////////////////////////////////

int getSystemConfig(const char* msg, int n_type) {
	struct rlimit rlim ;
	if (getrlimit(n_type, &rlim) == -1) {
		printf("getrlimit(%d) ", n_type) ;
		perror("error : ") ;
		return -1 ;
	} else {
		if (rlim.rlim_max == RLIM_INFINITY) {
			printf(" = %-15s (Current/Max) : %d / unlimited \n", msg, (int)rlim.rlim_cur) ;
		} else {
			printf(" = %-15s (Current/Max) : %d / %d \n", msg, (int)rlim.rlim_cur, (int)rlim.rlim_max) ;
		}
		return 1 ;
	}
}

int setSystemConfig(int n_type, long int n_cur, long int n_max) {
	struct rlimit rlim ;
	if (getrlimit(RLIMIT_STACK, &rlim) == -1) {
		printf("getrlimit(%d) ", n_type) ;
		perror("error : ") ;
		return -1 ;
	} else {
		bool b_set = false ;
		if ((int)n_cur > 0 && (int)rlim.rlim_cur < n_cur) {
			rlim.rlim_cur = n_cur ;
			b_set = true ;
		}
		if ((int)n_max > 0 && (int)rlim.rlim_max < n_max && rlim.rlim_max != RLIM_INFINITY) {
			rlim.rlim_max = n_max ;
			b_set = true ;
		}
		if (b_set) {
			if (setrlimit(RLIMIT_STACK, &rlim) == -1) {
				printf("setrlimit(%d) ", n_type) ;
				perror("error : ") ;
				return -2 ;
			} else {
				return 1 ;
			}
		} else {
			return 0 ;
		}
	}
}

void fnSystemConfig() {
	getSystemConfig("Processes", RLIMIT_NPROC) ;
	getSystemConfig("Open Files", RLIMIT_NOFILE) ;
	getSystemConfig("Stack Size", RLIMIT_STACK) ;
	long int n_cur = (1024 * 1024 * 10) ; // 10 Mb
	if (setSystemConfig(RLIMIT_STACK, n_cur, -1) > 0) {
		getSystemConfig("Stack Size", RLIMIT_STACK) ;
	}
}

////////////////////////////////////////////////////////////

#endif /* SRC_CSYSTEMRESOURCE_H_ */
