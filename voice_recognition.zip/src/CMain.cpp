/*
 * CMain.cpp
 *
 *  Created on: jul 20, 2016
 *      Author: suhyun
 */

#include <CMain.h>
#include <TBENGVER.h>

void CMain::work() {
	//얼마 간격으로 쉴건지 conf파일에서 가져옴
	int n_interval = SG::conf()->g_module.n_interval;

	//처음에만 매니저를 만듬
	if (p_manager == NULL) {
		p_manager = new ThreadManager(1);
		p_manager->start();
	}

	//현재 자신 thread가 계속 run 상태라면 계속해서 반복
	while (b_run) {
		this->workRealtime();
		//서버가 살아있는지 확인 시키기 위해서 계속해서 값을 더하고 업데이트
		n_status += n_interval;
		sleep(50);
	}
}

void CMain::workPrepare() {

	////	Prepare Static Instance
	//초기에 conf파일을 가져옴
	if (p_conf == NULL) {
		p_conf = SG::conf();
	}

	//db를 연결함
	if (p_db == NULL) {
		p_db = new CDBMySQL();
		p_db->fnGetConnection();
	}

	////	DB | Get Server Config.
	string s_query = "";
	if (p_db) {
		s_query += (" SELECT * ");
		s_query += (" FROM TB_ENG_VER ");
		s_query += (" WHERE (1=1)");
		s_query += (" AND E_USEYN = 1 ");
		s_query += (" LIMIT 0, 1 ");
		s_query += (" ; ");
		MYSQL_RES* mRS = p_db->fnGetResultSet(s_query);
		if (mRS) {
			if (p_db->fnGetRows(mRS) > 0) {
				TBENGVER *tb = new TBENGVER();
				tb->getData(mRS);
				if (tb->E_VERSION.length() > 0
						&& !FN::equal(tb->E_VERSION, "NULL")) {
					sgprintf(INFO,
							"Load Configuration from DB - Override STT Image Version - %s",
							tb->E_VERSION.c_str());
					SG::conf()->g_laser.n_version = FN::stoi(tb->E_VERSION);
				}
				if (tb->E_FILE_PATH.length() > 0
						&& !FN::equal(tb->E_FILE_PATH, "NULL")) {
					sgprintf(INFO, "Load Configuration from DB - Override STT Binary File Path - %s", tb->E_FILE_PATH.c_str());
					SG::conf()->g_laser.s_target = ("/" + tb->E_FILE_PATH + "/");
				}
				delete tb;
				tb = NULL;
			}
		}
		mysql_free_result(mRS);
		mRS = NULL;
	}

	s_query = "";
	if (p_db) {
		s_query += (" SELECT * ");
		s_query += (" FROM TB_SOUND_PATH ");
		s_query += (" WHERE (1=1)");
		s_query += (" AND sp_flag = 1 ");
		s_query += (" LIMIT 0, 1 ");
		s_query += (" ; ");
		MYSQL_RES* mRS = p_db->fnGetResultSet(s_query);
		if (mRS) {
			if (p_db->fnGetRows(mRS) > 0) {
				TBSOUNDPATH *tb = new TBSOUNDPATH();
				tb->getData(mRS);
				if (tb->SP_PATH.length() > 0 && !FN::equal(tb->SP_PATH, "NULL")) {
					sgprintf(INFO, "Load result path from DB - Override result path - %s", tb->SP_PATH.c_str());

					string s_find = "/icanspeak" ;
					string s_root = "/home/cosamo01/" ;
					string s_input = tb->SP_PATH ;
					int n_pos = -1 ;
					if ((n_pos = s_input.find(s_find)) != (signed int)s_input.npos) {
						s_input = s_root + s_input.substr(n_pos) ;
					}
					SG::conf()->g_record.s_wav_path = s_input;
					SG::conf()->g_record.s_pcm_path = s_input;
				}
				delete tb;
				tb = NULL;
			}
		}
		mysql_free_result(mRS);
		mRS = NULL;
	}

	if (p_dnnman == NULL) {
		p_dnnman = SG::getLaserManager();
	}
}

void CMain::workRealtime() {

	////	Check Date Change

	string t_date = FN::yyyymmdd(1);
	if (!FN::equal(s_date, t_date)) {
		this->workDaily(t_date);
		s_date = t_date;
	}

	////	Update Server Status 서버 상태를 계속 +5씩 추가함. 서버가 죽지않고 살아있다는 것을 알림.

	if (p_db) {
		sgprintf(DEBUG,
				"CMain::workRealtime() - Update Server Module Status - %d",
				n_status);
		string s_query = "";
		s_query += (" UPDATE TB_SVR_CON ");
		s_query += (" SET SC_STATUS = " + FN::itos(n_status) + " ");
		s_query += (" WHERE (1=1) ");
		s_query +=  (" AND SC_USEYN = 1 ");
		s_query += (" ; ");
		p_db->fnExeQuery(s_query);
	}

}

void CMain::workDaily(string t_date) {
	////
	////	Find New Engine Config. 새로운 엔진 버전으로 업데이트하고 conf파일에 적용
	////
	if (p_db) {
		sgprintf(DEBUG,
				"CMain::workDaily() - Find New Laser Configuration \'%s\'",
				t_date.c_str());

		//현재 적용된 엔진 버전을 DB에서 가져옴
		string s_query = "";
		s_query += (" SELECT * ");
		s_query += (" FROM TB_ENG_VER ");
		s_query += (" WHERE (1=1) ");
		s_query += (" AND E_USEYN = 1 ");
		s_query += (" LIMIT 0, 1 ");
		s_query += (" ; ");
		MYSQL_RES *mRS = p_db->fnGetResultSet(s_query);
		if (mRS) {
			if (p_db->fnGetRows(mRS) > 0) {
				sgprintf(INFO,
						"CMain::workDaily() - New Engine Config Found !");
				TBENGVER *tb = new TBENGVER();
				tb->getData(mRS);

				//현재 사용 중인 버전 정보와 바이너리 파일 경로를 출력.
				if (FN::equal(tb->E_USEYN, "1")) {
					////
					////	2.1.	Override Engine Config
					////
					if (tb->E_VERSION.length() > 0
							&& !FN::equal(tb->E_VERSION, "NULL")) {
						sgprintf(INFO,
								"Load Configuration from DB - Override STT Image Version - %s",
								tb->E_VERSION.c_str());
						//새로 업데이트 된 버전으로 conf 내용 바꾸기
						SG::conf()->g_laser.n_version = FN::stoi(tb->E_VERSION);
					}
					if (tb->E_FILE_PATH.length() > 0
							&& !FN::equal(tb->E_FILE_PATH, "NULL")) {
						sgprintf(INFO,
								"Load Configuration from DB - Override STT binary file Path - %s",
								tb->E_FILE_PATH.c_str());
						//새로 업데이트 된 경로로 conf 내용 변경
						SG::conf()->g_laser.s_target = ("/" + tb->E_FILE_PATH
								+ "/");
					}

					////
					////	2.2.	Create New Master-Laser (일단은 변경 없음)
					////
					SG::getLaserManager()->createMaster();
				} else {
					sgprintf(ERROR,
							"CMain::workDaily() - New Engine Config Found, But Does not New Version ..");
				}
			} else {
				sgprintf(INFO, "CMain::workDaily() - No New Engine Config");
			}
		}

		mysql_free_result(mRS);
		mRS = NULL;
	}

	string s_query = "";
	if (p_db) {
		s_query += (" SELECT * ");
		s_query += (" FROM TB_SOUND_PATH ");
		s_query += (" WHERE (1=1)");
		s_query += (" AND sp_flag = 1 ");
		s_query += (" LIMIT 0, 1 ");
		s_query += (" ; ");
		MYSQL_RES* mRS = p_db->fnGetResultSet(s_query);
		if (mRS) {
			if (p_db->fnGetRows(mRS) > 0) {
				TBSOUNDPATH *tb = new TBSOUNDPATH();
				tb->getData(mRS);
				if (tb->SP_PATH.length() > 0 && !FN::equal(tb->SP_PATH, "NULL")) {
					sgprintf(INFO, "Load result path from DB - Override result path - %s", tb->SP_PATH.c_str());

					string s_find = "/icanspeak" ;
					string s_root = "/home/cosamo01/" ;
					string s_input = tb->SP_PATH ;
					int n_pos = -1 ;
					if ((n_pos = s_input.find(s_find)) != (signed int)s_input.npos) {
						s_input = s_root + s_input.substr(n_pos) ;
					}
					SG::conf()->g_record.s_wav_path = s_input;
					SG::conf()->g_record.s_pcm_path = s_input;
				}
				delete tb;
				tb = NULL;
			}
		}
		mysql_free_result(mRS);
		mRS = NULL;
	}

	////
	////Reset Time Status
	////

	n_status = 0;
}
