/*
 * CLaserManager.cpp
 *
 *  Created on: Apr 18, 2016
 *      Author: moyakk
 */

#include <CLaserManager.h>

void CLaserManager::swapMaster() {
	sgprintf(DEBUG, "CLaserManager::swapMaster() - %d > %d", n_foreground, n_background) ;
	if (p_master[n_background]) {
		if (p_master[n_background]->n_version > p_master[n_foreground]->n_version) {
			int n_temp = n_foreground ;
			n_foreground = n_background ;
			n_background = n_temp ;
		}
	}
}

void CLaserManager::closeChild() {
	sgprintf(DEBUG, "CLaserManager::closeChild() - Queue Size: %d", childq.size()) ;
	while (childq.size() > 0) {
		CLaser *p_child = childq.remove() ;
		p_child->closeChild() ;
		delete p_child ;
	}
}

void CLaserManager::closeMaster() {
	if (p_master_yn) {
		p_master_yn->closeMaster_yn() ;
		delete p_master_yn ;
		p_master_yn = NULL ;
	}
	if (b_run) {
		sgprintf(DEBUG, "CLaserManager::closeMaster() - Close Background Master Laser") ;
		closeMaster(n_background) ;
	} else {
		sgprintf(DEBUG, "CLaserManager::closeMaster() - Close All Master Laser") ;
		closeMaster(0) ;
		closeMaster(1) ;
	}
}

void CLaserManager::closeMaster(int n_idx) {
	sgprintf(DEBUG, "CLaserManager::closeMaster() - Close Master Laser: %d", n_idx) ;
	if (p_master[n_idx]) {
		p_master[n_idx]->closeMaster() ;
		delete p_master[n_idx] ;
		p_master[n_idx] = NULL ;
	}
}

void CLaserManager::createMaster() {
	sgprintf(DEBUG, "CLaserManager::createMaster() - [ ESTk-Laser DNN ]") ;
	if (!p_master_yn) {
		p_master_yn = new CLaser(SG::conf()) ;
		if (p_master_yn->getMaster_yn() < 0) {
			sgprintf(ERROR, " = laser.yn.m - fail to create master.yn laser ..") ;
		} else {
			sgprintf(INFO, " = laser.yn.m - ready !") ;
		}
	}
	if (!p_master[n_foreground]) {
		sgprintf(INFO, "CLaserManager::createMaster() - Create Foreground Master Laser - Version: %d", SG::conf()->g_laser.n_version) ;
		p_master[n_foreground] = new CLaser(SG::conf()) ;
		if ((p_master[n_foreground]->getMaster()) < 0) {
			sgprintf(ERROR, " = laser.m - fail to create master laser ..") ;
		} else {
			p_master[n_foreground]->createPostProc() ;
			sgprintf(INFO, " = laser.m - ready !") ;
		}
	} else {
		sgprintf(INFO, "CLaserManager::createMaster() - Create Background Master Laser - Version: %d", SG::conf()->g_laser.n_version) ;
		if (p_master[n_background]) {
			closeMaster(n_background) ;
		}
		p_master[n_background] = new CLaser(SG::conf()) ;
		if ((p_master[n_background]->getMaster()) < 0) {
			sgprintf(ERROR, " = laser.m - fail to create master laser ..") ;
		} else {
			this->swapMaster() ;
			sgprintf(INFO, " = laser.m - ready !") ;
		}
	}
}

void CLaserManager::push(CLaser *p_child) {
	int n_version = p_child->n_version ;
	int n_master = n_foreground ;

	if (p_master[n_master]->n_version != n_version) { n_master = n_background ; }

	int n_queue_old = p_master[n_master]->n_cnt ;
	if (1) {
		childq.remove(p_child) ;
		p_child->closeChild() ;
		delete p_child ;
		p_child = NULL ;
		p_master[n_master]->n_cnt-- ;
		usleep(10) ;
	}
	sgprintf(DEBUG, "CLaserManager::push() - Child Laser Version: %d, Queue Size(%d): %d > %d", n_version, childq.size(), n_queue_old, p_master[n_master]->n_cnt) ;

	if (p_master[n_background] != NULL) {
		if (p_master[n_background]->n_cnt <= 0) {
			p_master[n_background]->closeMaster() ;
			this->closeMaster(n_background) ;
			sgprintf(DEBUG, "CLaserManager::push() - Background Master Laser Closed") ;
		}
	}
}

CLaser *CLaserManager::pop() {
	CLaser *p_child = NULL ;
	pthread_mutex_lock(&mutex) ;
	int n_queue_old = p_master[n_foreground]->n_cnt ;
	if (p_master[n_foreground]->n_cnt >= SG::conf()->g_laser.n_channel) {
		sgprintf(INFO, "CLaserManager::popChild() - No Child(Channel Full) !") ;
		return NULL ;
	} else {
		p_child = new CLaser(SG::conf()) ;
		if ((p_child->getChild(p_master[n_foreground]->pLaser)) < 0) {
			sgprintf(INFO, " = laser.c%d - fail to create child laser ..", p_master[n_foreground]->n_cnt) ;
		} else {
			sgprintf(INFO, " = laser.c%d - ready ! \n", p_master[n_foreground]->n_cnt) ;
			childq.add(p_child) ;
		}
		p_master[n_foreground]->n_cnt++ ;
		usleep(10) ;
	}
	sgprintf(DEBUG, "CLaserManager::pop() - Queue Size(%d): %d > %d", childq.size(), n_queue_old, p_master[n_foreground]->n_cnt) ;
	pthread_mutex_unlock(&mutex) ;
	return p_child ;
}
