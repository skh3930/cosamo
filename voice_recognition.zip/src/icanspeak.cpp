//============================================================================
// Name        : icanspeak.cpp
// Author      : suhyun
// Version     : 0.1
// Description :
//============================================================================

#include <string>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <math.h>
#include <CMain.h>

#include "CSystemResource.h"

CMain *p_main ;

void sigHandler(int n_signo) {
	sgprintf(INFO, "sigHandler() - Signal Catched - %d", n_signo) ;
	if (p_main) {
		p_main->stop() ;
	}
}

int main() {
	sgprintf(INFO, "----- > COSAMO-ICIP > START ! > -----") ;

	signal(SIGINT, sigHandler) ;
	fnSystemConfig() ;

	p_main = NULL ;
	if (!p_main) {
		p_main = new CMain(1) ;
		p_main->start() ;
	}

	int n_cnt = 0 ;
	while (1) {
		n_cnt++ ;
		if (p_main) {
			if (!p_main->isRun()) {	//현재 메인 스레드가 돌고있는지 확인
				p_main->join() ;	//현재 메인 스레드가 돌고 있지 않으므로 종료 시킴.
				delete p_main ;		//메인 스레드 삭제
				p_main = NULL ;
				break ;
			}
		}
		if (n_cnt >= 60) {	//일정한 간격으로 계속 돌고 있음을 나타냄.
			sgprintf(DEBUG, "COSAMO-ICIP::main() - I'm alive ! :D") ;
			n_cnt = 0 ;
		}
		sleep(1) ;
	}
	sgprintf(INFO, "----- > COSAMO-ICIP > FINISH ! > -----") ;	//현재 돌고있지 않다면 종료 됨.
	return 0 ;
}
