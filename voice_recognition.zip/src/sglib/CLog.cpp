/*
c * CLog.cpp
 *
 *  Created on: Dec 22, 2015
 *      Author: moyakk
 */

#include "CLog.h"

CLog::CLog(string in_name) {
	pthread_mutex_init(&mutex, NULL) ;
	fLog = NULL ;
	s_name = in_name ;
	s_path = "./log/" ;
	s_file = "" ;
	s_date = FN::yyyymmdd(0) ;
	n_info = LOG_STDOUT ;
	n_debug = LOG_STDOUT ;
	n_error = LOG_STDOUT ;
	openLog() ;
}

CLog::CLog(string in_name, string in_path) {
	pthread_mutex_init(&mutex, NULL) ;
	fLog = NULL ;
	s_name = in_name ;
	if (in_path.length() > 0) {
		s_path = in_path ;
		s_path += "log/" ;
	} else {
		s_path = "./log/" ;
	}
	s_file = "" ;
	s_date = FN::yyyymmdd(0) ;
	n_info = LOG_STDOUT ;
	n_debug = LOG_STDOUT ;
	n_error = LOG_STDOUT ;
	openLog() ;
}

CLog::~CLog() {
	pthread_mutex_destroy(&mutex) ;
	closeLog() ;
}

void CLog::setLog(string in_name, string in_path) {
	s_name = in_name ;
	if (in_path.length() > 0) {
		s_path = in_path ;
		s_path += "log/" ;
	} else {
		s_path = "./log/" ;
	}
}

void CLog::setLogLevel(int _info, int _debug, int _error) {
	n_info = _info ;
	n_debug = _debug ;
	n_error = _error ;
}

void CLog::openLog() {
	bool isDIR = false ;
	struct stat sb ;
	if (s_name.length() > 0) {
		if (stat(s_path.c_str(), &sb) == 0) {
			if (S_ISDIR(sb.st_mode)) {
				isDIR = true ;
			} else {
				printf(" = log.%s - path error .. \n . [%s] \n", s_name.c_str(), s_path.c_str()) ;
			}
		} else {
			printf(" = mkdir \n") ;
			mkdir(s_path.c_str(), 0700) ;
		}
		s_file = (s_path+s_name+"."+FN::yyyymmdd(0)+".log") ;
		fLog = fopen(s_file.c_str(), "a+");
		printf(" = log.%s - OK ! \n . [%s] \n", s_name.c_str(), s_file.c_str()) ;
	} else {
		fLog = stdout ;
		printf(" = log.%s - OK ! \n", "stdout") ;
	}
}

void CLog::closeLog() {
	if (s_name.length() > 0) {
		if (fLog) {
			fflush(fLog) ;
			fclose(fLog) ;
		}
	}
}

void CLog::resetLog() {
	closeLog() ;
	openLog() ;
}

bool CLog::checkDate() {
	bool b_ret = false ;
	string s_now = FN::yyyymmdd(0) ;
	int n_input_len = s_date.length() ;
	int n_compare_len = s_now.length() ;
	if (n_input_len == n_compare_len) {
		if (s_date.compare(s_now) == 0) {
			b_ret = false ;
		} else {
			printf(" = CLog.checkDate(%s) - Date Changed ! %s > %s \n", s_name.c_str(), s_date.c_str(), s_now.c_str()) ;
			s_date = s_now ;
			b_ret = true ;
		}
	}
	return b_ret ;
}

void CLog::printLog(string s_title, string s_description) {
	pthread_mutex_lock(&mutex) ;
	if (checkDate()) { resetLog() ; }
	if (s_description.length() == 0) {
		s_description = "Empty Log" ;
	}
	pthread_mutex_unlock(&mutex) ;
}

void CLog::print(int n_type, const char *timestamp, char *buf) {
	pthread_mutex_lock(&mutex) ;
	if (buf[strlen(buf)-1] == '\n') {
		buf[strlen(buf)-1] = 0x00 ;
	}
	int n_level = LOG_NEVER ;
	string s_type = "i" ;
	if (n_type == 1) {
		n_level = n_info ;
		s_type = "i" ;
	} else if (n_type == 2) {
		n_level = n_debug ;
		s_type = "d" ;
	} else if (n_type == 3) {
		n_level = n_error ;
		s_type = "e" ;
	}
	if (n_level == LOG_STDOUT || n_level == LOG_ALL) {
		fprintf(stdout, "[%s][%s] %s\n", timestamp, s_type.c_str(), buf) ;
	}
	if (n_level == LOG_FILE || n_level == LOG_ALL) {
		if (checkDate()) { resetLog() ; }
	}
	pthread_mutex_unlock(&mutex) ;
}
void CLog::info(const char *msg, ...) {
	int n_len = 1024 ;
	if (n_len < (int)strlen(msg)) {
		n_len = strlen(msg) + 2 ;
	}
	char buf[n_len] ;
	va_list ap ;
	va_start(ap, msg) ;
	vsprintf(buf, msg, ap) ;
	va_end(ap) ;
	print(1, FN::yyyymmddhhmmsss(1).c_str(), buf) ;
}
void CLog::debug(const char *msg, ...) {
	int n_len = 1024 ;
	if (n_len < (int)strlen(msg)) {
		n_len = strlen(msg) + 2 ;
	}
	char buf[n_len] ;
	va_list ap ;
	va_start(ap, msg) ;
	vsprintf(buf, msg, ap) ;
	va_end(ap) ;
	print(2, FN::yyyymmddhhmmsss(1).c_str(), buf) ;
}
void CLog::error(const char *msg, ...) {
	int n_len = 1024 ;
	if (n_len < (int)strlen(msg)) {
		n_len = strlen(msg) + 2 ;
	}
	char buf[n_len] ;
	va_list ap ;
	va_start(ap, msg) ;
	vsprintf(buf, msg, ap) ;
	va_end(ap) ;
	print(3, FN::yyyymmddhhmmsss(1).c_str(), buf) ;
}
