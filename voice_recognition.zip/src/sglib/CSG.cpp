/*
 * CSG.cpp
 *
 *  Created on: Apr 18, 2016
 *      Author: moyakk
 */

#include <CSG.h>
#include <CConfiguration.h>
#include <CLog.h>
#include <CLaserManager.h>
#include <CFile.h>
////////////////////////////////////////////////////////////
////
////	CConfiguration
////

CConfiguration *SG::p_conf = NULL ;
CConfiguration *SG::conf() {
	if (!p_conf) {
		sgprintf(DEBUG, "SG::conf() - Load Configuration from File") ;
		p_conf = new CConfiguration("icanspeak.conf") ;
		p_conf->fnPrintConfigData() ;
	}
	return p_conf ;
}


////////////////////////////////////////////////////////////
////
////	CLog
////

CLog *SG::p_sgout = NULL ;
CLog *SG::getsgout() {
	if (p_sgout == NULL) {
		CConfiguration *t_conf = new CConfiguration("icanspeak.conf") ;
		p_sgout = new CLog("sgout", t_conf->g_module.s_root) ;
		p_sgout->setLogLevel(t_conf->g_module.n_log_info, t_conf->g_module.n_log_debug, t_conf->g_module.n_log_error) ;
		delete t_conf ;
	}
	return p_sgout ;
}

////////////////////////////////////////////////////////////
////
////	CLaserManager
////

CLaserManager *SG::p_laser_manager = NULL ;
CLaserManager *SG::getLaserManager() {
	if (p_laser_manager == NULL) {
		sgprintf(DEBUG, "SG::getLaserManager() - Create Instance") ;
		p_laser_manager = new CLaserManager() ;
		p_laser_manager->createMaster() ;
	}
	return p_laser_manager ;
}

////////////////////////////////////////////////////////////
////
////	CFile
////

CFile *SG::p_file = NULL ;
CFile *SG::getCFile() {
	if (p_file == NULL) {
		sgprintf(DEBUG, "SG::getCFile() - Create Instance") ;
		p_file = new CFile() ;
	}
	return p_file ;
}
