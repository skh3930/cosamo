/*
 * CConfiguration.cpp
 *
 *  Created on: Sep 24, 2015
 *      Author: solugate
 */

#include <CSGUTIL.h>
#include "CConfiguration.h"

void CConfiguration::getConfig() {

	string s_group = "" ;
	Config *p_group ;

	////////////////////////////////////////////////////////////
	////	MODULE

	p_group = group("MODULE") ;
	if (p_group->getSymbols().size() > 0) {
		g_module.s_name = p_group->pString("NAME") ;
		g_module.s_root = p_group->pString("ROOT") ;
		g_module.n_interval = p_group->pInt("ALIVE_INTERVAL") ;
		g_module.s_ip = p_group->pString("IP") ;
		g_module.s_key = p_group->pString("KEY") ;
		g_module.n_mode = p_group->pInt("MODE") ;
		g_module.n_log_info = p_group->pInt("LOG_INFO") ;
		g_module.n_log_debug = p_group->pInt("LOG_DEBUG") ;
		g_module.n_log_error = p_group->pInt("LOG_ERROR") ;
	}

	////////////////////////////////////////////////////////////
	////	LASER

	p_group = group("LASER") ;
	if (p_group->getSymbols().size() > 0) {
		g_laser.n_version = 0 ;
		g_laser.s_root = p_group->pString("ROOT") ;
		g_laser.s_target = p_group->pString("TARGET") ;
		g_laser.b_gpu = p_group->pBool("GPU_YN") ;
		g_laser.n_channel = p_group->pInt("CHANNEL") ;
	}

	////////////////////////////////////////////////////////////
	////	DB

	p_group = group("DB") ;
	if (p_group->getSymbols().size() > 0) {
		g_db.s_type = p_group->pString("TYPE") ;
		g_db.s_host = p_group->pString("HOST") ;
		g_db.n_port = p_group->pInt("PORT") ;
		g_db.s_name = p_group->pString("NAME") ;
		g_db.s_id = p_group->pString("ID") ;
		g_db.s_pw = p_group->pString("PW") ;
		g_db.n_log_info = p_group->pInt("LOG_INFO") ;
		g_db.n_log_debug = p_group->pInt("LOG_DEBUG") ;
		g_db.n_log_error = p_group->pInt("LOG_ERROR") ;
	}

	////////////////////////////////////////////////////////////
	////	RECORD

	p_group = group("RECORD") ;
	if (p_group->getSymbols().size() > 0) {
		g_record.b_txt = p_group->pBool("TXT_USE_YN") ;
		g_record.b_txt_remove = p_group->pBool("TXT_REMOVE_YN") ;
		g_record.n_txt_remove_after = p_group->pInt("TXT_REMOVE_AFTER") ;
		g_record.s_txt_path = p_group->pString("TXT_PATH") ;
		g_record.b_pcm = p_group->pBool("PCM_USE_YN") ;
		g_record.b_pcm_remove = p_group->pBool("PCM_REMOVE_YN") ;
		g_record.n_pcm_remove_after = p_group->pInt("PCM_REMOVE_AFTER") ;
		g_record.s_pcm_path = p_group->pString("PCM_PATH") ;
		g_record.b_wav = p_group->pBool("WAV_USE_YN") ;
		g_record.b_wav_remove = p_group->pBool("WAV_REMOVE_YN") ;
		g_record.n_wav_remove_after = p_group->pInt("WAV_REMOVE_AFTER") ;
		g_record.s_wav_path = p_group->pString("WAV_PATH") ;
		g_record.b_mp3 = p_group->pBool("MP3_USE_YN") ;
		g_record.b_mp3_remove = p_group->pBool("MP3_REMOVE_YN") ;
		g_record.n_mp3_remove_after = p_group->pInt("MP3_REMOVE_AFTER") ;
		g_record.s_mp3_path = p_group->pString("MP3_PATH") ;
	}

	////////////////////////////////////////////////////////////
	////	 PORT

	p_group = group("TCPIP") ;
	if (p_group->getSymbols().size() > 0) {
		g_tcpip.n_tcp_port = p_group->pInt("TCP_PORT") ;
		g_tcpip.n_udp_port_start = p_group->pInt("UDP_PORT_START") ;
		g_tcpip.n_udp_port_end = p_group->pInt("UDP_PORT_END") ;
		g_tcpip.s_ip = p_group->pString("SERVER_IP");
	}
}

void CConfiguration::fnPrintConfigData() {
	map<string, Config*> p_groups = getGroups() ;
	for (map<string, Config*>::iterator i=p_groups.begin(); i!=p_groups.end(); ++i) {
		string s_group_name = i->first ;
		Config *p_config = i->second ;

		for (map<string, string>::iterator ii=p_config->getSymbols().begin(); ii!=p_config->getSymbols().end(); ++ii) {
			string s_key = ii->first ;
			string s_value = ii->second ;
			string s_group_key = s_group_name + "." + s_key ;
			printf(" [CONF] %-20s: %s\n", s_group_key.c_str(), FN::exists(s_group_key.c_str(), ".PW")? "********":s_value.c_str()) ;
		}
		printf("\n") ;
	}
}
