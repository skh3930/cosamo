/*
 * CLaser.cpp
 *
 *  Created on: Dec 29, 2015
 *      Author: moyakk
 */

#include <CLaser.h>
#include <CLog.h>
#include <CSG.h>
#include <CDefineDNN.h>

CLaser::CLaser(CConfiguration *in_conf) {
	conf = in_conf;
	priorWeight = 0.8;
	miniBatch = 128;
	useGPU = 0;
	idGPU = 0;
	featdim_epd = -1;
	featdim_dnn = -1;
	mfcc_size = -1;
	s_root = (conf->g_laser.s_root + "/" + conf->g_laser.s_target + "/");
	n_version = conf->g_laser.n_version;
	n_cnt = 0;
	//
	memset(sam, 0x00, clen);
	memset(sfsm, 0x00, clen);
	memset(sym, 0x00, clen);
	memset(adapt, 0x00, clen);
	memset(prior, 0x00, clen);
	memset(lda, 0x00, clen);
	memset(tagging, 0x00, clen);
	memset(chunking, 0x00, clen);
	memset(userDic, 0x00, clen);
	memset(confEPD, 0x00, clen);
	memset(confDNN, 0x00, clen);
	memset(sttLaser, 0x00, clen);
	//
	pLaser = NULL;
	feEPD = NULL;
	feDNN = NULL;
	m_psil = NULL;
}

CLaser::~CLaser() {
	if (m_psil)
		free(m_psil);
}

int CLaser::getMaster() {
	bool b_next = true;
	int n_ret = -1;
	if (b_next) {
		if ((n_ret = setConfig()) < 0) {
			sgprintf(ERROR, "CLaser::getMaster() - fail to set config ..");
			b_next = false;
		}
	}
	n_ret = -1;
	if (b_next) {
		setSLaserLBCores(NUM_CORES);
		if ((n_ret = createMaster()) < 0) {
			sgprintf(ERROR,
					"CLaser::getMaster() - fail to create master laser ..");
			b_next = false;
		}
	}
	return n_ret;
}

int CLaser::getMaster_yn() {
	bool b_next = true;
	int n_ret = -1;
	if (b_next) {
		if ((n_ret = setConfig_yn()) < 0) {
			sgprintf(ERROR, "CLaser::getMaster() - fail to set config ..");
			b_next = false;
		}
	}
	n_ret = -1;
	if (b_next) {
		if ((n_ret = createMaster()) < 0) {
			sgprintf(ERROR,
					"CLaser::getMaster() - fail to create master laser ..");
			b_next = false;
		}
	}
	return n_ret;
}

int CLaser::getChild(Laser *pMaster) {
	bool b_next = true;
	int n_ret = -1;
	if (b_next) {
		if ((n_ret = setConfig()) < 0) {
			sgprintf(ERROR, "CLaser::getChild() - fail to set config ..");
			b_next = false;
		}
	}
	if (b_next) {
		if ((n_ret = setFrontEnd()) < 0) {
			sgprintf(ERROR, "CLaser::getChild() - fail to set frontend ..");
			b_next = false;
		}
	}
	if (b_next) {
		if ((n_ret = createChild(pMaster)) < 0) {
			sgprintf(ERROR,
					"CLaser::getChild() - fail to create child laser ..");
			b_next = false;
		}
	}
	return n_ret;
}

int CLaser::getChild_yn(Laser *pMaster) {
	bool b_next = true;
	int n_ret = -1;
	if (b_next) {
		if ((n_ret = setConfig_yn()) < 0) {
			sgprintf(ERROR, "CLaser::getChild() - fail to set config ..");
			b_next = false;
		}
	}
	if (b_next) {
		if ((n_ret = setFrontEnd()) < 0) {
			sgprintf(ERROR, "CLaser::getChild() - fail to set frontend ..");
			b_next = false;
		}
	}
	if (b_next) {
		if ((n_ret = createChild(pMaster)) < 0) {
			sgprintf(ERROR,
					"CLaser::getChild() - fail to create child laser ..");
			b_next = false;
		}
	}
	return n_ret;
}

void CLaser::closeMaster() {
	if (pLaser) {
		sgprintf(INFO, "CLaser::closeMaster() - Close Master Laser");
		closeSPLPostProc();
		sgprintf(INFO, "CLaser::closeMaster() - (1/2) closeSPLPostProc");
		freeMasterLaserDNN(pLaser);
		sgprintf(INFO, "CLaser::closeMaster() - (2/2) freeMasterLaserDNN");
	}
}

void CLaser::closeMaster_yn() {
	if (pLaser) {
		sgprintf(INFO, "CLaser::closeMaster_yn() - Close Master Laser");
		freeMasterLaserDNN(pLaser);
		sgprintf(INFO, "CLaser::closeMaster_yn() - (1/1) freeMasterLaserDNN");
	}
}

void CLaser::closeChild() {
	if (pLaser) {
		sgprintf(INFO, "CLaser::closeChild() - Close Child Laser");
		freeChildLaserDNN(pLaser);
		sgprintf(INFO, "CLaser::closeChild() - (1/1) freeChildLaserDNN");
	}
	if (feEPD) {
		sgprintf(INFO, "CLaser::closeChild() - Close FrontEnd.EPD");
		resetLFrontEnd(feEPD);
		sgprintf(INFO, "CLaser::closeChild() - (1/2) resetLFrontEnd.EPD");
		closeLFrontEnd(feEPD);
		sgprintf(INFO, "CLaser::closeChild() - (2/2) closeLFrontEnd.EPD");
	}
	if (feDNN) {
		sgprintf(INFO, "CLaser::closeChild() - Close FrontEnd.DNN");
		resetLFrontEnd(feDNN);
		sgprintf(INFO, "CLaser::closeChild() - (1/2) resetLFrontEnd.DNN");
		closeLFrontEnd(feDNN);
		sgprintf(INFO, "CLaser::closeChild() - (2/2) closeLFrontEnd.DNN");
	}
}

int CLaser::setConfig() {
	int n_ret = -1;
	if (!conf) {
		n_ret = -1;
	} else {
		// REF.PATH
		strcpy(sam, s_root.c_str());
		strcat(sam, d_sam);
		strcpy(sfsm, s_root.c_str());
		strcat(sfsm, d_sfsm);
		strcpy(sym, s_root.c_str());
		strcat(sym, d_sym);
		strcpy(adapt, s_root.c_str());
		strcat(adapt, d_adapt);
		strcpy(prior, s_root.c_str());
		strcat(prior, d_prior);
		strcpy(lda, s_root.c_str());
		strcat(lda, d_lda);
		strcpy(tagging, s_root.c_str());
		strcat(tagging, d_tagging);
		strcpy(chunking, s_root.c_str());
		strcat(chunking, d_chunking);
		strcpy(userDic, s_root.c_str());
		strcat(userDic, d_userDic);
		// LASER.SETTTING
		priorWeight = 0.8;
		miniBatch = 128;
		useGPU = (conf->g_laser.b_gpu) ? 1 : 0;
		idGPU = 0;
		//
		featdim_epd = -1;
		featdim_dnn = -1;
		mfcc_size = -1;
		n_ret = 1;
	}
	return n_ret;
}

int CLaser::setConfig_yn() {
	int n_ret = -1;
	if (!conf) {
		n_ret = -1;
	} else {
		s_root = "/home/rootdev/ETRIdnn/default_yn/";
		strcpy(sam, s_root.c_str());
		strcat(sam, d_sam);
		strcpy(sfsm, s_root.c_str());
		strcat(sfsm, d_sfsm);
		strcpy(sym, s_root.c_str());
		strcat(sym, d_sym);
		strcpy(adapt, s_root.c_str());
		strcat(adapt, d_adapt);
		strcpy(prior, s_root.c_str());
		strcat(prior, d_prior);
		strcpy(lda, s_root.c_str());
		strcat(lda, d_lda);
		strcpy(tagging, s_root.c_str());
		strcat(tagging, d_tagging);
		strcpy(chunking, s_root.c_str());
		strcat(chunking, d_chunking);
		strcpy(userDic, s_root.c_str());
		strcat(userDic, d_userDic);

		// LASER.SETTTING
		priorWeight = 0.8;
		miniBatch = 1;
		useGPU = (conf->g_laser.b_gpu) ? 1 : 0;
		idGPU = 0;
		//
		featdim_epd = -1;
		featdim_dnn = -1;
		mfcc_size = -1;
		n_ret = 1;
	}
	return n_ret;
}

int CLaser::setFrontEnd() {
	int n_ret = -1;

	strcpy(confEPD, s_root.c_str());
	strcat(confEPD, d_feEPD);
	strcpy(confDNN, s_root.c_str());
	strcat(confDNN, d_feDNN);

	// ______________________________________________________________________
	//
	//		Prepare FrontEnd | for EPD
	//

	sgprintf(INFO, "CLaser::setFrontEnd() - FrontEnd.EPD");

	featdim_epd = -1;
	if (!feEPD) {
		feEPD = createLFrontEndExt(FRONTEND_OPTION_8KHZFRONTEND);
		//	Read Configuration
		if (readOptionLFrontEnd(feEPD, confEPD))
			sgprintf(ERROR,
					"CLaser::setFrontEnd() - Fail to Read Configuration - frontend_53.cfg");
		//	Check Configuration
		resetLFrontEnd(feEPD);
		if (getIntValueLFrontEnd(feEPD, (char *) "FRONTEND_OUTDIM",
				&featdim_epd) == -1) {
			sgprintf(ERROR,
					"CLaser::setFrontEnd() - FRONTEND_OUTDIM.EPD | fail to read ..");
		} else {
			sgprintf(INFO, "CLaser::setFrontEnd() - FRONTEND_OUTDIM.EPD | %d",
					featdim_epd);
		}
		//	Message
		if (feEPD) {
			sgprintf(INFO,
					"CLaser::setFrontEnd() - createLFrontEndExt.EPD - OK !");
		} else {
			sgprintf(ERROR,
					"CLaser::setFrontEnd() - createLFrontEndExt.EPD - fail ..");
		}
	}

	// ______________________________________________________________________
	//
	//		Prepare FrontEnd | for DNN
	//

	sgprintf(INFO, "CLaser::setFrontEnd() - FrontEnd.STT");

	mfcc_size = -1;
	featdim_dnn = -1;
	if (!feDNN) {
		feDNN = createLFrontEndExt(
		FRONTEND_OPTION_8KHZFRONTEND | FRONTEND_OPTION_DNNFBFRONTEND);
		//	Read Configuration
		if (readOptionLFrontEnd(feDNN, confDNN))
			sgprintf(ERROR,
					"CLaser::setFrontEnd() - Fail to Read Configuration - frontend_dnn.cfg");
		//	Check Configuration
		resetLFrontEnd(feDNN);
		if (getIntValueLFrontEnd(feDNN, (char *) "FRONTEND_OUTDIM", &mfcc_size)
				== -1) {
			sgprintf(ERROR,
					"CLaser::setFrontEnd() - FRONTEND_OUTDIM.DNN | fail to read ..");
		} else {
			sgprintf(INFO, "CLaser::setFrontEnd() - FRONTEND_OUTDIM.DNN | %d",
					mfcc_size);
			featdim_dnn = mfcc_size * miniBatch;
		}
		//	Message
		if (feDNN) {
			sgprintf(INFO, "createLFrontEndExt.DNN - OK !");
		} else {
			sgprintf(ERROR, "createLFrontEndExt.DNN - Fail ..");
		}
	}

	if (featdim_epd > 0 && featdim_dnn > 0) {

		// ______________________________________________________________________
		//
		// m_psil
		//

		int pbSilLen = 90;

		FILE *fp = NULL;
		fp = fopen("tools/sil_dnn.data", "rb");

		if (miniBatch > pbSilLen) {
			pbSilLen = MAX_MINIBATCH;
			if (fp != NULL) {
				m_psil = (float*) malloc(
						sizeof(float) * (pbSilLen + 128) * mfcc_size);
				fread(m_psil, sizeof(float), mfcc_size * 100, fp);
				for (int i = 1; i <= 10; i++) {
					memcpy(m_psil + i * (mfcc_size * 100), m_psil,
							sizeof(float) * mfcc_size * 100);
				}
				fclose(fp);
			}
		} else {
			if (fp != NULL) {
				m_psil = (float*) malloc(sizeof(float) * pbSilLen * mfcc_size);
				fread(m_psil, sizeof(float), mfcc_size * 90, fp);
				fclose(fp);
			}
		}
		n_ret = 1;
	} else {
		n_ret = -1;
	}
	return n_ret;
}

int CLaser::createMaster() {
	int n_ret = -1;
	if (pLaser) {
		n_ret = 0;
	} else {
		strcpy(sttLaser, s_root.c_str());
		strcat(sttLaser, d_laser);
		// CREATE
		pLaser = createMasterLaserDNN(sam, adapt, priorWeight, prior, lda,
				miniBatch, useGPU, idGPU, sfsm, sym);

		// SET
		sgprintf(INFO,
				"CLaser::createMaster() - createMasterLaserDNN - OK ! [GPU:%d]",
				useGPU);
		if (readSLaserConfig(pLaser, sttLaser) < 0) {
			sgprintf(INFO,
					"CLaser::createMaster() - readSLaserConfig - fail ..");
		} else {
			sgprintf(INFO, "CLaser::createMaster() - readSLaserConfig - OK !");
		}
		//	PRINT
		if (pLaser) {
			sgprintf(INFO,
					"CLaser::createMaster() - createMasterLaserDNN - OK !");
		} else {
			sgprintf(ERROR,
					"CLaser::createMaster() - createMasterLaserDNN - Fail ..");
		}
		n_ret = 1;
	}
	return n_ret;
}

int CLaser::createPostProc() {
	int n_ret = -1;
	int n_cnt = conf->g_laser.n_channel;
	if (n_cnt > 32) {
		n_cnt = 32;
	}
	if (!Lat2cnWordNbestOutInit(tagging, chunking, userDic, n_cnt)) {
		sgprintf(ERROR,
				"CLaser::createPostProc() - Lat2cnWordNbestOutInit - fail ..");
		n_ret = -2;
	} else {
		sgprintf(INFO,
				"CLaser::createPostProc() - Lat2cnWordNbestOutInit - OK !");
		n_ret = 1;
	}
	return n_ret;
}

int CLaser::createChild(Laser *pMaster) {
	int n_ret = -1;
	if (pLaser) {
		n_ret = 0;
	} else {
		if (!pMaster) {
			n_ret = -2;
		} else {
			pLaser = createChildLaserDNN(pMaster, sam, adapt, priorWeight,
					prior, lda, miniBatch, useGPU, idGPU, sfsm, sym);
			//	PRINT
			if (!pLaser) {
				sgprintf(ERROR,
						"CLaser::createChild() - createChildLaserDNN - Fail ..");
				n_ret = -3;
			} else {
				sgprintf(INFO,
						"CLaser::createChild() - createChildLaserDNN - OK ! [GPU:%d]",
						useGPU);
				n_ret = 1;
			}
		}
	}
	if (n_ret == 1) {
		sgprintf(INFO, "CLaser::createChild() - CLaserDNN - OK !");
		if (0) {
			printf("sam \t\t : %s \n", sam);
			printf("sfsm \t\t : %s \n", sfsm);
			printf("sym \t\t : %s \n", sym);
			printf("adapt \t\t : %s \n", adapt);
			printf("prior \t\t : %s \n", prior);
			printf("lda \t\t : %s \n", lda);
			printf("\n");
			printf("LBCores \t : %d \n", NUM_CORES);
			printf("priorWeight \t : %f \n", priorWeight);
			printf("miniBatch \t : %d \n", miniBatch);
			printf("useGPU \t\t : %d \n", useGPU);
			printf("idGPU \t\t : %d \n", idGPU);
			printf("\n [ Lat2cnWordNbestOutInit ] \n");
			printf("tagging \t : %s \n", tagging);
			printf("chunking \t : %s \n", chunking);
			printf("userDic \t : %s \n", userDic);
		}
	}
	return n_ret;
}

int CLaser::getEPD(short *buf, int n_buf_len, bool b_show_epdret) {
	// ______________________________________________________________________
	//	EPD - End Point Detection

	int n_status = -1;

	int olen_epd = -1;
	float *obuf_epd = (float*) malloc(
			sizeof(float) * (featdim_epd * n_buf_len));
	int epdstat = stepFrameLFrontEnd(feEPD, n_buf_len, buf, &olen_epd,
			obuf_epd);

	if (b_show_epdret)
		printf(" (epdret: %d) ", epdstat);

	if (epdstat & onset) {
		if (b_show_epdret)
			printf(" [onset] \n");
		n_status = 1;
	}
	if (epdstat & detecting) {
		if (b_show_epdret)
			printf(" [detecting] \n");
		n_status = 2;
	}
	if (epdstat & offset) {
		if (b_show_epdret)
			printf(" [offset] \n");
		n_status = 2;
	}
	if (epdstat & detected) {
		if (b_show_epdret)
			printf(" [detected] \n");
		n_status = 3;
	}
	if (b_show_epdret) {
		if (epdstat & noise) {
			printf(" [noise] \n");
		}
		if (epdstat & reset) {
			printf(" [reset] \n");
		}
		if (epdstat & restart) {
			printf(" [restart] \n");
		}
		if (epdstat & timeout) {
			printf(" [timeout] \n");
		}
	}
	free(obuf_epd);
	return n_status;
}

string CLaser::getSTT(short *buf, int n_buf_len) {
	string s_ret = "";
	if (buf && n_buf_len > 0) {
		resetSLaser(pLaser);
		resetLFrontEnd(feEPD);
		resetLFrontEnd(feDNN);
		// Make Features and Get Result Text
		int olen_dnn;
		float *obuf_dnn = (float*) malloc(
				sizeof(float) * (mfcc_size * n_buf_len));
		stepFrameLFrontEnd(feDNN, n_buf_len, buf, &olen_dnn, obuf_dnn); // Feature Extraction
		if (olen_dnn > 0) {
			int nf = olen_dnn / mfcc_size;
			if (nf < miniBatch) { // fill silenced feature data to miniBatch size
				memcpy((obuf_dnn + nf + mfcc_size), m_psil,
						sizeof(float) * (mfcc_size * (miniBatch - nf)));
			}
			sgprintf(DEBUG,
					"CLaser::getSTT() - buflen: %d, nf: %d, featdim: %d, mfccsize: %d \n",
					n_buf_len, nf, featdim_dnn, mfcc_size);
			for (int k = 0; k < nf; k++) {
				stepSARecFrameExt(pLaser, k, featdim_dnn,
						obuf_dnn + (k * mfcc_size));
			}
			for (int k = 0; k < 40; k++) {
				stepSARecFrameExt(pLaser, k + nf, featdim_dnn,
						m_psil + (k * mfcc_size));
			}
			nf += 40;
			int n_print_mode = 2; // 1:Detail, 2:TextOnly
			int n_buf_max = 4096;
			char lvouts1[n_buf_max];
			memset(lvouts1, 0x00, n_buf_max);
			char lvouts2[n_buf_max];
			memset(lvouts2, 0x00, n_buf_max);
			char *resultP = getWBAdjustedResultSLaser(pLaser, nf, 1,
					n_print_mode); // Get Result
			if (resultP) {
				if (strlen(resultP) > 0) {
					if (n_print_mode == 1) {
						memcpy(lvouts2, resultP, n_buf_max); // SET.TAIL
					} else {
						sgprintf(DEBUG, "CLaser::getSTT() - buflen: %d, [%s]",
								n_buf_len, FN::toUTF8(resultP).c_str());
						SPLPostProc(resultP, lvouts1); // Post Process
						RemoveSpecialChar(lvouts1, lvouts2); // Clean Text
					}
					s_ret = lvouts2;
				}
			}
		}
		free(obuf_dnn);
		reallocSLaser(pLaser);
		resetSLaser(pLaser);
	}
	return s_ret;
}

string CLaser::getSTT_yn(short *buf, int n_buf_len) {
	string s_ret = "";
	if (buf && n_buf_len > 0) {
		resetSLaser(pLaser);
		resetLFrontEnd(feEPD);
		resetLFrontEnd(feDNN);
		// Make Features and Get Result Text
		int olen_dnn;
		float *obuf_dnn = (float*) malloc(
				sizeof(float) * (mfcc_size * n_buf_len));
		stepFrameLFrontEnd(feDNN, n_buf_len, buf, &olen_dnn, obuf_dnn); // Feature Extraction
		if (olen_dnn > 0) {
			int nf = olen_dnn / mfcc_size;
			if (nf < miniBatch) { // fill silenced feature data to miniBatch size
				memcpy((obuf_dnn + nf + mfcc_size), m_psil,
						sizeof(float) * (mfcc_size * (miniBatch - nf)));
			}
			sgprintf(DEBUG,
					"CLaser::getSTT_yn() - buflen: %d, nf: %d, featdim: %d, mfccsize: %d",
					n_buf_len, nf, featdim_dnn, mfcc_size);
			for (int k = 0; k < nf; k++) {
				stepSARecFrameExt(pLaser, k, featdim_dnn,
						obuf_dnn + (k * mfcc_size));
			}
			for (int k = 0; k < 40; k++) {
				stepSARecFrameExt(pLaser, k + nf, featdim_dnn,
						m_psil + (k * mfcc_size));
			}
			nf += 40;
			int n_print_mode = 2; // 1:Detail, 2:TextOnly
			int n_buf_max = 4096;
			char lvouts1[n_buf_max];
			memset(lvouts1, 0x00, n_buf_max);
			char lvouts2[n_buf_max];
			memset(lvouts2, 0x00, n_buf_max);
			char *resultP = getWBAdjustedResultSLaser(pLaser, nf, 1,
					n_print_mode); // Get Result
			if (resultP) {
				if (strlen(resultP) > 0) {
					if (n_print_mode == 1) {
						memcpy(lvouts2, resultP, n_buf_max); // SET.TAIL
					} else {
						sgprintf(DEBUG,
								"CLaser::getSTT_yn() - buflen: %d, [%s]",
								n_buf_len, FN::toUTF8(resultP).c_str());
						SPLPostProc(resultP, lvouts1); // Post Process
						RemoveSpecialChar(lvouts1, lvouts2); // Clean Text
					}
					s_ret = lvouts2;
				}
			}
		}
		free(obuf_dnn);
		reallocSLaser(pLaser);
		resetSLaser(pLaser);
	}
	return s_ret;
}

void CLaser::resetFrontEndEPD() {
	resetLFrontEnd(feEPD);
}

void CLaser::RemoveSpecialChar(char* pIn, char* pOut) {
	int nLen = strlen(pIn);
	int nAdd = 0;
	for (int i = 0; i < nLen; i++) {
		if (pIn[i] == '<' || pIn[i] == '>' || pIn[i] == 's' || pIn[i] == '/'
				|| pIn[i] == '#' || pIn[i] == '\n') {
			continue;
		} else if (pIn[i] == ' ') {
			pOut[nAdd++] = pIn[i];
		} else {
			pOut[nAdd++] = pIn[i];
		}
	}
}
