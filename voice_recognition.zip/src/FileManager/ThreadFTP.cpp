/*
 * ThreadFTP.cpp
 *
 *  Created on: 2016. 7. 27.
 *      Author: cosamo01
 */

#include <ThreadFTP.h>
#include <CFile.h>

void ThreadFTP::work(){
	sgprintf(DEBUG, "ThreadFTP::run(%d)", tid());
	//////////////////////////////////////////////////////////////////////////////////////
	//              setting for  UDP port connect       				//
	////////////////////////////////////////////////////////////////////////////////////

	int con_no;
	int addrlen;
	sockaddr_in serv_addr;
	sockaddr_in clnt_addr;
	char temp[125];

	//udp port number write
	sprintf(temp, "%d\n", n_udp_port);
	write(n_clnt_no, temp , strlen(temp));
	sgprintf(DEBUG, "ThreadFTP::work(%d) send port num : %d", tid(), n_udp_port) ;

	sock = socket(AF_INET, SOCK_DGRAM, 0);

	bzero(&serv_addr, sizeof(serv_addr));
	serv_addr.sin_family=AF_INET;
	serv_addr.sin_port=htons(n_udp_port);
	serv_addr.sin_addr.s_addr=htonl(INADDR_ANY);

	if((con_no = bind(sock, (sockaddr*)&serv_addr, sizeof(serv_addr)))==-1)
		sgprintf(DEBUG, "ThreadFTP::work(%d) fail to call bind()", tid()) ;

	addrlen=sizeof(clnt_addr);

	/////////////////////////////////////////////////////////////////////////////////////////
	//                setting for voice recognition             //
	///////////////////////////////////////////////////////////////////////////////////////

	int nFrameLength = 320 ;
	int n_frame_max = nFrameLength*sizeof(short) ;
	int n_frame_len = 0 ;
	int n_buf_pcm_max = 8000 * 60 * 30 ;

	p_child = SG::getLaserManager()->pop() ;

	p_frame = new unsigned char[n_frame_max] ;
	memset(p_frame, 0x00, n_frame_max) ;

	p_voice = new CBuffer(n_buf_pcm_max, CBuffer::TYPE_BYTE, CBuffer::LENGTH_AUTOINCREASE) ;

	string s_text = "" ;

	int n_status = 0 ;
	bool b_stt = false ;

	while (b_run) {
		memset(p_frame, 0x00, n_frame_max) ;

		sgprintf(DEBUG, "ThreadWorker::work(%d) voice frame reiceive start - UDP PORT : %d", tid(),n_udp_port) ;
		/////////////////////////////////////////////////////////////////////////////
		//           Get voice frame from the client                //
		/////////////////////////////////////////////////////////////////////////////

		if((con_no=recvfrom(sock, p_frame, n_frame_max, 0, (sockaddr*)&clnt_addr, (socklen_t*)&addrlen)) == -1){
			sgprintf(DEBUG, "ThreadWorker::work(%d) UDP receive error ", tid()) ;
			break;
		} else {
			/////////////////////////////////////////////////////////////////////////////
			//             save voice except start and end              //
			/////////////////////////////////////////////////////////////////////////////

			sgprintf(DEBUG, "ThreadFTP::work(%d) PCM Frame info : %d/%d", tid(), con_no, n_frame_max) ;

			int n_epd;

			if((	n_frame_len = con_no) < 640){
				b_stt = true ;
			}else{
				p_voice->fnAdd(p_frame, n_frame_len) ;
				n_epd = p_child->getEPD((short *)p_frame, n_frame_len/2, false) ;
				sgprintf(DEBUG, "ThreadFTP::work(%d) EPD : %d", tid(), n_epd) ;

				//1 : speak start , 2 : speaking , 3 : speak end
				if (n_epd > 0) {
					//save voice frame
					n_status = 1 ;
				}
				// -1 : silent
				else {
					// if lt is not first silent
					if (n_status > 0) {
						p_child->resetFrontEndEPD() ;

						sgprintf(DEBUG, "ThreadFTP::work(%d) exit : %d", tid(), n_epd) ;

					}
				}
			}

			/////////////////////////////////////////////////////////////////////////////
			//             get STT & make and save file                 //
			/////////////////////////////////////////////////////////////////////////////
			if (b_stt) {

				string file_name = SG::getCFile()->savefile(p_voice);
				sgprintf(INFO, "ThreadFTP::work(%d) - SAVE WAV AND PCM FILE: %s", tid(), file_name.c_str()) ;

				file_name += "\r\n";
				write(n_clnt_no, file_name.c_str() , file_name.length());

				b_stt_flag = true;
				s_text = p_child->getSTT((short *)p_voice->buf, p_voice->size()/2) ;
				s_text = FN::toUTF8((char *)s_text.c_str()) ;
				s_text = FN::trim(s_text);
				if(s_text.length()==0)
					s_text = "fail";
				b_stt_flag = false;

				s_text += "\r\n";
				write(n_clnt_no, s_text.c_str() , s_text.length());
				sgprintf(INFO, "ThreadFTP::work(%d) STT result : %s", tid(), s_text.c_str()) ;

				b_stt = false ;
				n_status = 0 ;

				break ;
			}
		}
	}
	SG::getLaserManager()->push(p_child);
	p_child = NULL;
}
