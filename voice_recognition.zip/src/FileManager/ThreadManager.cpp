/*
 * ThreadManager.cpp
 *
 *  Created on: 2016. 7. 13.
 *      Author: moyakk
 */

#include <ThreadManager.h>

#include <CSG.h>
#include <CSGUTIL.h>

void ThreadManager::work() {
	sgprintf(DEBUG, "ThreadManager::run(%d)", tid());

	if (p_db) {
		p_db->fnGetConnection();
	}

	    ///////////////////////////////////////////////////////////////////
	 //               TCP connect setting                //
	///////////////////////////////////////////////////////////////////

	int n_tid = 0;
	int con_no = 0;
	int sock;
	int udp_port = SG::conf()->g_tcpip.n_udp_port_start;

	memset(&serv_addr, 0, sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	serv_addr.sin_port = htons(12345);

	if ((sock = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
		sgprintf(ERROR, "ThreadManager::fail to call socket()");
	}

	//연결이 끊기면 바로 소켓 닫기
	struct linger soLinger;
	int rn = sizeof(int);
	rn = sizeof(soLinger);
	getsockopt(sock, SOL_SOCKET, SO_LINGER, &soLinger, (socklen_t *)&rn);
	soLinger.l_onoff = true;
	soLinger.l_linger = 0;
	setsockopt(sock, SOL_SOCKET, SO_LINGER, &soLinger, sizeof(soLinger));


	if (bind(sock, (struct sockaddr *) &serv_addr,
			sizeof(struct sockaddr_in)) == -1) {
		sgprintf(ERROR, "ThreadManager::fail to call bind()");
	}

	if (listen(sock, 5) == -1) {
		sgprintf(ERROR, "ThreadManager::fail to call listen()");
	}

	clnt_addr_size = sizeof(clnt_addr);


	   ////////////////////////////////////////////////////////////////////
	 //        wait client & make a threadWorker         //
	///////////////////////////////////////////////////////////////////
	while (b_run) {

		//prevent tid overflow
		if (n_tid > n_tid_max)
			n_tid = 1;

		// udp port number initialization
		if(udp_port > SG::conf()->g_tcpip.n_udp_port_end)
			udp_port = SG::conf()->g_tcpip.n_udp_port_start ;

		//remove finished threads
		while (true) {
			if (!pop())
				break;
		}

		//wait a client
		if((con_no = accept(sock, (struct sockaddr *) &clnt_addr,(socklen_t *) &clnt_addr_size))==-1){
			sgprintf(ERROR, "ThreadManager::work(%d) fail to call accept()", tid());
		}

		//check the max value of client queue
		if (threadq.size() > n_queue_max) {
			sgprintf(ERROR, "ThreadManager::work(%d) the clients queue is full", tid());
			close(con_no);
			continue;
		}

		//(n_tid : thread number , con_no : client number , udp_port : udp port number for voice transmission)
		ThreadWorker *cthread = new ThreadWorker(++n_tid, con_no, udp_port++,threadq);
		cthread->start();
	}
	close(sock);
}

bool ThreadManager::pop() {
    	///////////////////////////////////////////////////////////////////
	 //            remove finished threads               //
	///////////////////////////////////////////////////////////////////
	bool b_pop = false;
	int n_queue_size = threadq.size();
	for (int i = 0; i < n_queue_size; i++) {
		CThreadQueue *cthread = threadq.getAt(i);
		if (!cthread->isOn()) {
			int temp_id = cthread->tid();
			cthread->join();
			delete cthread;
			b_pop = true;
			printf(" = manager - Remove Thread [t%d] \n", temp_id);
			break;
		}
	}
	return b_pop;
}

