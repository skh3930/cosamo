/*
 * ThreadWorker.cpp
 *
 *  Created on: 2016. 7. 13.
 *      Author: moyakk
 */

#include <CLaserManager.h>
#include "ThreadWorker.h"

void ThreadWorker::stop() {
	sgprintf(DEBUG, "ThreadWorker::stop(%d)", tid()) ;
}

void ThreadWorker::work() {
	sgprintf(DEBUG, "ThreadWorker::work(%d)", tid()) ;

	char buf[10] ;

	p_threadFTP = new ThreadFTP(tid(), n_clnt_no, n_udp_port);
	p_threadFTP->start();

	while(b_run){
		if(read(n_clnt_no, buf, sizeof(buf)) == 0){
			delete p_threadFTP ;
			p_threadFTP = NULL ;
			break ;
		}
	}

	close(n_clnt_no);

}

