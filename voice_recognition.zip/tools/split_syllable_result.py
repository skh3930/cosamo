#!/usr/bin/env python
# -*- coding: cp949 -*-
# 

import sys, string, re
from curses import *
import pdb

if len(sys.argv) == 3:
	inFN, outFN = sys.argv[1:3]
else:
	print "Usage: python split_syllable_result.py in-result out-result"
	sys.exit(1)

inFN2 = 'tools/split.txt'

out = file(outFN,'w')

outFN2 = '%s.org' %outFN
out2 = file(outFN2,'w')


def make_sylA(word):
	word_len = len(word)
	cc = 0
	sylA = []
	while cc < word_len:
		ch = word[cc]
		if ch.isdigit() == 1:
			ch = 'dd_%s' %ch
			sylA.append(ch)
			cc += 1
		elif ch.isalpha() == 1:
			sylA.append(ch)
			cc += 1
		else:
			syl = word[cc:cc+2]
			sylA.append(syl)
			cc += 2
#	print '%s' %string.join(sylA,' ')
	return sylA

mapA = {}
for line in file(inFN2):
	line = string.strip(line)
	if '=' not in line:
		continue
	if '###' in line:
		continue

	itemA = line.split('=')
	word_org = itemA[0]
	word_tar = itemA[1]
	word_org = string.strip(word_org)
	word_tar = string.strip(word_tar)
	mapA[word_org] = word_tar



for line in file(inFN):
	line = string.strip(line)
	
	if 'MLF' in line:
		print>>out,line
		print>>out2,line
	elif 'MFCC' in line or '.rec' in line or '.lab' in line or 'mfcc' in line or 'pcm' in line or 'raw ' in line or 'wav' in line or '.SUP' in line or '.sup' in line:
		print>>out,line
		print>>out2,line
	elif 'SENT' in line or '<s>' in line or '</s>' in line or '<eps>' in line:
		#continue
		#print>>out,line
		print>>out,'<s>'
		print>>out2,'<s>'
	elif line == '.':
		print>>out,line
		print>>out2,line
	elif line == '///':
		print>>out,line
		print>>out2,line
	else:
		itemA = line.split()
		if len(itemA) == 4:
			st = itemA[0]
			et = itemA[1]
			word = itemA[2]
			score = itemA[3]
		else:
			st = et = score = 0
			word = line

		word = word.lower()
		
		if word == '#':
			continue
		elif '#' in word:
			word = re.sub('#','',word)
			
		#word = re.sub('5\.1','������',word)
		word = re.sub('\?','',word)
		word = re.sub('\?','',word)
		word = re.sub('\!','',word)
		word = re.sub('\!','',word)
		#word = re.sub('\.','',word)
		word = re.sub('\,','',word)
		word = re.sub('\,','',word)
		word = re.sub('\~','',word)

		if word in mapA:
			out_word = mapA[word]
			tmpA = out_word.split()
			if len(tmpA) == 1:
				print>>out2,out_word
				sylA = make_sylA(out_word)
				for ss in sylA:
					print>>out,ss
			else:
				for ww in tmpA:
					print>>out2,ww
					sylA = make_sylA(ww)
					for ss in sylA:
						print>>out,ss
		else:
			if word[0].isdigit() == 1:
				print>>out2,'dd_%s' %word
			else:
				print>>out2,word
			if word == 'name_filler' or word == 'unknown_filler':
				print>>out,word
			else:
				sylA = make_sylA(word)
				for ss in sylA:
					print>>out,ss
