//============================================================================
// Name        : icanspeak.cpp
// Author      : suhyun
// Version     : 0.1
// Description :
//============================================================================

#include <string>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <math.h>
#include <CMain.h>

#include "CSystemResource.h"

CMain *p_main ;

void sigHandler(int n_signo) {
	sgprintf(INFO, "sigHandler() - Signal Catched - %d", n_signo) ;
	if (p_main) {
		p_main->stop() ;
	}
}

int main() {
	sgprintf(INFO, "----- > COSAMO-ICIP > START ! > -----") ;

	signal(SIGINT, sigHandler) ;
	fnSystemConfig() ;

	p_main = NULL ;
	if (!p_main) {
		p_main = new CMain(1) ;
		p_main->start() ;
	}

	while (1) {
		if (p_main) {
			if (!p_main->isRun()) {
				p_main->join() ;
				delete p_main ;
				p_main = NULL ;
				break ;
			}
		}
	}
	sgprintf(INFO, "----- > COSAMO-ICIP > FINISH ! > -----") ;
	return 0 ;
}
