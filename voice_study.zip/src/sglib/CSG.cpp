/*
 * CSG.cpp
 *
 *  Created on: Apr 18, 2016
 *      Author: moyakk
 */

#include <CSG.h>
#include <CConfiguration.h>
#include <CLog.h>
////////////////////////////////////////////////////////////
////
////	CConfiguration
////

CConfiguration *SG::p_conf = NULL ;
CConfiguration *SG::conf() {
	if (!p_conf) {
		sgprintf(DEBUG, "SG::conf() - Load Configuration from File") ;
		p_conf = new CConfiguration("icanspeak.conf") ;
		p_conf->fnPrintConfigData() ;
	}
	return p_conf ;
}


////////////////////////////////////////////////////////////
////
////	CLog
////

CLog *SG::p_sgout = NULL ;
CLog *SG::getsgout() {
	if (p_sgout == NULL) {
		CConfiguration *t_conf = new CConfiguration("icanspeak.conf") ;
		p_sgout = new CLog("sgout", t_conf->g_module.s_root) ;
		p_sgout->setLogLevel(t_conf->g_module.n_log_info, t_conf->g_module.n_log_debug, t_conf->g_module.n_log_error) ;
		delete t_conf ;
	}
	return p_sgout ;
}
