/*
 * CMain.cpp
 *
 *  Created on: jul 20, 2016
 *      Author: suhyun
 */

#include <CMain.h>
#include <TBENGSCHEDULE.h>

void CMain::work() {
	sgprintf(DEBUG, "CMain::work() - start \n");
	while (b_run) {
		this->workRealtime();
		sleep(60);
	}
}

void CMain::workPrepare() {
	sgprintf(DEBUG, "CMain::workPrepare() - start \n");
	if (p_conf == NULL) {
		p_conf = SG::conf();
	}
	if (p_db == NULL) {
		p_db = new CDBMySQL();
		p_db->fnGetConnection();
	}
	if (p_log == NULL) {
		p_log = new TBENGSTUDYLOG(p_db);
	}
}

void CMain::workRealtime() {
	sgprintf(DEBUG, "CLearning::workRealtime() - start \n");
	string today_date = FN::yyyymmddhhmmss(1);
	string s_error = "";
	string b_success;

	//스케쥴 확인
	if (p_db) {
		string s_query = "";
		s_query += (" SELECT * ");
		s_query += (" FROM TB_ENG_SCHEDULE ");
		s_query += (" WHERE (1=1)");
		s_query += (" AND TS_ACTIVATION = 1 ");
		s_query += (" ORDER BY TS_STUDY_TIME ASC ");
		s_query += (" LIMIT 0, 1 ");
		s_query += (" ; ");

		MYSQL_RES* mRS = p_db->fnGetResultSet(s_query);

		if (mRS) {
			if (p_db->fnGetRows(mRS) > 0) {
				TBENGSCHEDULE *tb = new TBENGSCHEDULE();
				tb->getData(mRS);

				//현시간에 수행해야하는 엔진 학습이 있다면,
				//if ((strcmp(today_date.substr(0,16).c_str(), tb->ts_study_time.substr(0,16).c_str()) == 0 )
				//&&
				if(!FN::equal(tb->TS_STUDY_TIME, "NULL")) {
					sgprintf(DEBUG, "CMain::CMain() - now : %s , study time : %s", today_date.substr(0,16).c_str(),tb->TS_STUDY_TIME.substr(0,16).c_str()) ;

					//이미 학습 완료 된 버전이라면
					if(isLearned(tb->TS_VERSION)){
						//현재 사용중인 버전을 비사용으로 변경
						if (p_db) {
							sgprintf(DEBUG, "CLearning::startLearning() - Clear useyn statement in TB_ENG_VER\n");
							s_query = "";
							s_query += (" UPDATE TB_ENG_VER");
							s_query += (" SET");
							s_query += (" E_USEYN = 2,");
							s_query += (" E_TIME = \'" + FN::yyyymmddhhmmss(1) + "\'");
							s_query += (" WHERE (1=1)");
							s_query += (" AND E_USEYN = 1");
							s_query += (" ; ");
							p_db->fnExeQuery(s_query);

							s_query = "";
							s_query += (" UPDATE TB_ENG_VER");
							s_query += (" SET");
							s_query += (" E_USEYN = 1,");
							s_query += (" E_TIME = \'" + FN::yyyymmddhhmmss(1) + "\'");
							s_query += (" WHERE (1=1)");
							s_query += (" AND E_VERSION ="+ tb->TS_VERSION);
							s_query += (" ; ");
							p_db->fnExeQuery(s_query);

							p_log->insertEngineLog("학습 완료 엔진 상태 변경",  tb->TS_VERSION, "", "1");
						}
						b_success = "1";
					}
					//아직 학습되지 않은 버전이라면
					else{

						CLearning *p_learning = new CLearning(tb->TS_VERSION, p_db, p_log) ;

						//엔진 학습 수행
						s_error = p_learning->runLearning();

						sgprintf(ERROR, "CLearning::startLearning() - learning error - %s ////%s \n", s_error.c_str() ,s_error.substr(0,5).c_str());

						//엔진 학습 실패 시
						if(strcmp(s_error.substr(0,5).c_str(), "error") == 0){
							b_success = "2";
						}else {
							b_success = "1";
						}

						delete p_learning ;
						p_learning = NULL ;
					}

					//엔진 스케쥴 업데이트
					if (p_db) {

						string s_query = "";
						s_query += (" UPDATE TB_ENG_SCHEDULE ");
						s_query += (" SET ts_activation = 2");
						s_query += (" ,ts_status = "+ b_success);

						if(b_success == "2")
							s_query += (" ,ts_etc = \'" + s_error + "\' ");
						else
							s_query += (" ,ts_etc = \'\' ");
						s_query += (" WHERE (1=1)");
						s_query += (" AND ts_no =" + tb->TS_NO+" ");
						s_query += (" ; ");
						p_db->fnExeQuery(s_query);
					}
				}

				delete tb;
				tb = NULL;
			}
		}
		mysql_free_result(mRS);
		mRS = NULL;
	}

}

bool CMain::isLearned(string s_version){
	int n_cnt = 0;
	if (p_db) {
		sgprintf(DEBUG, "CLearning::startLearning() - Check Engine version info from TB_ENG_VER \n");
		string s_query = "";
		s_query += (" SELECT *");
		s_query += (" FROM TB_ENG_VER");
		s_query += (" WHERE E_VERSION =" + s_version +"");
		s_query += (" ;");

		MYSQL_RES* mRS = p_db->fnGetResultSet(s_query);
		TBENGVER *tb = new TBENGVER();
		tb->getData(mRS);

		if (mRS) {
			n_cnt = p_db->fnGetRows(mRS);
		}

		if(n_cnt == 0 || tb->E_STATE == "2")
			return false;
		else if(tb->E_STATE == "1"){
			return true;
		}

		return false;
	}
}

