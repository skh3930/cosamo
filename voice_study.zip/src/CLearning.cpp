/*
 * CLearning.cpp
 *
 *  Created on: 2016. 7. 29.
 *      Author: cosamo01
 */

#include <CLearning.h>
#include <db/TBMYSQL.h>

string CLearning::runLearning() {
	sgprintf(DEBUG, "CLearning::startLearning()- start \n");

	ThreadQueue<TBENGSTUDYLIST*> files;
	string s_list_path = "";
	string s_binary_path = "";

	while (true) {

		/////////////////////////////////////////////////////////////////////////////
		//             prepare engine learning              //
		/////////////////////////////////////////////////////////////////////////////

		files = getFileList();

		if (s_error_code.length() != 0) {
			sgprintf(ERROR,
					"CLearning::startLearning()- return error from getFileList() function \n");

			s_error_code = "error: a file is not exist - " + s_error_code;
			break;
		}

		if ((s_list_path = makeTxtFile(files)) == "") {
			sgprintf(ERROR,
					"CLearning::startLearning()- return error from makeTxtFile(filelist) function \n");

			files.removeAll();
			s_error_code = "error: can't make text file";
			break;
		}

		/////////////////////////////////////////////////////////////////////////////
		//                 run engine learning               //
		/////////////////////////////////////////////////////////////////////////////

		string s_cmd = "";

		s_cmd = "";
		s_cmd += ("/home/cosamo01/release.dnn_env_am/run.am.sh "
				+ SG::conf()->g_record.s_list_am_path + s_list_path);

		try {
			int cmd_ret = FN::runCommand(s_cmd.c_str());
			sgprintf(DEBUG,
					"CLearning::startLearning() - Engine learning -am success - %d \n",
					cmd_ret);
		} catch (exception & e) {
			sgprintf(ERROR,
					"CLearning::startLearning() - Engine learning- am fail - %s \n",
					s_cmd.c_str());
			files.removeAll();

			s_error_code = "error : learning is fail - am";
			break;
		}

		s_cmd = "";
		s_cmd += ("/home/cosamo01/release.dnn_env_lm/run.lm.sh "
				+ SG::conf()->g_record.s_list_lm_path + s_list_path);

		try {
			int cmd_ret = FN::runCommand(s_cmd.c_str());
			sgprintf(DEBUG,
					"CLearning::startLearning() - Engine learning -lm success - %d \n",
					cmd_ret);
		} catch (exception & e) {
			sgprintf(ERROR,
					"CLearning::startLearning() - Engine learning -lm fail - %s \n",
					s_cmd.c_str());
			files.removeAll();

			s_error_code = "error : learning is fail - lm";
			break;
		}

		/////////////////////////////////////////////////////////////////////////////////////////
		//       move engine learning result(binary files)          //
		////////////////////////////////////////////////////////////////////////////////////////

		s_binary_path = FN::yyyymmddhhmmsss(0);

		//바이너리 파일 복사
		s_cmd = "";
		s_cmd += ("cp -r " + SG::conf()->g_record.s_binary_path + "default "
				+ SG::conf()->g_record.s_binary_path + s_binary_path);

		try {
			int cmd_ret = FN::runCommand(s_cmd.c_str());
			sgprintf(DEBUG,
					"CLearning::startLearning() - Engine folder copy success - %d \n",
					cmd_ret);
		} catch (exception & e) {
			sgprintf(ERROR,
					"CLearning::startLearning() - Engine folder copy fail - %s \n",
					s_cmd.c_str());
			files.removeAll();

			s_error_code = "error: learning file copy fail";
			break;
		}

		s_cmd = "";
		s_cmd += ("cp -f " + SG::conf()->g_laser.s_am_img_path
				+ "final.dnn.adapt.0.0001.0.bin "
				+ SG::conf()->g_record.s_binary_path + s_binary_path
				+ "/stt_images_dnn/final.dnn.adapt.bin");

		try {
			int cmd_ret = FN::runCommand(s_cmd.c_str());
			sgprintf(DEBUG,
					"CLearning::startLearning() - Engine file copy success - %d \n",
					cmd_ret);
		} catch (exception & e) {
			sgprintf(ERROR,
					"CLearning::startLearning() - Engine file copy fail - %s \n",
					s_cmd.c_str());
			files.removeAll();

			s_error_code = "error: learning file copy fail";
			break;
		}

		s_cmd = "";
		s_cmd += ("cp -f " + SG::conf()->g_laser.s_am_img_path
				+ "final.dnn.prior.bin.adapted "
				+ SG::conf()->g_record.s_binary_path + s_binary_path
				+ "/stt_images_dnn/final.dnn.prior.bin");

		try {
			int cmd_ret = FN::runCommand(s_cmd.c_str());
			sgprintf(DEBUG,
					"CLearning::startLearning() - Engine file copy success - %d \n",
					cmd_ret);
		} catch (exception & e) {
			sgprintf(ERROR,
					"CLearning::startLearning() - Engine file copy fail - %s \n",
					s_cmd.c_str());
			files.removeAll();

			s_error_code = "error: learning file copy fail";
			break;
		}

		s_cmd = "";
		s_cmd += ("cp -f " + SG::conf()->g_laser.s_lm_img_path
				+ "stt_release.sfsm.bin " + SG::conf()->g_record.s_binary_path
				+ s_binary_path + "/stt_images_dnn/stt_release.sfsm.bin");

		try {
			int cmd_ret = FN::runCommand(s_cmd.c_str());
			sgprintf(DEBUG,
					"CLearning::startLearning() - Engine file copy success - %d \n",
					cmd_ret);
		} catch (exception & e) {
			sgprintf(ERROR,
					"CLearning::startLearning() - Engine file copy fail - %s \n",
					s_cmd.c_str());
			files.removeAll();

			s_error_code = "error: learning file copy fail";
			break;
		}

		s_cmd = "";
		s_cmd += ("cp -f " + SG::conf()->g_laser.s_lm_img_path
				+ "stt_release.sym.bin " + SG::conf()->g_record.s_binary_path
				+ s_binary_path + "/stt_images_dnn/stt_release.sym.bin");

		try {
			int cmd_ret = FN::runCommand(s_cmd.c_str());
			sgprintf(DEBUG,
					"CLearning::startLearning() - Engine file copy success - %d \n",
					cmd_ret);
		} catch (exception & e) {
			sgprintf(ERROR,
					"CLearning::startLearning() - Engine file copy fail - %s \n",
					s_cmd.c_str());
			files.removeAll();

			s_error_code = "error: binary file moving fail";
			break;
		}

		break;
	}


	///////////////////////////////////////////////////////////////////////////////////////
	//                   update result into DB                 //
	//////////////////////////////////////////////////////////////////////////////////////

	if (strcmp(s_error_code.substr(0, 5).c_str(), "error") == 0) {
		UpdateLearningResult(false, s_binary_path, files);
	} else {
		UpdateLearningResult(true, s_binary_path, files);
	}

	return s_error_code;
}

void CLearning::UpdateLearningResult(bool b_result, string s_binary_path,
		ThreadQueue<TBENGSTUDYLIST*> files) {
	int n_cnt = 0;

	//엔진 정보 있는지 확인
	if (p_db) {
		sgprintf(DEBUG,
				"CLearning::startLearning() - Check Engine version info from TB_ENG_VER \n");
		string s_query = "";
		s_query += (" SELECT *");
		s_query += (" FROM TB_ENG_VER");
		s_query += (" WHERE E_VERSION =" + n_ts_version + "");
		s_query += (" ;");

		MYSQL_RES* mRS = p_db->fnGetResultSet(s_query);

		if (mRS) {
			n_cnt = p_db->fnGetRows(mRS);
		}
	}

	//현재 사용중이던 버전 비사용으로 변경
	if (b_result) {
		if (p_db) {
			sgprintf(DEBUG,
					"CLearning::startLearning() - Clear useyn statement in TB_ENG_VER\n");
			string s_query = "";
			s_query += (" UPDATE TB_ENG_VER");
			s_query += (" SET");
			s_query += (" E_USEYN = 2,");
			s_query += (" E_TIME = \'" + FN::yyyymmddhhmmss(1) + "\'");
			s_query += (" WHERE (1=1)");
			s_query += (" AND E_USEYN = 1");
			s_query += (" ; ");
			p_db->fnExeQuery(s_query);
		}
	}

	//엔진 정보가 없다면 새로 입력
	if (n_cnt == 0) {
		sgprintf(DEBUG,
				"CLearning::startLearning() - Insert Engine version info into TB_ENG_VER \n");
		if (p_db) {
			string s_query = "";
			s_query += (" INSERT INTO TB_ENG_VER");
			s_query += (" (E_VERSION,");
			s_query += (" E_FILE_PATH,");
			s_query += (" E_STATE,");
			s_query += (" E_USEYN,");
			s_query += (" E_TIME)");
			s_query += (" VALUES ");
			s_query += (" (\'" + n_ts_version + "\', ");

			if (b_result) {
				s_query += (" \'" + s_binary_path + "\', ");
				s_query += (" 1, ");
				s_query += (" 1, ");
			} else {
				s_query += (" \'\', ");
				s_query += (" 0, ");
				s_query += (" 2, ");
			}

			s_query += (" \'" + FN::yyyymmddhhmmss(1) + "\') ");
			s_query += (" ;");

			p_db->fnExeQuery(s_query);
		}
	} else { //엔진 정보가 있다면 업데이트
		sgprintf(DEBUG,
				"CLearning::startLearning() - Update Engine version info in TB_ENG_VER \n");
		if (p_db) {
			string s_query = "";
			s_query += (" UPDATE TB_ENG_VER");
			s_query += (" SET");
			if (b_result) {
				s_query += (" FILE_PATH = \'" + s_binary_path + "\', ");
				s_query += (" E_STATE = 1,");
				s_query += (" E_STATE = 1,");
			} else {
				s_query += (" E_FILE_PATH = \'\', ");
				s_query += (" E_STATE = 0,");
				s_query += (" E_STATE = 2,");
			}
			s_query += (" E_TIME = \'" + FN::yyyymmddhhmmss(1) + "\' ");
			s_query += (" WHERE (1=1)");
			s_query += (" AND E_VERSION =" + n_ts_version + " ");
			s_query += (" ; ");
			p_db->fnExeQuery(s_query);
		}
	}

	int F_FLAG;

	if (b_result) {
		p_log->insertEngineLog("학습성공",  n_ts_version, s_binary_path, "1");
		F_FLAG = 1;
	} else {
		p_log->insertEngineLog("학습실패",  n_ts_version, "", "2");
		F_FLAG = 2;
	}

	//음성 리스트 업데이트
	for (int i = 0; i < files.size(); i++) {
		string s_query = "";
		s_query += (" UPDATE TB_ENG_STUDY_LIST");
		s_query += (" SET");
		s_query += (" F_FLAG = " + FN::itos(F_FLAG) + "");
		s_query += (" WHERE (1=1)");
		s_query += (" AND ESL_NO =" + files.getAt(i)->ESL_NO + " ");
		s_query += (" ; ");
		p_db->fnExeQuery(s_query);
	}

	for (int i = 0; i < files.size(); i++) {
		string s_query = "";
		s_query += (" INSERT INTO TB_ANS_SOUND");
		s_query += (" (SND_FLAG,");
		s_query += (" S_NO,");
		s_query += (" E_VERSION,");
		s_query += (" SND_PATH,");
		s_query += (" SND_TIME)");
		s_query += (" VALUES");
		s_query += (" (" + files.getAt(i)->S_FLAG + ",");
		s_query += (" " + files.getAt(i)->S_NO + ",");
		s_query += (" " + n_ts_version + ",");
		s_query += (" \'" + files.getAt(i)->ES_SOUND_PATH + "\',");
		s_query += (" \"" + FN::yyyymmddhhmmss(1) + "\")");
		s_query += (" ; ");
		p_db->fnExeQuery(s_query);
	}
}

ThreadQueue<TBENGSTUDYLIST*> CLearning::getFileList() {
	sgprintf(DEBUG, "CLearning::getFileList() - start \n");

	ThreadQueue<TBENGSTUDYLIST*> files;

	/////////////////////////////////////////////////////////////////////////////////////////
	//                   get sound file path                    //
	////////////////////////////////////////////////////////////////////////////////////////

	//get correct answer path
	string s_query = "";
	s_query += (" SELECT * ");
	s_query += (" FROM TB_SOUND_PATH ");
	s_query += (" WHERE (1=1)");
	s_query += (" AND SP_FLAG = 2 ");
	s_query += (" LIMIT 0, 1 ");
	s_query += (" ; ");
	MYSQL_RES* mRS = p_db->fnGetResultSet(s_query);
	if (mRS) {
		if (p_db->fnGetRows(mRS) > 0) {
			TBSOUNDPATH *tb = new TBSOUNDPATH();
			tb->getData(mRS);

			if ((tb->SP_PATH.length() > 0) && !FN::equal(tb->SP_PATH, "NULL")) {

				string s_find = "/icanspeak" ;
				string s_root = "/home/cosamo01/" ;
				string s_input = tb->SP_PATH ;
				int n_pos = -1 ;
				if ((n_pos = s_input.find(s_find)) != (signed int)s_input.npos) {
					s_input = s_root + s_input.substr(n_pos) ;
				}

				s_ca_path = s_input;

				sgprintf(DEBUG,
										"CLearning::getFileList() - correct sound path : %s \n",
										s_ca_path);
			}
			delete tb;
			tb = NULL;
		}
	}

	//get wrong answer path
	s_query = "";
	s_query += (" SELECT * ");
	s_query += (" FROM TB_SOUND_PATH ");
	s_query += (" WHERE (1=1)");
	s_query += (" AND SP_FLAG = 3 ");
	s_query += (" LIMIT 0, 1 ");
	s_query += (" ; ");
	mRS = p_db->fnGetResultSet(s_query);
	if (mRS) {
		if (p_db->fnGetRows(mRS) > 0) {
			TBSOUNDPATH *tb = new TBSOUNDPATH();
			tb->getData(mRS);
			if ((tb->SP_PATH.length() > 0) && !FN::equal(tb->SP_PATH, "NULL")) {

				string s_find = "/icanspeak" ;
				string s_root = "/home/cosamo01/" ;
				string s_input = tb->SP_PATH ;
				int n_pos = -1 ;
				if ((n_pos = s_input.find(s_find)) != (signed int)s_input.npos) {
					s_input = s_root + s_input.substr(n_pos) ;
				}

				s_wa_path = s_input;

				sgprintf(DEBUG,
									"CLearning::getFileList() - wrong sound path : %s \n",
									s_wa_path);

			}
			delete tb;
			tb = NULL;
		}
	}

	/////////////////////////////////////////////////////////////////////////////////////////
	//              get file name and add file list             //
	///////////////////////////////////////////////////////////////////////////////////////

	int n_cnt = 0;
	s_query = "";
	s_query += (" SELECT * ");
	s_query += (" FROM TB_ENG_STUDY_LIST");
	s_query += (" WHERE (1=1)");
	s_query += (" AND E_VERSION =" + n_ts_version + " ");
	s_query += (" ; ");
	if (p_db) {
		mRS = p_db->fnGetResultSet(s_query);
		if (mRS) {
			if ((n_cnt = p_db->fnGetRows(mRS)) > 0) {
				for (int i = 0; i < n_cnt; i++) {
					TBENGSTUDYLIST *tb = new TBENGSTUDYLIST();
					tb->getData(mRS);

					string s_path = "";
					if (tb->S_FLAG == "1")
						s_path += s_ca_path;
					else if (tb->S_FLAG == "2")
						s_path += s_wa_path;

					string root = s_path;
					s_path += tb->ES_SOUND_PATH;

					/////////////////////////////////////////////////////////////////////////////////////////
					//                    convert wav to pcm                    //
					///////////////////////////////////////////////////////////////////////////////////////

					string s_find = "." ;
					string s_file_type = "";
					string s_file_name = "";
					string s_file_full_name = tb->ES_SOUND_PATH;
					int n_pos = -1 ;
					if ((n_pos = s_file_full_name.find(s_find)) != (signed int)s_file_full_name.npos) {
						s_file_type = s_file_full_name.substr(n_pos+1) ;
						s_file_name = s_file_full_name.substr(0, n_pos);
					}

					if(s_file_type == "wav"){
						string s_cmd = "" ;
						s_cmd += (" ffmpeg -nostats -loglevel 0 -y -i") ;
						s_cmd += (" "+s_path+"") ;
						s_cmd += (" -f s16le -ar 8000 -acodec pcm_s16le");
						s_cmd += (" "+ root + s_file_name + ".pcm");
						printf(" WAV to PCM : %s", s_cmd.c_str()) ;
						try {
							int cmd_ret = FN::runCommand(s_cmd.c_str()) ;
							sgprintf(DEBUG, "CFile::savefile() - Convert WAV to PCM - %d \n", cmd_ret) ;
						} catch (exception & e) {
							sgprintf(ERROR, "CFile::savefile() - Fail to Convert WAV to PCM- %s \n", s_cmd.c_str()) ;
							s_error_code = "CFile::savefile() - Fail to Convert WAV to PCM- %s \n", s_cmd.c_str();
						}

						tb->ES_SOUND_PATH = s_file_name + ".pcm";
					}

					files.add(tb);

					/////////////////////////////////////////////////////////////////////////////////////////
					//                    check file existence                  //
					///////////////////////////////////////////////////////////////////////////////////////

					if (isExists(s_path)) {
						sgprintf(DEBUG,
								"CLearning::getFileList() - success to add File list[%s] \n",
								s_path.c_str());

					} else if(	tb->ES_SOUND_PATH.length() == 0 || tb->ES_SOUND_PATH.length() == NULL){
						sgprintf(DEBUG, "CLearning::getFileList() - just language learning \n");
					}else {
						sgprintf(ERROR,
								"CLearning::getFileList() - fail to add File list[%s] \n",
								tb->ES_SOUND_PATH.c_str());
						s_error_code += (tb->ES_SOUND_PATH + ", ");
					}
				}
			}
		}
	}
	return files;
}

string CLearning::makeTxtFile(ThreadQueue<TBENGSTUDYLIST*> files) {
	sgprintf(DEBUG, "CDir::writeTxtFile() - start \n");

	///////////////////////////////////////////////////////////////////////////////
	//                make list text file                //
	//////////////////////////////////////////////////////////////////////////////

	string s_std_pron = "";
	string s_save_path = "";
	string s_file_name = "";

	string s_file_path = FN::yyyymmddhhmmss(0) + "_" + n_ts_version + ".txt";
	FILE *fp_am = NULL;
	FILE *fp_lm = NULL;

	if ((fp_am = fopen(
			(SG::conf()->g_record.s_list_am_path + s_file_path).c_str(), "a+"))
			!= NULL) {
		sgprintf(DEBUG,
				"CDir::writeTxtFile() - Text List am file write success- OK %s\n",
				s_file_path.c_str());
	} else {
		sgprintf(ERROR,
				"CDir::writeTxtFile() - Text List am file write fail .. %s\n",
				s_file_path.c_str());
		s_error_code = "error : text list am file make fail";
		return "";
	}

	if ((fp_lm = fopen(
			(SG::conf()->g_record.s_list_lm_path + s_file_path).c_str(), "a+"))
			!= NULL) {
		sgprintf(DEBUG,
				"CDir::writeTxtFile() - Text List lm file write success- OK %s\n",
				s_file_path.c_str());
	} else {
		sgprintf(ERROR,
				"CDir::writeTxtFile() - Text List lm file write fail .. %s\n",
				s_file_path.c_str());
		s_error_code = "error : text list lm file make fail";
		return "";
	}

	/////////////////////////////////////////////////////////////////////////////
	//      get the text of sound and make txt file     //
	/////////////////////////////////////////////////////////////////////////////

	for (int i = 0; i < files.size(); i++) {
		//correct answer
		if (files.getAt(i)->S_FLAG == "1") {
			string s_query = "";
			s_query += (" SELECT * ");
			s_query += (" FROM TB_CA_INFO ");
			s_query += (" WHERE (1=1)");
			s_query += (" AND CA_NO = " + files.getAt(i)->S_NO);
			s_query += (" LIMIT 0, 1 ");
			s_query += (" ; ");
			MYSQL_RES* mRS = p_db->fnGetResultSet(s_query);
			if (mRS) {
				if (p_db->fnGetRows(mRS) > 0) {
					TBCAINFO *tb = new TBCAINFO();
					tb->getData(mRS);

					if ((tb->CA_STD_PRON.length() > 0)
							&& !FN::equal(tb->CA_STD_PRON, "NULL")) {
						sgprintf(DEBUG,
								"CLearning::MakeTxtFile() - correct answer txt : %s",
								tb->CA_STD_PRON.c_str());
						s_save_path = s_ca_path;
						s_std_pron = tb->CA_STD_PRON;

						if (files.getAt(i)->ES_SOUND_PATH.length() == 0) {
							s_file_name = "";
						} else {
							s_file_name = getFileName(
									files.getAt(i)->ES_SOUND_PATH) + ".txt";
						}
					}
					delete tb;
					tb = NULL;
				}
			}
			//wrong answer
		} else if (files.getAt(i)->S_FLAG == "2") {
			string s_query = "";
			s_query += (" SELECT * ");
			s_query += (" FROM TB_WA_INFO ");
			s_query += (" WHERE (1=1)");
			s_query += (" AND WA_NO = " + files.getAt(i)->S_NO);
			s_query += (" LIMIT 0, 1 ");
			s_query += (" ; ");
			MYSQL_RES* mRS = p_db->fnGetResultSet(s_query);
			if (mRS) {
				if (p_db->fnGetRows(mRS) > 0) {
					TBWAINFO *tb = new TBWAINFO();
					tb->getData(mRS);

					if ((tb->WA_TXT.length() > 0)
							&& !FN::equal(tb->WA_TXT, "NULL")) {
						sgprintf(DEBUG,
								"CLearning::MakeTxtFile() - wrong answer txt : %s",
								tb->WA_TXT.c_str());

						s_save_path = s_wa_path;
						s_std_pron = tb->WA_TXT;

						if (files.getAt(i)->ES_SOUND_PATH.length() == 0) {
							s_file_name = "";
						} else {
							s_file_name = getFileName(
									files.getAt(i)->ES_SOUND_PATH) + ".txt";
						}
					}
					delete tb;
					tb = NULL;
				}
			}
		}

		if (s_file_name.length() != 0) {
			//make text file for sound learning
			if (!writeTxtFile(s_save_path + s_file_name, s_std_pron)) {
				sgprintf(ERROR,
						"CLearning::MakeTxtFile() - file write fail so the file is removed");
				s_error_code = "error : file write fail so the file is removed";
				return "";
			}
			//add file path at list
			fprintf(fp_am, "%s\n",
					(s_save_path + files.getAt(i)->ES_SOUND_PATH).c_str());
		}

		if (files.getAt(i)->S_FLAG == "1") {
			for (int i = 0; i < 3; i++)
				fprintf(fp_lm, "%s\n", s_std_pron.c_str());
		} else {
			fprintf(fp_lm, "%s\n", s_std_pron.c_str());
		}

	}
	fclose(fp_lm);
	fclose(fp_am);

	return s_file_path;
}
