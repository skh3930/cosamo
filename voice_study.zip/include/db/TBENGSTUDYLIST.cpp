#include <TBENGSTUDYLIST.h>

TBENGSTUDYLIST::TBENGSTUDYLIST() {
	//DB 관련 변수 초기화
	ESL_TABLE = "TB_ENG_STUDY_LIST";
	ESL_NO = "";
	E_VERSION = "";
	ES_SOUND_PATH = "";
	S_FLAG = "";
	S_NO = "";
	F_FLAG = "";
	ESL_TIME = "";
}

TBENGSTUDYLIST::~TBENGSTUDYLIST() {
	//
}

void TBENGSTUDYLIST::getData(MYSQL_RES *mRS) {
	// Get Size
	int n_col = getCols(mRS);

	// Get Field Name
	MYSQL_FIELD *mFS = mysql_fetch_fields(mRS);
	// Get Data
	MYSQL_ROW mRow;
	if ((mRow = mysql_fetch_row(mRS))) {
		for (int i = 0; i < n_col; i++) {
			string s_field = (mRow[i]) ? mRow[i] : "NULL";
			if (FN::equal(mFS[i].name, "ESL_NO")) {
				ESL_NO = s_field;
			} else if (FN::equal(mFS[i].name, "E_VERSION")) {
				E_VERSION = s_field;
			} else if (FN::equal(mFS[i].name, "ES_SOUND_PATH")) {
				ES_SOUND_PATH = s_field;
			} else if (FN::equal(mFS[i].name, "S_FLAG")) {
				S_FLAG = s_field;
			} else if (FN::equal(mFS[i].name, "S_NO")) {
				S_NO = s_field;
			} else if (FN::equal(mFS[i].name, "F_FLAG")) {
				F_FLAG = s_field;
			} else if (FN::equal(mFS[i].name, "ESL_TIME")) {
				ESL_TIME = s_field;
			} else {
				printf(" = %s - Skip Field \'%s = %s\'\n", ESL_TABLE.c_str(),
						mFS[i].name, s_field.c_str());
			}
		}
	}
	printf("\n");
}


