#include <TBENGSCHEDULE.h>

TBENGSCHEDULE::TBENGSCHEDULE() {
	//DB 관련 변수 초기화
	TS_TABLE = "TB_ENG_SCHEDULE" ;
	TS_NO = "";
	TS_STUDY_TIME = "";
	TS_VERSION = "";
	TS_APPLY_TIME = "";
	TS_STATUS = "";
	TS_ACTIVATION = "";
	TS_TIME = "";
	TS_ETC = "" ;
}

TBENGSCHEDULE::~TBENGSCHEDULE() {
	//
}

void TBENGSCHEDULE::getData(MYSQL_RES *mRS) {
	// Get Size
	int n_row = getRows(mRS);
	int n_col = getCols(mRS);
	if (n_row > 1) {
		printf(" = %s - multiple-rows .. (%d)\n", TS_TABLE.c_str(), n_row);
	}
	// Get Field Name
	MYSQL_FIELD *mFS = mysql_fetch_fields(mRS);
	// Get Data
	MYSQL_ROW mRow;
	while ((mRow = mysql_fetch_row(mRS))) {
		for (int i = 0; i < n_col; i++) {
			string s_field = (mRow[i]) ? mRow[i] : "NULL";
			if (FN::equal(mFS[i].name, "TS_NO")) {
				TS_NO = s_field;
			} else if (FN::equal(mFS[i].name, "TS_STUDY_TIME")) {
				TS_STUDY_TIME = s_field;
			} else if (FN::equal(mFS[i].name, "TS_VERSION")) {
				TS_VERSION = s_field;
			} else if (FN::equal(mFS[i].name, "TS_APPLY_TIME")) {
				TS_APPLY_TIME = s_field;
			} else if (FN::equal(mFS[i].name, "TS_STATUS")) {
				TS_STATUS = s_field;
			} else if (FN::equal(mFS[i].name, "TS_ACTIVATION")) {
				TS_ACTIVATION = s_field;
			} else if (FN::equal(mFS[i].name, "TS_TIME")) {
				TS_TIME = s_field;
			} else if (FN::equal(mFS[i].name, "TS_ETC")) {
				TS_ETC = s_field;
			} else {
				printf(" = %s - Skip Field \'%s = %s\'\n", TS_TABLE.c_str(),
						mFS[i].name, s_field.c_str());
			}
		}
	}
	printf("\n");
}

