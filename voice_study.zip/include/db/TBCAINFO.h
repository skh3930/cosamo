/*
 * TBCAINFO.h
 *
 *  Created on: jul 20, 2016
 *      Author: suhyun
 */

#ifndef INCLUDE_DB_TBCAINFO_H_
#define INCLUDE_DB_TBCAINFO_H_

#include <TBMYSQL.h>

class TBCAINFO : public TBMYSQL {
public:
	string CA_TABLE ;
	string CA_NO ;
	string CA_TXT ;
	string CA_TYPE ;
	string CA_CATEGORY ;
	string CA_FB ;
	string CA_FB_PATH ;
	string CA_STD_PRON ;
	string CA_SOUND_PATH ;
	string CA_D_FLAG ;
	string CA_TIME ;
	string CA_ACCURACY ;

	TBCAINFO();
	virtual ~TBCAINFO();

	void getData(MYSQL_RES *mRS) ;

};

#endif /* INCLUDE_DB_TBCAINFO_H_ */
