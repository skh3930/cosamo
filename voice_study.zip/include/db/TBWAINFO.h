/*
 * TBWAINFO.h
 *
 *  Created on: jul 20, 2016
 *      Author: suhyun
 */

#ifndef INCLUDE_DB_TBWAINFO_H_
#define INCLUDE_DB_TBWAINFO_H_

#include <TBMYSQL.h>

class TBWAINFO : public TBMYSQL {
public:
	string WA_TABLE ;
	string WA_NO ;
	string WA_TXT ;
	string CA_NO ;
	string WA_ACCURACY ;
	string WA_D_FLAG ;
	string WA_TIME ;

	TBWAINFO();
	virtual ~TBWAINFO();

	void getData(MYSQL_RES *mRS) ;

};

#endif /* INCLUDE_DB_TBWAINFO_H_ */
