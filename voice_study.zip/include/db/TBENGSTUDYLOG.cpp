#include <TBENGSTUDYLOG.h>

TBENGSTUDYLOG::TBENGSTUDYLOG(CDBMySQL *_db) {
	p_db = _db;
	//DB 관련 변수 초기화
	EL_TABLE = "TB_ENG_STUDY_LOG";
	EL_NO = "";
	EL_STATUS = "";
	EL_FILE_PATH = "";
	EL_ACTIVATION = "";
	EL_VERSION = "";
	EL_TIME = "";
}

TBENGSTUDYLOG::~TBENGSTUDYLOG() {
	//
}

void TBENGSTUDYLOG::insertEngineLog(string status, string version, string file_path, string activation){

	string s_query = "";
	s_query += (" INSERT INTO TB_ENG_STUDY_LOG");
	s_query += (" (EL_STATUS");
	s_query += (" ,EL_FILE_PATH");
	s_query += (" ,EL_ACTIVATION");
	s_query += (" ,EL_VERSION)");
	s_query += (" VALUES");
	s_query += (" ( \'" + status + "\'");
	s_query += (" ,\'" + file_path + "\'");
	s_query += (" ,"+ activation + "");
	s_query += (" ,"+ version+ ")");
	s_query += (" ; ");

	p_db->fnExeQuery(s_query);
}
