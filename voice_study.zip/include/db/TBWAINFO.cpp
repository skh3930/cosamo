#include <TBWAINFO.h>

TBWAINFO::TBWAINFO() {
	//DB 관련 변수 초기화
	WA_TABLE = "TB_WA_INFO";
	WA_NO = "" ;
	WA_TXT = "";
	CA_NO = "";
	WA_ACCURACY = "";
	WA_D_FLAG = "";
	WA_TIME = "";
}

TBWAINFO::~TBWAINFO() {
	//
}

void TBWAINFO::getData(MYSQL_RES *mRS) {
	// Get Size
	int n_row = getRows(mRS);
	int n_col = getCols(mRS);
	if (n_row > 1) {
		printf(" = %s - multiple-rows .. (%d)\n", WA_TABLE.c_str(), n_row);
	}
	// Get Field Name
	MYSQL_FIELD *mFS = mysql_fetch_fields(mRS);
	// Get Data
	MYSQL_ROW mRow;
	while ((mRow = mysql_fetch_row(mRS))) {
		for (int i = 0; i < n_col; i++) {
			string s_field = (mRow[i]) ? mRow[i] : "NULL";
			if (FN::equal(mFS[i].name, "WA_NO")) {
				WA_NO = s_field;
			} else if (FN::equal(mFS[i].name, "WA_TXT")) {
				WA_TXT = s_field;
			} else if (FN::equal(mFS[i].name, "CA_NO")) {
				CA_NO = s_field;
			} else if (FN::equal(mFS[i].name, "WA_ACCURACY")) {
				WA_ACCURACY = s_field;
			} else if (FN::equal(mFS[i].name, "WA_D_FLAG")) {
				WA_D_FLAG = s_field;
			} else if (FN::equal(mFS[i].name, "WA_TIME")) {
				WA_TIME = s_field;
			} else {
				printf(" = %s - Skip Field \'%s = %s\'\n", WA_TABLE.c_str(),
						mFS[i].name, s_field.c_str());
			}
		}
	}
	printf("\n");
}
