#include <TBSOUNDPATH.h>

TBSOUNDPATH::TBSOUNDPATH() {
	//DB 관련 변수 초기화
	SP_TABLE = "TB_SOUND_PATH" ;
	SP_NO = "" ;
	SP_FLAG = "" ;
	SP_PATH = "" ;
	SP_TIME = "" ;
}

TBSOUNDPATH::~TBSOUNDPATH() {
	//
}

void TBSOUNDPATH::getData(MYSQL_RES *mRS) {
	// Get Size
	int n_row = getRows(mRS);
	int n_col = getCols(mRS);
	if (n_row > 1) {
		printf(" = %s - multiple-rows .. (%d)\n", SP_TABLE.c_str(), n_row);
	}
	// Get Field Name
	MYSQL_FIELD *mFS = mysql_fetch_fields(mRS);
	// Get Data
	MYSQL_ROW mRow;
	while ((mRow = mysql_fetch_row(mRS))) {
		for (int i = 0; i < n_col; i++) {
			string s_field = (mRow[i]) ? mRow[i] : "NULL";
			if (FN::equal(mFS[i].name, "SP_NO")) {
				SP_NO = s_field;
			} else if (FN::equal(mFS[i].name, "SP_FLAG")) {
				SP_FLAG = s_field;
			} else if (FN::equal(mFS[i].name, "SP_PATH")) {
				SP_PATH = s_field;
			} else if (FN::equal(mFS[i].name, "SP_TIME")) {
				SP_TIME = s_field;
			} else {
				printf(" = %s - Skip Field \'%s = %s\'\n", SP_TABLE.c_str(),
						mFS[i].name, s_field.c_str());
			}
		}
	}
	printf("\n");
}


