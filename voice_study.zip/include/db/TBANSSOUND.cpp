#include <TBANSSOUND.h>

TBANSSOUND::TBANSSOUND() {
	//DB 관련 변수 초기화
	SND_TABLE = "TB_ANS_SOUND";
	SND_NO = "" ;
	SND_FLAG ="" ;
	S_NO = "" ;
	E_VERSION = "" ;
	SND_PATH = "" ;
	SND_TIME = "" ;
	PS_PLAG = "" ;
}

TBANSSOUND::~TBANSSOUND() {
	//
}

void TBANSSOUND::getData(MYSQL_RES *mRS) {
	// Get Size
	int n_col = getCols(mRS);

	// Get Field Name
	MYSQL_FIELD *mFS = mysql_fetch_fields(mRS);
	// Get Data
	MYSQL_ROW mRow;
	if ((mRow = mysql_fetch_row(mRS))) {
		for (int i = 0; i < n_col; i++) {
			string s_field = (mRow[i]) ? mRow[i] : "NULL";
			if (FN::equal(mFS[i].name, "SND_NO")) {
				SND_NO = s_field;
			} else if (FN::equal(mFS[i].name, "SND_FLAG")) {
				SND_FLAG = s_field;
			} else if (FN::equal(mFS[i].name, "S_NO")) {
				S_NO = s_field;
			} else if (FN::equal(mFS[i].name, "E_VERSION")) {
				E_VERSION = s_field;
			} else if (FN::equal(mFS[i].name, "SND_PATH")) {
				SND_PATH = s_field;
			} else if (FN::equal(mFS[i].name, "SND_TIME")) {
				SND_TIME = s_field;
			} else if (FN::equal(mFS[i].name, "PS_FLAG")) {
				PS_PLAG = s_field;
			} else {
				printf(" = %s - Skip Field \'%s = %s\'\n", SND_TABLE.c_str(),
						mFS[i].name, s_field.c_str());
			}
		}
	}
	printf("\n");
}
