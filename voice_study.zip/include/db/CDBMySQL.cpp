/*
 * CDBMySQL.cpp
 *
 *  Created on: Sep 25, 2015
 *      Author: solugate
 */

#include <db/CDBMySQL.h>

void CDBMySQL::fnSetConnectionInfo() {
	b_set = true ;
	CConfiguration *conf = SG::conf() ;
	conn_info.s_ip = conf->g_db.s_host ;
	conn_info.n_port = conf->g_db.n_port ;
	conn_info.s_name = conf->g_db.s_name ;
	conn_info.s_id = conf->g_db.s_id ;
	conn_info.s_pw = conf->g_db.s_pw ;
}

void CDBMySQL::fnSetConnectionInfo(CConfiguration *conf) {
	b_set = true ;
	conn_info.s_ip = conf->g_db.s_host ;
	conn_info.n_port = conf->g_db.n_port ;
	conn_info.s_name = conf->g_db.s_name ;
	conn_info.s_id = conf->g_db.s_id ;
	conn_info.s_pw = conf->g_db.s_pw ;
}

void CDBMySQL::fnSetConnectionInfo(string s_ip, int n_port, string s_name, string s_id, string s_pw) {
	b_set = true ;
	conn_info.s_ip = s_ip ;
	conn_info.n_port = n_port ;
	conn_info.s_name = s_name ;
	conn_info.s_id = s_id ;
	conn_info.s_pw = s_pw ;
}

bool CDBMySQL::fnGetConnection() {
	if (!b_set) {
		this->fnSetConnectionInfo() ;
	}
	bool b_ret = false ;
	try {
		if (!mConnection) {
			mysql_init(&conn) ;
			unsigned int timeout = 300 ;
			mysql_options(&conn, MYSQL_OPT_CONNECT_TIMEOUT, (const char *)&timeout) ;
			mysql_options(&conn, MYSQL_SET_CHARSET_NAME, "utf8") ;
		    mConnection = mysql_real_connect(&conn, conn_info.s_ip.c_str(), conn_info.s_id.c_str(), conn_info.s_pw.c_str(), conn_info.s_name.c_str(), conn_info.n_port, (char *)NULL, 0) ;
		    if (mConnection) {
		    	b_ret = true ;
		    } else {
		        sgprintf(ERROR, "CDBMySQL::fnGetConnection() - %s", mysql_error(&conn)) ;
		    }
		}
	} catch (exception &e) {
		b_ret = false ;
	}
	return b_ret ;
}

bool CDBMySQL::fnDisConnection() {
	bool b_ret = false ;
	try {
		if (mConnection) {
			mysql_close(&conn) ;
			mConnection = NULL ;
			b_ret = true ;
			sgprintf(INFO, "CDBMySQL::fnDisConnection() - OK !") ;
		}
	} catch (exception & e) {
		sgprintf(ERROR, "CDBMySQL::fnDisConnection() - Fail ..") ;
		b_ret = false ;
	}
	return b_ret ;
}

MYSQL_RES* CDBMySQL::fnGetResultSet(string s_query) {
	pthread_mutex_lock(&m_mutex) ;
	MYSQL_RES* mRS = NULL ;
	if (mConnection) {
		bool b_work_next = false ;
		int n_retry = 3 ;
		int query_stat = -1 ;
		while (!b_work_next && n_retry > 0) {
			try {
				query_stat = mysql_query(&conn, s_query.c_str()) ;
				if (query_stat == 0) {
					sgprintf(INFO, "CDBMySQL::fnGetResultSet() - %s", s_query.c_str()) ;
					b_work_next = true ;
				} else {
					sgprintf(ERROR, "CDBMySQL::fnGetResultSet() - %s\n%s", mysql_error(&conn), s_query.c_str()) ;
					n_retry-- ;
					fnDisConnection() ;
					usleep(10) ;
					fnGetConnection() ;
					usleep(10) ;
				}
				if (b_work_next) {
					mRS = mysql_store_result(&conn) ;
					if (!mRS) {
						sgprintf(ERROR, "CDBMySQL::fnGetResultSet() - Empty Result Set .. \n(%s)%s", mysql_error(&conn), s_query.c_str()) ;
					}
				}
			} catch (exception &e) {
				mRS = NULL ;
			}
		}
	}
	pthread_mutex_unlock(&m_mutex) ;
	return mRS ;
}

bool CDBMySQL::fnExeQuery(string s_query) {
	pthread_mutex_lock(&m_mutex) ;
	bool b_ret = false;
	int n_retry = 3 ;
	int query_stat = -1 ;
	while (!b_ret && n_retry > 0) {
		try {
			query_stat = mysql_query(&conn, s_query.c_str());
			if (query_stat == 0) {
				sgprintf(INFO, "CDBMySQL::fnExeQuery() - %s", s_query.c_str()) ;
				b_ret = true;
			} else {
				sgprintf(ERROR, "CDBMySQL::fnExeQuery() - Error(%s)\n(%d)%s", mysql_error(&conn), n_retry, s_query.c_str()) ;
				n_retry-- ;
				fnDisConnection() ;
				usleep(10) ;
				fnGetConnection() ;
				usleep(10) ;
			}
		} catch (exception &e) {
			sgprintf(ERROR, "CDBMySQL::fnExeQuery() - Exception(%s)", e.what());
			b_ret = false;
		}
	}
	pthread_mutex_unlock(&m_mutex) ;
    return b_ret;
}

long CDBMySQL::fnGetRows(MYSQL_RES* mRS) {
	long l_ret = 0;
	try {
		l_ret = mysql_num_rows(mRS);
	} catch (exception &e) {
		sgprintf(ERROR, "CDBMySQL::fnGetRows() - Error(%s)", mysql_error(&conn));
		l_ret = 0;
	}
	return l_ret;
}

int CDBMySQL::fnGetCols(MYSQL_RES* mRS) {
	int n_ret = 0;
	try {
		n_ret = mysql_num_fields(mRS);
	} catch (exception &e) {
		sgprintf(ERROR, "CDBMySQL::fnGetCols() - Error(%s)", mysql_error(&conn));
		n_ret = 0;
	}
	return n_ret;
}

MYSQL_FIELD* CDBMySQL::fnGetFields(MYSQL_RES* mRS) {
	MYSQL_FIELD* mField = NULL;
	try {
		mField = mysql_fetch_fields(mRS);
	} catch (exception &e) {
		sgprintf(ERROR, "CDBMySQL::fnGetFields() - Error(%s)", mysql_error(&conn));
		mField = NULL;
	}
	return mField;
}
