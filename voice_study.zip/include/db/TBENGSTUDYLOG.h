/*
 * TBENGSCHEDULE.h
 *
 *  Created on: jul 20, 2016
 *      Author: suhyun
 */

#ifndef INCLUDE_DB_TBENGSTUDYLOG_H_
#define INCLUDE_DB_TBENGSTUDYLOG_H_

#include <TBMYSQL.h>
#include <CDBMySQL.h>

class TBENGSTUDYLOG : public TBMYSQL {
public:
	string EL_TABLE ;
	string EL_NO ;
	string EL_STATUS ;
	string EL_FILE_PATH ;
	string EL_ACTIVATION ;
	string EL_VERSION ;
	string EL_TIME ;
	CDBMySQL *p_db ;

	TBENGSTUDYLOG(CDBMySQL *_db);
	virtual ~TBENGSTUDYLOG();

	void insertEngineLog(string s_flag, string version, string file_path, string activation) ;
};

#endif /* INCLUDE_DB_TBENGSTUDYLOG_H_ */
