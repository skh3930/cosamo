/*
 * TBENGSCHEDULE.h
 *
 *  Created on: jul 20, 2016
 *      Author: suhyun
 */

#ifndef INCLUDE_DB_TBANSSOUND_H_
#define INCLUDE_DB_TBANSSOUND_H_

#include <TBMYSQL.h>

class TBANSSOUND : public TBMYSQL {
public:
	string SND_TABLE ;
	string SND_NO ;
	string SND_FLAG ;
	string S_NO ;
	string E_VERSION ;
	string SND_PATH ;
	string SND_TIME ;
	string PS_PLAG ;

	TBANSSOUND();
	virtual ~TBANSSOUND();

	void getData(MYSQL_RES *mRS) ;
};

#endif /* INCLUDE_DB_TBEANSSOUND_H_ */
