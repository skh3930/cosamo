/*
 * TBENGSCHEDULE.h
 *
 *  Created on: jul 20, 2016
 *      Author: suhyun
 */

#ifndef INCLUDE_DB_TBENGSCHEDULE_H_
#define INCLUDE_DB_TBENGSCHEDULE_H_

#include <TBMYSQL.h>

class TBENGSCHEDULE : public TBMYSQL {
public:
	string TS_TABLE ;
	string TS_NO ;
	string TS_STUDY_TIME ;
	string TS_VERSION ;
	string TS_APPLY_TIME ;
	string TS_STATUS ;
	string TS_ACTIVATION ;
	string TS_TIME ;
	string TS_ETC ;

	TBENGSCHEDULE();
	virtual ~TBENGSCHEDULE();

	void getData(MYSQL_RES *mRS) ;
};

#endif /* INCLUDE_DB_TBENGSCHEDULE_H_ */
