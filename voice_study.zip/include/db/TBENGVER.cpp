#include <TBENGVER.h>

TBENGVER::TBENGVER() {
	//DB 관련 변수 초기화
	E_TABLE = "TB_ENG_VER";
	E_VERSION = "" ;
	E_FILE_PATH = "" ;
	E_STATE = "" ;
	E_USEYN = "" ;
	E_TIME = "" ;
}

TBENGVER::~TBENGVER() {
	//
}

void TBENGVER::getData(MYSQL_RES *mRS) {
	// Get Size
	int n_row = getRows(mRS);
	int n_col = getCols(mRS);
	if (n_row > 1) {
		printf(" = %s - multiple-rows .. (%d)\n", E_TABLE.c_str(), n_row);
	}
	// Get Field Name
	MYSQL_FIELD *mFS = mysql_fetch_fields(mRS);
	// Get Data
	MYSQL_ROW mRow;
	while ((mRow = mysql_fetch_row(mRS))) {
		for (int i = 0; i < n_col; i++) {
			string s_field = (mRow[i]) ? mRow[i] : "NULL";
			if (FN::equal(mFS[i].name, "E_VERSION")) {
				E_VERSION = s_field;
			} else if (FN::equal(mFS[i].name, "E_FILE_PATH")) {
				E_FILE_PATH = s_field;
			} else if (FN::equal(mFS[i].name, "E_STATE")) {
				E_STATE = s_field;
			} else if (FN::equal(mFS[i].name, "E_USEYN")) {
				E_USEYN = s_field;
			} else if (FN::equal(mFS[i].name, "E_TIME")) {
				E_TIME = s_field;
			} else {
				printf(" = %s - Skip Field \'%s = %s\'\n", E_TABLE.c_str(),
						mFS[i].name, s_field.c_str());
			}
		}
	}
	printf("\n");
}
