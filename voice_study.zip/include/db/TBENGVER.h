/*
 * TBENGVER.h
 *
 *  Created on: jul 20, 2016
 *      Author: suhyun
 */

#ifndef INCLUDE_DB_TBENGVER_H_
#define INCLUDE_DB_TBENGVER_H_

#include <TBMYSQL.h>

class TBENGVER : public TBMYSQL {
public:
	string E_TABLE ;
	string E_VERSION ;
	string E_FILE_PATH ;
	string E_STATE ;
	string E_USEYN ;
	string E_TIME ;

	TBENGVER();
	virtual ~TBENGVER();

	void getData(MYSQL_RES *mRS) ;
};

#endif /* INCLUDE_DB_TBENGVER_H_ */
