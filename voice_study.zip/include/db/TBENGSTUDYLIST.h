/*
 * TBENGSCHEDULE.h
 *
 *  Created on: jul 20, 2016
 *      Author: suhyun
 */

#ifndef INCLUDE_DB_TBENGSTUDYLIST_H_
#define INCLUDE_DB_TBENGSTUDYLIST_H_

#include <TBMYSQL.h>

class TBENGSTUDYLIST: public TBMYSQL {
public:
	string ESL_TABLE;
	string ESL_NO;
	string E_VERSION;
	string ES_SOUND_PATH;
	string S_FLAG;
	string S_NO;
	string F_FLAG;
	string ESL_TIME;

	TBENGSTUDYLIST();virtual ~TBENGSTUDYLIST();

	void getData(MYSQL_RES *mRS);
};

#endif /* INCLUDE_DB_TBENGSTUDYLIST_H_ */
