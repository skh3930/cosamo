#include <TBCAINFO.h>

TBCAINFO::TBCAINFO() {
	//DB 관련 변수 초기화
	CA_TABLE = "TB_CA_INFO";
	CA_NO = "" ;
	CA_TXT = "";
	CA_TYPE = "";
	CA_CATEGORY = "";
	CA_FB = "";
	CA_FB_PATH = "";
	CA_STD_PRON = "";
	CA_SOUND_PATH = "";
	CA_D_FLAG = "";
	CA_TIME = "";
	CA_ACCURACY = "";
}

TBCAINFO::~TBCAINFO() {
	//
}

void TBCAINFO::getData(MYSQL_RES *mRS) {
	// Get Size
	int n_row = getRows(mRS);
	int n_col = getCols(mRS);
	if (n_row > 1) {
		printf(" = %s - multiple-rows .. (%d)\n", CA_TABLE.c_str(), n_row);
	}
	// Get Field Name
	MYSQL_FIELD *mFS = mysql_fetch_fields(mRS);
	// Get Data
	MYSQL_ROW mRow;
	while ((mRow = mysql_fetch_row(mRS))) {
		for (int i = 0; i < n_col; i++) {
			string s_field = (mRow[i]) ? mRow[i] : "NULL";
			if (FN::equal(mFS[i].name, "CA_NO")) {
				CA_NO = s_field;
			} else if (FN::equal(mFS[i].name, "CA_TXT")) {
				CA_TXT = s_field;
			} else if (FN::equal(mFS[i].name, "CA_TYPE")) {
				CA_TYPE = s_field;
			} else if (FN::equal(mFS[i].name, "CA_CATEGORY")) {
				CA_CATEGORY = s_field;
			} else if (FN::equal(mFS[i].name, "CA_FB")) {
				CA_FB = s_field;
			} else if (FN::equal(mFS[i].name, "CA_FB_PATH")) {
				CA_FB_PATH = s_field;
			} else if (FN::equal(mFS[i].name, "CA_STD_PRON")) {
				CA_STD_PRON = s_field;
			} else if (FN::equal(mFS[i].name, "CA_SOUND_PATH")) {
				CA_SOUND_PATH = s_field;
			} else if (FN::equal(mFS[i].name, "CA_D_FLAG")) {
				CA_D_FLAG = s_field;
			} else if (FN::equal(mFS[i].name, "CA_TIME")) {
				CA_TIME = s_field;
			} else if (FN::equal(mFS[i].name, "CA_ACCURACY")) {
				CA_TIME = s_field;
			} else {
				printf(" = %s - Skip Field \'%s = %s\'\n", CA_TABLE.c_str(),
						mFS[i].name, s_field.c_str());
			}
		}
	}
	printf("\n");
}
