/*
 * CConvert.h
 *
 *  Created on: Jan 21, 2016
 *      Author: moyakk
 */

#ifndef SRC_CCONVERT_H_
#define SRC_CCONVERT_H_

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

using namespace std ;

class CConvert {

public:

	// Bit
	int getBit(unsigned char x, int n) {
		return (x & (1 << n)) >> n ;
	}
	void toBinary(unsigned char x) {
		int cnt = 8 * sizeof(unsigned char) ;
		printf("[") ;
		for (int i=(cnt-1); i>=0; i--) {
			printf("%d", getBit(x, i)) ;
		}
		printf("]\n") ;
	}

	// Hex
	string HexToDecStr(unsigned char hex) {
		char dec[5] ;
		sprintf(dec, "%d", hex) ;
		return dec ;
	}
	int HexToDec(unsigned char *hex, int len) {
		string s_input = "0x" ;
		for (int i=0; i<len; i++) {
			s_input += HexToStr(*(hex+i)) ;
		}
		int n_output =  (int)strtol(s_input.c_str(), NULL, 0) ;
		return n_output ;
	}
	string HexToDecStr(unsigned char *hex, int len) {
		char buf[10] ;
		sprintf(buf, "%d", HexToDec(hex, len)) ;
		string s_output = buf ;
		return s_output ;
	}
	string HexToStr(unsigned char hex) {
		char dec[5] ;
		sprintf(dec, "%02x", hex) ;
		return dec ;
	}
} ;

#endif /* SRC_CCONVERT_H_ */
