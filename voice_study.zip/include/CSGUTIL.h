/*
 * CSGSTD.h
 *
 *  Created on: Apr 18, 2016
 *      Author: moyakk
 */

#ifndef INCLUDE_CSGUTIL_H_
#define INCLUDE_CSGUTIL_H_

#include <iostream>
#include <sstream>

#include <algorithm>
#include <string>

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#include <math.h>
#include <time.h>
#include <sys/time.h>

#include <iconv.h>
#include <errno.h>

#include <stddef.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>

#define SHELL "/bin/sh"

using namespace std ;

class FN {

	////////////////////////////////////////////////////////////
	////
	////	static function | Common Utility
	////

public :

	static string yyyymmdd(int n_separator) {
		time_t rawtime ;
		time(&rawtime) ;
		tm* timeinfo = localtime(&rawtime) ;
		char buffer[20] ;
		if (n_separator == 0) {
			strftime(buffer, 20, "%Y%m%d", timeinfo) ;
		} else {
			strftime(buffer, 20, "%Y-%m-%d", timeinfo) ;
		}
		return buffer ;
	}

	static string yyyymmddhhmmss(int n_separator) {
		time_t rawtime ;
		time(&rawtime) ;
		tm* timeinfo = localtime(&rawtime) ;
		char buffer[20] ;
		if (n_separator == 0) {
			strftime(buffer, 20, "%Y%m%d%H%M%S", timeinfo) ;
		} else if (n_separator == 1) {
			strftime(buffer, 20, "%Y-%m-%d %H:%M:%S", timeinfo) ;
		} else if (n_separator == 2) {
			strftime(buffer, 20, "%Y%m%d_%H%M%S", timeinfo) ;
		} else {
			strftime(buffer, 20, "%Y-%m-%d %H:%M:%S", timeinfo) ;
		}
		return buffer ;
	}

	static string yyyymmddhhmmsss(int n_separator) {
		timeval curTime;
		gettimeofday(&curTime, NULL);
		int milli = curTime.tv_usec / 1000 ;

		time_t rawtime ;
		time(&rawtime) ;
		tm* timeinfo = localtime(&rawtime) ;
		char buffer[20] ;
		if (n_separator == 0) {
			strftime(buffer, 20, "%Y%m%d%H%M%S", timeinfo) ;
			sprintf(buffer, "%s%03d", buffer, milli) ;
		} else {
			strftime(buffer, 20, "%Y-%m-%d %H:%M:%S", timeinfo) ;
			if (milli < 10) {
				sprintf(buffer, "%s.00%d", buffer, milli) ;
			} else if (milli < 100) {
				sprintf(buffer, "%s.0%d", buffer, milli) ;
			} else {
				sprintf(buffer, "%s.%d", buffer, milli) ;
			}
		}
		return buffer ;
	}

	static string hhmmsss(int n_separator) {
		timeval curTime;
		gettimeofday(&curTime, NULL);
		int milli = curTime.tv_usec / 1000 ;

		time_t rawtime ;
		time(&rawtime) ;
		tm* timeinfo = localtime(&rawtime) ;
		char buffer[20] ;
		if (n_separator == 0) {
			strftime(buffer, 20, "%H%M%S", timeinfo) ;
			sprintf(buffer, "%s%d", buffer, milli) ;
		} else {
			strftime(buffer, 20, "%H:%M:%S", timeinfo) ;
			sprintf(buffer, "%s.%03d", buffer, milli) ;
		}
		return buffer ;
	}

	static string hhmmsss(timeval t_gap) {
		int n_hour = 0 ;
		int n_min = 0 ;
		int n_sec = 0 ;
		int n_msec = 0 ;

		char c_hour[2] ;
		char c_min[2] ;
		char c_sec[2]  ;
		char c_msec[3] ;

		n_sec = (int)t_gap.tv_sec ;
		n_msec = (int)(t_gap.tv_usec / 1000) ;

		n_hour = (int)(n_sec / 3600) ;
		n_sec -= (n_hour * 3600) ;

		n_min = (int)(n_sec / 60) ;
		n_sec -= (n_min * 60) ;

		sprintf(c_msec, "%03d", n_msec) ;
		sprintf(c_hour, "%02d", n_hour) ;
		sprintf(c_min, "%02d", n_min) ;
		sprintf(c_sec, "%02d", n_sec) ;

		string s_time = "" ;
		s_time += c_hour ;
		s_time += ":" ;
		s_time += c_min ;
		s_time += ":" ;
		s_time += c_sec ;
		s_time += "." ;
		s_time += c_msec ;

		return s_time ;
	}

	static string hhmmsss(int n_pos, int n_fs) {
		double f_dur = (double)n_pos / (double)n_fs ;
		double f_msec = modf(f_dur, &f_dur) ;

		int n_hour = 0 ;
		int n_min = 0 ;
		int n_sec = 0 ;
		int n_msec = 0 ;

		char c_hour[2] ;
		char c_min[2] ;
		char c_sec[2]  ;
		char c_msec[3] ;

		n_sec = (int)f_dur ;
		n_msec = (int)(f_msec * 1000) ;

		n_hour = (int)(n_sec / 3600) ;
		n_sec -= (n_hour * 3600) ;

		n_min = (int)(n_sec / 60) ;
		n_sec -= (n_min * 60) ;

		sprintf(c_msec, "%03d", n_msec) ;
		sprintf(c_hour, "%02d", n_hour) ;
		sprintf(c_min, "%02d", n_min) ;
		sprintf(c_sec, "%02d", n_sec) ;

		string s_time = "" ;
		s_time += c_hour ;
		s_time += ":" ;
		s_time += c_min ;
		s_time += ":" ;
		s_time += c_sec ;
		s_time += "." ;
		s_time += c_msec ;

		return s_time ;
	}

	static string rdate(int n_separator) {
		time_t rawtime ;
		time(&rawtime) ;
		tm* timeinfo = localtime(&rawtime) ;
		char buffer[20] ;
		if (n_separator == 0) {
			strftime(buffer, 20, "%Y%m%d", timeinfo) ;
		} else {
			strftime(buffer, 20, "%Y-%m-%d", timeinfo) ;
		}
		return buffer ;
	}

	static string rtime(int n_separator) {
		time_t rawtime ;
		time(&rawtime) ;
		tm* timeinfo = localtime(&rawtime) ;
		char buffer[20] ;
		if (n_separator == 0) {
			strftime(buffer, 20, "%H%M%S", timeinfo) ;
		} else {
			strftime(buffer, 20, "%H:%M:%S", timeinfo) ;
		}
		return buffer ;
	}

	static string trim(string s_input) {
		string s_output ;
		string s_space = " \t\r\n\v" ;
		s_output = s_input.erase(0, s_input.find_first_not_of(s_space)) ; // trim.Left
		s_output = s_input.erase(s_input.find_last_not_of(s_space)+1) ;   // trim.Right
		return s_output ;
	}

	static bool exists(string s_input, string s_find) {
		bool b_ret = false ;
		int n_pos = -1 ;
		if ((n_pos = s_input.find(s_find)) != (signed int)s_input.npos) {
			if (n_pos >= 0) {
				b_ret = true ;
			}
		}
		return b_ret ;
	}

	static bool equal(string s_input, string s_compare) {
		bool b_ret = false ;
		s_input = trim(s_input) ;
		s_compare = trim(s_compare) ;

		int n_input_len = s_input.length() ;
		int n_compare_len = s_compare.length() ;

		if (n_input_len == n_compare_len) {
			if (s_input.compare(s_compare) == 0) {
				b_ret = true ;
			}
		}
		return b_ret ;
	}

	static int stoi(string s_input) {
		int n_len = 255 ;
		int n_idx = 0 ;
		unsigned char *p_out ;
		p_out = new unsigned char[n_len] ;
		memset(p_out, 0x00, n_len) ;
		unsigned char *p_in ;
		unsigned char *p_in_org ;
		p_in = new unsigned char[n_len] ;
		p_in_org = p_in ;
		memset(p_in, 0x00, n_len) ;
		memcpy(p_in, s_input.c_str(), s_input.length()) ;
		while(*p_in) {
			if (isdigit(*p_in)) {
				memcpy(p_out+n_idx, p_in, 1) ;
				n_idx++ ;
			}
			*p_in++ ;
		}
		p_in = p_in_org ;
		int n_output = atoi((const char*)p_out) ;
		delete [] p_out ;
		delete [] p_in ;
		return n_output ;
	}

	static string itos(int n_input) {
		char c_out[255] ;
		sprintf(c_out, "%d", n_input) ;
		string s_output = c_out ;
		return c_out ;
	}

	static bool stob(string s_input) {
		bool b_output = false ;
		int n_input = 1 ;
		if (s_input.length() > 1) {
			if (equal(s_input, "true")) {
				n_input = 1 ;
			} else if (equal(s_input, "false")) {
				n_input = 0 ;
			}
		} else {
			n_input = stoi(s_input) ;
		}
		b_output = (n_input > 0)? true:false ;
		return b_output ;
	}

	static string btos(bool b_input) {
		string s_output = "" ;
		s_output = (b_input)? "true":"false" ;
		return s_output ;
	}

	static string tolower(string s_input) {
		string s_output = s_input ;
		transform(s_output.begin(), s_output.end(), s_output.begin(), ::tolower) ;
		return s_output ;
	}

	static string touppder(string s_input) {
		string s_output = s_input ;
		transform(s_output.begin(), s_output.end(), s_output.begin(), ::toupper) ;
		return s_output ;
	}

	static int replace(string *s_input, string s_before, string s_after) {
		int n_pos = -1 ;
		if ((n_pos = s_input->find(s_before)) != (signed int)s_input->npos) {
			if (n_pos >= 0) {
				s_input->erase(n_pos, s_before.length()) ;
				s_input->insert(n_pos, s_after) ;
			}
		}
		return n_pos ;
	}

	static string replace(string s_input, string s_before, string s_after) {
		string s_output = s_input ;
		int n_pos = -1 ;
		if ((n_pos = s_output.find(s_before)) != (signed int)s_output.npos) {
			if (n_pos >= 0) {
				s_output.erase(n_pos, s_before.length()) ;
				s_output.insert(n_pos, s_after) ;
			}
		}
		return s_output ;
	}

	static string replaceAll(string s_input, string s_before, string s_after) {
		string s_output = s_input ;
		int n_ret = 1 ;
		while(n_ret >= 0) {
			n_ret = replace(&s_output, s_before, s_after) ;
		}
		return s_output ;
	}

	static tm toDate(string s_input, string s_format) {
		////	Normalize Input
		string s_date = "" ;
		string s_type = "" ;
		if (s_input.length() > 0) {
			s_date = replaceAll(s_input, "-", "") ;
		}
		if (s_format.length() > 0) {
			s_type = replaceAll(s_format, "-", "") ;
		}
		////	Check Date Format
		int n_len = 8 ;
		if (s_type.length() > 0) {
			if (equal(s_type, "yyyymmdd")) {
				n_len = 8 ;
			} else if (equal(s_type, "yymmdd")) {
				n_len = 6 ;
			}
		}
		////	Get Date
		int year = 0 ;
		int month = 0 ;
		int day = 0 ;

		if (n_len == 8) {
			year = stoi(s_date.substr(0, 4)) ;
			month = stoi(s_date.substr(4, 2)) ;
			day = stoi(s_date.substr(6, 2)) ;
		} else {
			year = (2000 + stoi(s_date.substr(0, 2))) ;
			month = stoi(s_date.substr(2, 2)) ;
			day = stoi(s_date.substr(4, 2)) ;
		}
		////	prepare for tm
		if ((int)s_date.length() > n_len) {
			s_date = s_date.substr(0, n_len) ;
		}
		if ((int)s_type.length() > n_len) {
			s_type = s_type.substr(0, n_len) ;
		}
		if (year >= 1900) { year -= 1900 ; }
		if (month > 0) { month -= 1 ; }
		////	make tm
		struct tm date ;
		date.tm_year = year ;
		date.tm_mon = month ;
		date.tm_mday = day ;
		date.tm_hour = 0 ;
		date.tm_min = 0 ;
		date.tm_sec = 0 ;
		date.tm_isdst = 0 ; // Summer Time Y/N
		return date ;
	}

	static int getDateDuration(string s_input, string s_format) {
		struct tm date1 ;
		struct tm *date2 ;
		time_t tm1 ;
		time_t tm2 ;
		//
		time(&tm2) ;
		date1 = toDate(s_input, s_format) ;
		date2 = localtime(&tm2) ;
		date2->tm_hour = 0 ;
		date2->tm_min = 0 ;
		date2->tm_sec = 0 ;
		date2->tm_isdst = 0 ;
		//
		tm1 = mktime(&date1) ;
		tm2 = mktime(date2) ;
		double d_diff = difftime(tm2, tm1) ;
		int n_diff_days = d_diff / (60*60*24) ;
		return n_diff_days ;
	}

	static string getUniqueKey() {
		time_t rawtime ;
		time(&rawtime) ;

		tm* timeinfo ;
		timeinfo = localtime(&rawtime) ;

		char buffer[80] ;
		strftime(buffer, 80, "%y%m%d%H%M%S", timeinfo) ;
		int n_buffer_len = (int)strlen(buffer) ;
		memset(buffer+n_buffer_len, 0x00, 80-n_buffer_len) ;

		char ukey[20] ;
		struct timespec ts ;
		clock_gettime(CLOCK_MONOTONIC, &ts) ; // Get Nano-Sec
		sprintf(ukey, "%0.f", (double)ts.tv_nsec) ;
		int n_ukey_len = (int)strlen(ukey) ;

		memset(buffer+n_buffer_len, '0', (10-n_ukey_len)) ;
		sprintf(buffer+n_buffer_len+(10-n_ukey_len), "%s", ukey) ;
		return buffer ;
	}

	static string getChannelIdentifier(string s_suffix) {
		time_t rawtime ;
		time(&rawtime) ;

		tm* timeinfo ;
		timeinfo = localtime(&rawtime) ;

		char buffer[80] ;
		strftime(buffer, 80, "%y%m%d%H%M%S", timeinfo) ;
		int n_buffer_len = (int)strlen(buffer) ;
		memset(buffer+n_buffer_len, 0x00, 80-n_buffer_len) ;

		char ukey[20] ;
		struct timespec ts ;
		clock_gettime(CLOCK_MONOTONIC, &ts) ; // Get Nano-Sec
		sprintf(ukey, "%0.f", (double)ts.tv_nsec) ;
		int n_ukey_len = (int)strlen(ukey) ;

		memset(buffer+n_buffer_len, '0', (10-n_ukey_len)) ;
		sprintf(buffer+n_buffer_len+(10-n_ukey_len), "%s", ukey) ;

		string s_return = (buffer + s_suffix) ;
		return s_return ;
	}

	static string toUTF8(char *c_data) {
		string s_ret = "" ;
		size_t szIn = strlen(c_data) + 10 ;
		size_t szOut = szIn * 3 ;

		char *pIn = NULL ;
		char *pOut = NULL ;

		pIn = new char[szIn] ;
		memset(pIn, 0x00, (sizeof(char) * szIn)) ;
		memcpy(pIn, c_data, (sizeof(char) * strlen(c_data))) ;

		pOut = new char[szOut] ;
		memset(pOut, 0x00, sizeof(char) * szOut) ;

		char *pIn_bak = pIn ;
		char *pOut_bak = pOut ;

		iconv_t cd ;
		if ((cd = iconv_open("UTF-8//IGNORE", "CP949")) < 0) {
			printf(" = fail iconv_open() \n") ;
		} else {
			if (iconv(cd, &pIn_bak, &szIn, &pOut_bak, &szOut) < 0) {
				switch (errno) {
					case E2BIG  : printf(" = fail iconv() - E2BIG  \n") ; break ;
					case EILSEQ : printf(" = fail iconv() - EILSEQ \n") ; break ;
					case EINVAL : printf(" = fail iconv() - EINVAL \n") ; break ;
				}
			} else {
				string s_data(pOut) ;
				s_ret = s_data ;
			}
			iconv_close(cd) ;
		}
		delete [] pIn ;
		delete [] pOut ;
		return s_ret ;
	}

	static string toEUCKR(char *c_data) {
		string s_ret = "" ;
		size_t szIn = strlen(c_data) + 10 ;
		size_t szOut = szIn * 3 ;

		char *pIn = NULL ;
		char *pOut = NULL ;

		pIn = new char[szIn] ;
		memset(pIn, 0x00, (sizeof(char) * szIn)) ;
		memcpy(pIn, c_data, (sizeof(char) * strlen(c_data))) ;

		pOut = new char[szOut] ;
		memset(pOut, 0x00, sizeof(char) * szOut) ;

		char *pIn_bak = pIn ;
		char *pOut_bak = pOut ;

		iconv_t cd ;
		if ((cd = iconv_open("CP949", "UTF-8//IGNORE")) < 0) {
			printf(" = fail iconv_open() \n") ;
		} else {
			if (iconv(cd, &pIn_bak, &szIn, &pOut_bak, &szOut) < 0) {
				switch (errno) {
					case E2BIG  : printf(" = fail iconv() - E2BIG  \n") ; break ;
					case EILSEQ : printf(" = fail iconv() - EILSEQ \n") ; break ;
					case EINVAL : printf(" = fail iconv() - EINVAL \n") ; break ;
				}
			} else {
				string s_data(pOut) ;
				s_ret = s_data ;
			}
			iconv_close(cd) ;
		}
		delete [] pIn ;
		delete [] pOut ;
		return s_ret ;
	}

	static int runCommand(const char *strCommand) {
		int iStatus = -1 ;
		pid_t iForkId ;
		iForkId = vfork() ;
		if (iForkId == 0) {
			execl(SHELL, SHELL, "-c", strCommand, NULL) ;
			printf("CSGUTIL::runCommand() - fail to command - %s\n", strCommand) ;
		} else if (iForkId < 0) {
			iStatus = -1 ;
		} else {
			if (waitpid(iForkId, &iStatus, 0) != iForkId) {
				iStatus = -1 ;
			}
		}
		return(iStatus);
	}

	static string getCommand(string s_cmd) {
		string s_output = "" ;
		FILE *stream = popen(s_cmd.c_str(), "r") ;
		ostringstream output ;
		while (!feof(stream) && !ferror(stream)) {
			char buf[256] ;
			int bRead = fread(buf, 1, 256, stream) ;
			output.write(buf, bRead) ;
		}
		pclose(stream) ;
		s_output = output.str() ;
		return s_output ;
	}

	static void checkDIR(string s_path) {
			bool isDIR = false ;
			struct stat sb ;
			if (stat(s_path.c_str(), &sb) == 0) {
				if (S_ISDIR(sb.st_mode)) {
					isDIR = true ;
				} else {
					printf(" = checkDIR() - path error .. \n . [%s] \n", s_path.c_str()) ;
				}
			} else {
				mkdir(s_path.c_str(), 0700) ;
			}
		}
}  ;

#endif /* INCLUDE_CSGUTIL_H_ */
