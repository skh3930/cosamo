/*
 * CThreadQueue.h
 *
 *  Created on: Dec 23, 2015
 *      Author: moyakk
 */

#ifndef CTHREADQUEUE_H_
#define CTHREADQUEUE_H_

#include <Thread.h>
#include <ThreadQueue.h>
#include <iostream>

using namespace std ;

class CThreadQueue : public Thread {

private :
	void pop() {
		if (!b_on) {
			int n_limit = threadq.size() ;
			for (int i=0; i<n_limit; i++) {
				CThreadQueue *temp = threadq.getAt(i) ;
				if (temp->tid() == n_tid) {
					threadq.remove(temp) ;
					break ;
				}
			}
		}
	}

protected :
	int n_tid ;
	bool b_on ;

public :
	ThreadQueue<CThreadQueue*> &threadq ;

	/** - SAMPLE -----------------------------------------

		#include "CThreadQueue.h"

		class CWorkThread : public CThreadQueue {
		public:
			CWorkThread(int _tid, ThreadQueue<CThreadQueue*> &in_queue) : CThreadQueue(_tid, in_queue) {
				// INIT !!
			}
			~CWorkThread() {
				// DESTROY ALL POINTER !!
			}
			void* run() {
				// DoSOMETHING !!
			}
		} ;

		--------------------------------------------------
		@authre JJ
		--------------------------------------------------
	**/
	CThreadQueue(int in_tid, ThreadQueue<CThreadQueue*> &in_queue) : threadq(in_queue) {
		n_tid = in_tid ;
		b_on = true ;
	} ;
	virtual ~CThreadQueue() {
		//
	}
	virtual void *run() {
		return reinterpret_cast<void *>(tid()) ;
	}
	int tid() {
		return n_tid ;
	}
	bool isOn() {
		pop() ;
		return b_on ;
	}
} ;

#endif /* CTHREADQUEUE_H_ */
