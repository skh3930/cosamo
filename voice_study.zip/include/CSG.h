/*
 * CGlobal.h
 *
 *  Created on: Apr 21, 2016
 *      Author: moyakk
 */

#ifndef INCLUDE_CSG_H_
#define INCLUDE_CSG_H_

#include <iostream>
using namespace std ;

enum LOG_TYPE {INFO, DEBUG, ERROR} ;
enum LOG_LEVEL {LOG_NEVER, LOG_STDOUT, LOG_FILE, LOG_ALL} ;

////////////////////////////////////////////////////////////
////
////	Forward Declarations
////

class CConfiguration ;
class CLog ;
class CSessionManager ;

class SG {

private :
	static CConfiguration *p_conf ;
	static CLog *p_sgout ;
	static CSessionManager *p_session_manager ;
public :
	static CConfiguration *conf() ;
	static CLog* getsgout() ;
	static CSessionManager *getSessionManager() ;
} ;

#endif /* INCLUDE_CSG_H_ */
