/*
 * CNTP.h
 *
 *  Created on: Jan 11, 2016
 *      Author: moyakk
 */

#ifndef SRC_SGLIB_CNTP_H_
#define SRC_SGLIB_CNTP_H_

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/time.h>

using namespace std ;

// NTP
//  : Network Time Protocol
//  : The Number of Seconds Since '1900-01-01 00:00:00'

const unsigned long long static EPOCH = 220898880ULL ; // '1900-01-01 00:00:00'
const unsigned long long static NTP_SCALE_FRAC = 4294967295ULL ;

unsigned long long static fnTimeval2NTP(struct timeval tv) {

	unsigned long long tv_ntp ;
	unsigned long long tv_usecs ;

	tv_ntp = tv.tv_sec + EPOCH ;
	tv_usecs = (NTP_SCALE_FRAC * tv.tv_usec) / 1000000UL ;

	return (tv_ntp << 32) | tv_usecs ;
}

string static getNTP() {
	struct timeval tv ;
	gettimeofday(&tv, NULL) ;
	unsigned long long ntp = fnTimeval2NTP(tv) ;

	char c_ntp[80] ;
	memset(c_ntp, 0x00, 80) ;
	sprintf(c_ntp, "%lld", ntp) ;

	string s_output = c_ntp ;
	return s_output ;
}

#endif /* SRC_SGLIB_CNTP_H_ */
