/*
 * CConfiguration.h
 *
 *  Created on: Sep 24, 2015
 *      Author: solugate
 */

#ifndef CCONFIGURATION_H_
#define CCONFIGURATION_H_

#include <iostream>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <config.h>

#define TID_MAX 65535

using namespace std ;

enum PROG_MODE {MODE_TEST, MODE_RELEASE} ;
enum PROG_IVR  {IVR_DEFAULT, IVR_DEOTIS, IVR_BLUEBAY} ;

////////////////////////////////////////////////////////////
////	MODULE

typedef struct _MODULE {
	string s_name ;
	int n_interval ;
	string s_root ;
	string s_ip ;
	string s_key ;
	int n_mode ;
	int n_log_info ;
	int n_log_debug ;
	int n_log_error ;
} stMODULE ;

////////////////////////////////////////////////////////////
////	LASER

typedef struct _LASER {
	int n_version ;
	string s_root ;
	string s_target ;
	bool b_gpu ;
	int n_channel ;
	string s_am_img_path ;
	string s_lm_img_path ;
} stLASER ;

////////////////////////////////////////////////////////////
////	DB

typedef struct _DB {
	string s_type ;
	string s_host ;
	int n_port ;
	string s_name ;
	string s_id ;
	string s_pw ;
	int n_log_info ;
	int n_log_debug ;
	int n_log_error ;
} stDB ;

////////////////////////////////////////////////////////////
////	RECORD

typedef struct _RECORD {
	bool b_txt ;
	bool b_txt_remove ;
	int n_txt_remove_after ;
	string s_txt_path ;
	bool b_pcm ;
	bool b_pcm_remove ;
	int n_pcm_remove_after ;
	string s_pcm_path ;
	bool b_wav ;
	bool b_wav_remove ;
	int n_wav_remove_after ;
	string s_wav_path ;
	bool b_mp3 ;
	bool b_mp3_remove ;
	int n_mp3_remove_after ;
	string s_mp3_path ;
	string s_list_am_path ;
	string s_list_lm_path ;
	string s_binary_path ;
} stRECORD ;


////////////////////////////////////////////////////////////
////	RECORD

typedef struct _TCPIP {
	int n_tcp_port;
	int n_udp_port_start;
	int n_udp_port_end;
	string s_ip ;
} stTCPIP ;



////////////////////////////////////////////////////////////

class CConfiguration : public Config {
private :
	void getConfig() ;

public :
	stMODULE g_module ;
	stLASER g_laser ;
	stDB g_db ;
	stRECORD g_record ;
	stTCPIP g_tcpip ;

	CConfiguration() : Config("sgsas_svr.conf", 0) {
		string s_file = "sgsas_svr.conf"; // Default
		getConfig() ;
	}
	CConfiguration(string s_file) : Config(s_file, 0) {
		getConfig() ;
	}
	~CConfiguration() {
		//
	}
	void fnPrintConfigData() ;
} ;

#endif /* CCONFIGURATION_H_ */
