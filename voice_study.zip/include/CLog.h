/*
 * CLog.h
 *
 *  Created on: Dec 22, 2015
 *      Author: moyakk
 */

#ifndef INCLUDE_CLOG_H_
#define INCLUDE_CLOG_H_

#ifndef IGUN
#define IGUN __attribute__ ((unused)) // ignore unused variable warning
#endif

#include <iostream>
#include <unistd.h>
#include <sys/stat.h>
#include <stdarg.h>
#include <pthread.h>

#include <CSG.h>
#include <CSGUTIL.h>
#include <CConfiguration.h>

using namespace std ;

/** - SAMPLE -----------------------------------------

	// 1. Config

	string sPATH = "/home/rootdev/bluebay/log/" ;
	string sFILE = "sip" ;

	// 2. Open

	CLog *clog = new CLog(sFILE, sPATH) ;

	// 3. Print
	// FILE Date auto change

	clog->printLog("CLog", "Logging Test !") ;

	// 4. Close

	clog->closeLog() ;

	--------------------------------------------------
	@date	2016.01.15
	@author JJ
	--------------------------------------------------
**/

class CLog {
private:
	pthread_mutex_t mutex ;

	FILE *fLog ;
	string s_name ;
	string s_path ;
	string s_file ;
	string s_date ;

	int n_info ;
	int n_debug ;
	int n_error ;

	bool checkDate() ;

	void openLog() ;
	void closeLog() ;
	void resetLog() ;

public:
	CLog(string in_name);
	CLog(string in_name, string in_path);
	virtual ~CLog();

	void setLog(string in_name, string in_path) ;
	void setLogLevel(int _info, int _debug, int _error) ;

	void printLog(string s_title, string s_description) ;
	void printLog(string s_title, char * s_description) {
		printLog(s_title, (string)s_description) ;
	} void printLog(string s_title, const char * s_description) {
		printLog(s_title, (string)s_description) ;
	} void printLog(string s_title, unsigned char * s_description) {
		printLog(s_title, (string)(char *)s_description) ;
	}

	//// SGOUT ONLY //
	void print(int n_type, const char *timestamp, char *buf) ;
	void info(const char *s_msg, ...) ;
	void debug(const char *s_msg, ...) ;
	void error(const char *s_msg, ...) ;
};

IGUN static void sgprintf(LOG_TYPE log_type, const char * msg, ...) {
	int n_len = 1024 ;
	if (n_len < (int)strlen(msg)) {
		n_len = strlen(msg) + 2 ;
	}
	char buf[n_len] ;
	va_list ap ;
	va_start(ap, msg) ;
	vsprintf(buf, msg, ap) ;
	va_end(ap) ;
	CLog *p_sgout = SG::getsgout() ;
	string timestamp = FN::yyyymmddhhmmsss(1) ;
	if (log_type == INFO) {
		p_sgout->print(1, timestamp.c_str(), buf) ;
	} else if (log_type == DEBUG) {
		p_sgout->print(2, timestamp.c_str(), buf) ;
	} else if (log_type == ERROR) {
		p_sgout->print(3, timestamp.c_str(), buf) ;
	}
}

#endif /* INCLUDE_CLOG_H_ */
