/*
 * CLearning.h
 *
 *  Created on: 2016. 7. 29.
 *      Author: cosamo01
 */

#ifndef CLEARNING_H_
#define CLEARNING_H_

#include <CLog.h>
#include <CDir.h>
#include <CDBMySQL.h>
#include <TBANSSOUND.h>
#include <CSGUTIL.h>
#include <ThreadQueue.h>
#include <TBSOUNDPATH.h>
#include <TBENGSTUDYLIST.h>
#include <TBCAINFO.h>
#include <TBWAINFO.h>
#include <TBENGVER.h>
#include <TBENGSTUDYLOG.h>

class CLearning {
private :
	string n_ts_version;
	string s_ca_path;
	string s_wa_path;
	string s_error_code;
	CDBMySQL *p_db;
	TBENGSTUDYLOG *p_log;

public:
	CLearning(string _ts_version, CDBMySQL *_db, TBENGSTUDYLOG *_englog) {
		sgprintf(DEBUG, "CLearning::CLearning() - CREATE \n");
		s_error_code = "";
		n_ts_version = _ts_version ;
		p_db = _db ;
		p_log = _englog;
	}
	virtual ~CLearning(){
		sgprintf(DEBUG, "CLearning::CLearning() - destory \n");

	}
	void UpdateLearningResult(bool b_result, string s_binary_path, ThreadQueue<TBENGSTUDYLIST*> files);
	string runLearning() ;
	ThreadQueue<TBENGSTUDYLIST*> getFileList() ;
	string makeTxtFile(ThreadQueue<TBENGSTUDYLIST*> file) ;
};

#endif /* CLEARNING_H_ */
