/*
 * CBuffer.h
 *
 *  Created on: Feb 4, 2016
 *      Author: moyakk
 */

#ifndef INCLUDE_CBUFFER_H_
#define INCLUDE_CBUFFER_H_

#include <stdlib.h>
#include <string.h>

/**	- SAMPLE -----------------------------------------

	string s_msg = "" ;

	int buf_max = 10 ;
	int buf_type = CBuffer::TYPE_BYTE ;
	int buf_size = CBuffer::LENGTH_AUTOINCREASE ;

	CBuffer* buf ;
	buf = new CBuffer(buf_max, buf_type, buf_size) ;

	s_msg = "HELLO" ;
	buf->fnCopy((void *)s_msg.c_str(), s_msg.length()) ;
	printf(". (%s)(%d/%d)\n", (char *)buf->buf, buf->len, buf->max) ;

	s_msg = "WORLD" ;
	buf->fnAdd((void *)s_msg.c_str(), s_msg.length()) ;
	printf(". (%s)(%d/%d)\n", (char *)buf->buf, buf->len, buf->max) ;

	delete buf ;

	--------------------------------------------------
	@date	2016.02.04
	@author JJ
	--------------------------------------------------
**/
class CBuffer {

private:
	typedef unsigned char BYTE ;
	typedef struct {
		int type ;
		int length ;
	} CONF ;

	CONF conf ;
	int _size ;

	void fnCreate() {
		len = 0 ;
		if (conf.type == TYPE_BYTE) {
			buf = new BYTE[max] ;
			_size = sizeof(BYTE) ;
		} else if (conf.type == TYPE_SHORT) {
			buf = new short[max] ;
			_size = sizeof(short) ;
		}
		fnClear() ;
	}
	void fnCreate(int _max) {
		len = 0 ;
		max = _max ;
		if (conf.type == TYPE_BYTE) {
			buf = new BYTE[max] ;
			_size = sizeof(BYTE) ;
		} else if (conf.type == TYPE_SHORT) {
			buf = new short[max] ;
			_size = sizeof(short) ;
		}
		fnClear() ;
	}
	void fnDelete() {
		if (conf.type == TYPE_BYTE) {
			delete [] (BYTE *)buf ;
		} else if (conf.type == TYPE_SHORT) {
			delete [] (short *)buf ;
		}
	}
	void fnResize(int _max) {
		fnDelete() ;
		fnCreate(_max) ;
	}

public:
	enum BufferType {TYPE_BYTE, TYPE_SHORT} ;
	enum BufferLength {LENGTH_FIXED, LENGTH_AUTOINCREASE} ;

	int max ;
	int len ;
	void *buf ;

	CBuffer(int _max, BufferType _type) {
		max = _max ;
		conf.type = _type ;
		conf.length = LENGTH_FIXED ; // DEFAULT
		fnCreate() ;
	}
	CBuffer(int _max, BufferType _type, BufferLength _length) {
		max = _max ;
		conf.type = _type ;
		conf.length = _length ;
		fnCreate() ;
	}
	~CBuffer() {
		fnDelete() ;
	}

	void fnClear() {
		// printf(" = CBuffer::fnClear() - %d \n", len) ;
		if (len > 0) {
			len = 0 ;
			if (conf.type == TYPE_BYTE) {
				memset((BYTE *)buf, 0x00, max*_size) ;
			} else if (conf.type == TYPE_SHORT) {
				memset((short *)buf, 0x00, max*_size) ;
			}
		}
	}

	/**	--------------------------------------------------
		-	Copy Buffer Data : [Buffer] = [Input]
		--------------------------------------------------
		@date	2016.02.04
		@author	JJ
		--------------------------------------------------
	**/
	void fnCopy(void *_buf, int _len) {
		// EXCEPTION
		if (!_buf) {
			printf(" = CBuffer::fnCopy() Target Buffer Exception\n") ;
			return ;
		}
		if (_len <= 0) {
			printf(" = CBuffer::fnCopy() Target Length Exception : %d\n", _len) ;
			return ;
		}

		// CHECK BUFFER SIZE
		if (max < _len) {
			if (conf.length == LENGTH_FIXED) {
				printf(" = CBuffer::fnCopy() Target Length Exception : %d/%d\n", _len, max) ;
				return ;
			}
			if (conf.length == LENGTH_AUTOINCREASE) {
				int bigmax = max + (_len*2) ;
				printf(" = CBuffer::fnCopy() Increase Buffer : %d > %d\n", max, bigmax) ;
				fnResize(bigmax) ;
			}
		}

		// COPY
		fnClear() ;
		memcpy(buf, _buf, _len*_size) ;
		len = _len ;
	}

	void fnCopy(CBuffer *_buf) {
		this->fnCopy(_buf->buf, _buf->len) ;
	}

	/**	--------------------------------------------------
		-	Add After : [Buffer] + [Input]
		--------------------------------------------------
		@date	2016.02.04
		@author	JJ
		--------------------------------------------------
	**/
	void fnAdd(void *_buf, int _len) {
		// EXCEPTION
		if (!_buf) {
			printf(" = CBuffer::fnAdd() Target Buffer Exception\n") ;
			return ;
		}
		if (_len <= 0) {
			printf(" = CBuffer::fnAdd() Target Length Exception : %d\n", _len) ;
			return ;
		}

		// PREPARE
		int _gap = (len + _len) - max ;
		if (_gap > 0) {
			if (conf.length == LENGTH_FIXED) {
				// printf("CBuffer::fnAdd() - FIX - gap:%d - type:%d \n", _gap, conf.type) ;
				// SHIFT
				for (int i=0; i<max; i++) {
					if ((i+_gap) >= max) {
						if (conf.type == TYPE_BYTE) {
							memset(((BYTE *)buf+i), 0x00, _size) ;
						} else if (conf.type == TYPE_SHORT) {
							memset(((short *)buf+i), 0x00, _size) ;
						}
					} else {
						if (conf.type == TYPE_BYTE) {
							memcpy(((BYTE *)buf+i), ((BYTE *)buf+(i+_gap)), _size) ;
						} else if (conf.type == TYPE_SHORT) {
							memcpy(((short *)buf+i), ((short *)buf+(i+_gap)), _size) ;
						}
					}
				}
				len -= _gap ;
			}
			if (conf.length == LENGTH_AUTOINCREASE) {
				// printf("CBuffer::fnAdd() - AUTO - gap:%d - type:%d \n", _gap, conf.type) ;
				// INCREASE
				int bigmax = max + (_gap*2) ;
				// printf(" = CBuffer::fnAdd() Increase Buffer : %d > %d\n", max, bigmax) ;
				max = bigmax ;
				void *bigbuf ;
				if (conf.type == TYPE_BYTE) {
					bigbuf = new BYTE[max] ;
				} else if (conf.type == TYPE_SHORT) {
					bigbuf = new short[max] ;
				}
				memset(bigbuf, 0x00, max) ;
				memcpy(bigbuf, buf, len*_size) ;
				fnDelete() ;
				buf = bigbuf ;
			}
		}

		// ADD
		if (conf.type == TYPE_BYTE) {
			// printf("CBuffer::fnAdd() - ADD.BYTE - len:%d, size:%d - type:%d \n", len, _len*_size, conf.type) ;
			memcpy(((BYTE *)buf+len), _buf, _len*_size) ;
		} else if (conf.type == TYPE_SHORT) {
			// printf("CBuffer::fnAdd() - ADD.SHORT - len:%d, size:%d - type:%d \n", len, _len*_size, conf.type) ;
			// printf("CBuffer::fnAdd() - (%p)%p > %p \n", buf, (short *)buf, (short *)buf+len) ;
			memcpy(((short *)buf+len), _buf, _len*_size) ;
		}
		len += _len ;
	}

	/**	--------------------------------------------------
		-	Add Before : [Input] + [Buffer]
		--------------------------------------------------
		@date	2016.02.04
		@author	JJ
		--------------------------------------------------
	**/
	void fnAddBefore(void *_buf, int _len) {
		// EXCEPTION
		if (!_buf) {
			printf(" = CBuffer::fnAddBefore() Target Buffer Exception\n") ;
			return ;
		}
		if (_len <= 0) {
			printf(" = CBuffer::fnAddBefore() Target Length Exception (Empty) : %d\n", _len) ;
			return ;
		}
		if (conf.length == LENGTH_FIXED) {
			if (_len > max) {
				printf(" = CBuffer::fnAddBefore() Target Length Exception (Too Long) : %d/%d\n", _len, max) ;
				return ;
			}
		}

		// TEMP BUFFER
		int tempLen = 0 ;
		void *temp ;
		if (conf.type == TYPE_BYTE) {
			temp = new BYTE[max] ;
			memset((BYTE *)temp, 0x00, _size) ;
		} else if (conf.type == TYPE_SHORT) {
			temp = new short[max] ;
			memset((short *)temp, 0x00, _size) ;
		}

		// PREPARE
		int _gap = (len + _len) - max ;
		if (_gap > 0) {
			if (conf.length == LENGTH_FIXED) {
				// SHIFT
				if ((tempLen = (len-_gap)) > 0) {
					if (conf.type == TYPE_BYTE) {
						memcpy((BYTE *)temp, (BYTE *)buf, tempLen*_size) ;
						fnClear() ;
					} else if (conf.type == TYPE_SHORT) {
						memcpy((short *)temp, (short *)buf, tempLen*_size) ;
						fnClear() ;
					}
				}
				if (conf.type == TYPE_BYTE) {
					memcpy((BYTE *)buf, (BYTE *)_buf, _len*_size) ;
				} else if (conf.type == TYPE_SHORT) {
					memcpy((short *)buf, (short *)_buf, _len*_size) ;
				}
				len = _len ;
			}
			if (conf.length == LENGTH_AUTOINCREASE) {
				// INCREASE
				tempLen = (len) ;
				if (conf.type == TYPE_BYTE) {
					memcpy((BYTE *)temp, (BYTE *)buf, tempLen*_size) ;
				} else if (conf.type == TYPE_SHORT) {
					memcpy((short *)temp, (short *)buf, tempLen*_size) ;
				}
				len = _len ;
				int bigmax = max + (_gap*2) ;
				printf(" = CBuffer::fnAddBefore() Increase Buffer : %d > %d\n", max, bigmax) ;
				max = bigmax ;
				void *bigbuf ;
				if (conf.type == TYPE_BYTE) {
					bigbuf = new BYTE[max] ;
				} else if (conf.type == TYPE_SHORT) {
					bigbuf = new short[max] ;
				}
				memset(bigbuf, 0x00, max) ;
				memcpy(bigbuf, _buf, _len*_size) ;
				fnDelete() ;
				buf = bigbuf ;
			}
		} else {
			tempLen = (len) ;
			if (conf.type == TYPE_BYTE) {
				memcpy((BYTE *)temp, (BYTE *)buf, tempLen*_size) ;
				fnClear() ;
				memcpy((BYTE *)buf, (BYTE *)_buf, _len*_size) ;
			} else if (conf.type == TYPE_SHORT) {
				memcpy((short *)temp, (short *)buf, tempLen*_size) ;
				fnClear() ;
				memcpy((short *)buf, (short *)_buf, _len*_size) ;
			}
			len = _len ;
		}

		// ADD
		if (tempLen > 0) {
			if (conf.type == TYPE_BYTE) {
				memcpy(((BYTE *)buf+len), temp, tempLen*_size) ;
			} else if (conf.type == TYPE_SHORT) {
				memcpy(((short *)buf+len), temp, tempLen*_size) ;
			}
			len += tempLen ;
		}

		// CLEAR MEMORY
		if (conf.type == TYPE_BYTE) {
			delete [] (BYTE *)temp ;
		} else if (conf.type == TYPE_SHORT) {
			delete [] (short *)temp ;
		}
	}

	int size() { return len ; }
	bool isEmpty() { return (len > 0)? true:false ; }

	void print() {
		printf(" . %s (%d/%d)\n", (BYTE *)buf, len, max) ;
	}
} ;

#endif /* INCLUDE_CBUFFER_H_ */
