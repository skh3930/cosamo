/*
 * Thread.h
 *
 *  Created on: Sep 25, 2015
 *      Author: solugate
 */

#ifndef THREAD_H_
#define THREAD_H_

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <memory>
#include <pthread.h>
#include <cassert>
#include <error.h>
#include <errno.h>

using namespace std ;

class Runnable {

public :
	virtual void* run() = 0 ;
	virtual ~Runnable() = 0 ;
} ;

class Thread {

private :
	pthread_t PthreadThreadID ; // thread ID
	pthread_attr_t threadAttribute ;
	auto_ptr<Runnable> runnable ; // runnable object will be deleted automatically
	bool detached ; // true if thread created in detached state
	void* result ; // stores return value from run()

private :
	Thread(const Thread&) ;

	const Thread& operator=(const Thread&) ;
	void setCompleted() ; // called when run() completes
	virtual void* run() = 0  ;
	static void* startThreadRunnable(void* pVoid) ;
	static void* startThread(void* pVoid) ;
	void printError(const char * msg, int status, const char* fileName, int lineNumber) ;

public :
	Thread(auto_ptr<Runnable> run, bool isDetached = false) ;
	Thread(bool isDetached = false) ;
	virtual ~Thread() ;
	void start() ;
	void* join() ;
} ;

#endif /* THREAD_H_ */
