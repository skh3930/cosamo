#include <ext/log.h>

LogLevel logLevel = LOG_INFO;
