/*
 * CMain.h
 *
 *  Created on: Apr 18, 2016
 *      Author: moyakk
 */

#ifndef INCLUDE_CMAIN_H_
#define INCLUDE_CMAIN_H_

#include <CSG.h>
#include <CSGUTIL.h>
#include <CThread.h>
#include <CDBMySQL.h>
#include <CLearning.h>
#include <TBENGSTUDYLOG.h>

class CMain : public CThread {

private:
	bool b_run ;
	CDBMySQL *p_db ;
	CConfiguration *p_conf ;
	TBENGSTUDYLOG *p_log;

private:
	void work() ;
	void workPrepare() ;
	void workRealtime() ;
	bool isLearned(string s_version);


public:
	CMain(int _tid) : CThread(_tid) {
		sgprintf(DEBUG, "CMain::CMain(%d) - Create", tid()) ;
		b_run = true ;
		p_db = NULL ;
		p_conf = NULL ;
		p_log = NULL;
	}
	virtual ~CMain() {
		sgprintf(DEBUG, "CMain::~CMain(%d) - Destroy", tid()) ;
		b_run = false ;
		if (p_db) { delete p_db ; p_db = NULL ; }
		if (p_conf) { delete p_conf ; p_conf = NULL ; }
	}
	virtual void *run() {
		this->workPrepare() ;
		this->work() ;
		return reinterpret_cast<void *>(tid()) ;
	}
	void stop() {
		b_run = false ;
	}
	bool isRun() {
		return b_run ;
	}
} ;

#endif /* INCLUDE_CMAIN_H_ */
