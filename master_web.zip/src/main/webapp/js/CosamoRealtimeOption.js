/****************************************************************
 * 
 * 파일명 : CosamoRealtimeOption.js
 * 설  명 : 실시간현황 그래프 옵션 변경 JavaScript
 * 
 *    수정일      수정자     Version        Function 명
 * ------------    ---------   -------------  ----------------------------
 * 2016.07.26    김예림      1.0            
 * 
 * 
 * **************************************************************/

// 시간별, 일별, 월별, 년별 선택 필터
function fn_activateSelectbox(id) {
	var OptNew = new Array();

	if (id.indexOf("1") > -1) {
		// 시간별 선택시
		document.getElementById('s1').disabled = false;
		document.getElementById('s2').disabled = false;
		document.getElementById('s3').disabled = false;
		document.getElementById('s4').disabled = false;
		
		// 그래프 x축 - 0시~23시
		
	} else if (id.indexOf("2") > -1) {
		// 일별 선택시
		document.getElementById('s2').disabled = false;
		document.getElementById('s3').disabled = false;
		document.getElementById('s4').disabled = true;
		
		// 그래프 x축 - 1일~28(31)일
		
	} else if (id.indexOf("3") > -1) {
		// 월별 선택시
		document.getElementById('s2').disabled = false;
		document.getElementById('s3').disabled = true;
		document.getElementById('s4').disabled = true;
		
		// 그래프 x축 - 1월~12월
		
	} else if (id.indexOf("4") > -1) {
		// 년별 선택시
		document.getElementById('s2').disabled = true;
		document.getElementById('s3').disabled = true;
		document.getElementById('s4').disabled = true;
		
		// 그래프 x축 - x~2016년
	}
}

// 1~12월까지 옵션에 기본적으로 28일까지 있음.
function fn_changeDays(month) {
	var dayList = document.getElementById('s4');
	var OptNew = new Array();

	var length = dayList.length;

	for (var i = 0; i < 3; i++) {
		OptNew[i] = document.createElement('option');
	}
	OptNew[0].text = '29일';
	OptNew[0].value = 'd29';
	OptNew[1].text = '30일';
	OptNew[1].value = 'd30';
	OptNew[2].text = '31일';
	OptNew[2].value = 'd31';

	switch (month) {
	case 'm1': case 'm3': case 'm5': case 'm7':
	case 'm8': case 'm10': case 'm12':
		for (var i = 0; i < 3; i++)
			dayList.add(OptNew[i], length + i);
		break;
	case 'm4': case 'm6': case 'm9': case 'm11':
		for (var i = 0; i < 2; i++)
			dayList.add(OptNew[i], length + i);
		break;
	case 'm2':
		for(var i=length-1; i>27; i--)
			dayList.remove(i);
		break;
	}
}
/* 접속자 수 그래프 */	
function fn_makeGraph1(data){
	var chart = AmCharts.makeChart("chartdiv", {
		"type" : "serial",
		"theme" : "light",
		"legend" : {
			"equalWidths" : false,
			"useGraphSettings" : true,
			"valueAlign" : "left",
			"valueWidth" : 120
		},
		"dataProvider" : data,
		"valueField" : "userNum",
		"valueAxes" : [ {
			"id" : "userAxis",
			"axisAlpha" : 0,
			"gridAlpha" : 0,
			"position" : "left"
		}, {
			"id" : "dateAxis",
			"axisAlpha" : 0,
			"gridAlpha" : 0,
			"labelsEnabled" : false,
			"position" : "right"
		} ],
		"graphs" : [ {
			// 총 접속자 수
			"balloonText" : "[[value]]명",
			"bullet" : "round",
			"bulletBorderAlpha" : 1,
			"useLineColorForBulletBorder" : true,
			"bulletColor" : "#FFFFFF",
			"bulletSizeField" : "townSize",
			"dashLengthField" : "dashLength",
			"descriptionField" : "townName",
			"legendValueText" : "[[value]]명",
			"title" : "총 접속자 수",
			"fillAlphas" : 0,
			"valueField" : "userNum",
			"valueAxis" : "userAxis"
		}, {
			"bullet" : "square",
			"bulletBorderAlpha" : 1,
			"bulletBorderThickness" : 1,
			"dashLengthField" : "dashLength",
			"legendValueText" : "[[value]]명",
			"title" : "1급",
			"fillAlphas" : 0,
			"valueField" : "userNum1",
			"valueAxis" : "userAxis"
		}, {
			"bullet" : "square",
			"bulletBorderAlpha" : 1,
			"bulletBorderThickness" : 1,
			"dashLengthField" : "dashLength",
			"legendValueText" : "[[value]]명",
			"title" : "2급",
			"fillAlphas" : 0,
			"valueField" : "userNum2",
			"valueAxis" : "userAxis"
		}, {
			"bullet" : "square",
			"bulletBorderAlpha" : 1,
			"bulletBorderThickness" : 1,
			"dashLengthField" : "dashLength",
			"legendValueText" : "[[value]]명",
			"title" : "3급",
			"fillAlphas" : 0,
			"valueField" : "userNum3",
			"valueAxis" : "userAxis"
		}, {
			"bullet" : "square",
			"bulletBorderAlpha" : 1,
			"bulletBorderThickness" : 1,
			"dashLengthField" : "dashLength",
			"legendValueText" : "[[value]]명",
			"title" : "4급",
			"fillAlphas" : 0,
			"valueField" : "userNum4",
			"valueAxis" : "userAxis"
		}, {
			"bullet" : "square",
			"bulletBorderAlpha" : 1,
			"bulletBorderThickness" : 1,
			"dashLengthField" : "dashLength",
			"legendValueText" : "[[value]]명",
			"title" : "5급",
			"fillAlphas" : 0,
			"valueField" : "userNum5",
			"valueAxis" : "userAxis"
		}, {
			"bullet" : "square",
			"bulletBorderAlpha" : 1,
			"bulletBorderThickness" : 1,
			"dashLengthField" : "dashLength",
			"legendValueText" : "[[value]]명",
			"title" : "6급",
			"fillAlphas" : 0,
			"valueField" : "userNum6",
			"valueAxis" : "userAxis"
		} ],
		"chartCursor" : {
			"cursorAlpha" : 0.1,
			"cursorColor" : "#000000",
			"fullWidth" : true,
			"valueBalloonsEnabled" : false,
			"zoomable" : false
		},
		"categoryField" : "date",
		"categoryAxis" : {
			"gridPosition" : "start",
			"labelRotation" : 45
		},
		"export" : {
			"enabled" : true
		}
	});
}

/* 학습 별 접속자 수 그래프 */
function fn_makeGraph2(data){
	var chart2 = AmCharts.makeChart("chartdiv2", {
		"type" : "serial",
		"theme" : "light",
		"legend" : {
			"equalWidths" : false,
			"useGraphSettings" : true,
			"valueAlign" : "left",
			"valueWidth" : 120
		},
		"dataProvider" :  data,
		"valueField" : "userNum",
		"valueAxes" : [ {
			"id" : "userAxis",
			"axisAlpha" : 0,
			"gridAlpha" : 0,
			"position" : "left"
		}, {
			"id" : "dateAxis",
			"axisAlpha" : 0,
			"gridAlpha" : 0,
			"labelsEnabled" : false,
			"position" : "right"
		} ],
		"graphs" : [ {
			"bullet" : "square",
			"bulletBorderAlpha" : 1,
			"bulletBorderThickness" : 1,
			"dashLengthField" : "dashLength",
			"legendValueText" : "[[value]]명",
			"title" : "음절",
			"fillAlphas" : 0,
			"valueField" : "userNum",
			"valueAxis" : "userAxis"
		}, {
			"bullet" : "square",
			"bulletBorderAlpha" : 1,
			"bulletBorderThickness" : 1,
			"dashLengthField" : "dashLength",
			"legendValueText" : "[[value]]명",
			"title" : "단어",
			"fillAlphas" : 0,
			"valueField" : "userNum1",
			"valueAxis" : "userAxis"
		}, {
			"bullet" : "square",
			"bulletBorderAlpha" : 1,
			"bulletBorderThickness" : 1,
			"dashLengthField" : "dashLength",
			"legendValueText" : "[[value]]명",
			"title" : "문장",
			"fillAlphas" : 0,
			"valueField" : "userNum2",
			"valueAxis" : "userAxis"
		} ],
		"chartCursor" : {
			"cursorAlpha" : 0.1,
			"cursorColor" : "#000000",
			"fullWidth" : true,
			"valueBalloonsEnabled" : false,
			"zoomable" : false
		},
		"categoryField" : "date",
		"categoryAxis" : {
			"gridPosition" : "start",
			"labelRotation" : 45
		},
		"export" : {
			"enabled" : true
		}
	});
}
// 시간별 그래프 로드 (param userNum : 시간대별 이용자 수 배열)
function fn_timeAxis(userNum, userNum2) {
	var data = [{
			"date" : "0시",
			"userNum" : userNum[0][0], "userNum1" : userNum[1][0], "userNum2" : userNum[2][0],
			"userNum3" : userNum[3][0], "userNum4" : userNum[4][0], "userNum5" : userNum[5][0], "userNum6" : userNum[6][0]
		}, {
			"date" : "1시",
			"userNum" : userNum[0][1], "userNum1" : userNum[1][1], "userNum2" : userNum[2][1],
			"userNum3" : userNum[3][1], "userNum4" : userNum[4][1], "userNum5" : userNum[5][1], "userNum6" : userNum[6][1]
		}, {
			"date" : "2시",
			"userNum" : userNum[0][2], "userNum1" : userNum[1][2], "userNum2" : userNum[2][2],
			"userNum3" : userNum[3][2], "userNum4" : userNum[4][2], "userNum5" : userNum[5][2], "userNum6" : userNum[6][2]
		}, {
			"date" : "3시",
			"userNum" : userNum[0][3], "userNum1" : userNum[1][3], "userNum2" : userNum[2][3],
			"userNum3" : userNum[3][3], "userNum4" : userNum[4][3], "userNum5" : userNum[5][3], "userNum6" : userNum[6][3]
		}, {
			"date" : "4시",
			"userNum" : userNum[0][4], "userNum1" : userNum[1][4], "userNum2" : userNum[2][4],
			"userNum3" : userNum[3][4], "userNum4" : userNum[4][4], "userNum5" : userNum[5][4], "userNum6" : userNum[6][4]
		}, {
			"date" : "5시",
			"userNum" : userNum[0][5], "userNum1" : userNum[1][5], "userNum2" : userNum[2][5],
			"userNum3" : userNum[3][5], "userNum4" : userNum[4][5], "userNum5" : userNum[5][5], "userNum6" : userNum[6][5]
		}, {
			"date" : "6시",
			"userNum" : userNum[0][6], "userNum1" : userNum[1][6], "userNum2" : userNum[2][6],
			"userNum3" : userNum[3][6], "userNum4" : userNum[4][6], "userNum5" : userNum[5][6], "userNum6" : userNum[6][6]
		}, {
			"date" : "7시",
			"userNum" : userNum[0][7], "userNum1" : userNum[1][7], "userNum2" : userNum[2][7],
			"userNum3" : userNum[3][7], "userNum4" : userNum[4][7], "userNum5" : userNum[5][7], "userNum6" : userNum[6][7]
		}, {
			"date" : "8시",
			"userNum" : userNum[0][8], "userNum1" : userNum[1][8], "userNum2" : userNum[2][8],
			"userNum3" : userNum[3][8], "userNum4" : userNum[4][8], "userNum5" : userNum[5][8], "userNum6" : userNum[6][8]
		}, {
			"date" : "9시",
			"userNum" : userNum[0][9], "userNum1" : userNum[1][9], "userNum2" : userNum[2][9],
			"userNum3" : userNum[3][9], "userNum4" : userNum[4][9], "userNum5" : userNum[5][9], "userNum6" : userNum[6][9]
		}, {
			"date" : "10시",
			"userNum" : userNum[0][10], "userNum1" : userNum[1][10], "userNum2" : userNum[2][10],
			"userNum3" : userNum[3][10], "userNum4" : userNum[4][10], "userNum5" : userNum[5][10], "userNum6" : userNum[6][10]
		}, {
			"date" : "11시",
			"userNum" : userNum[0][11], "userNum1" : userNum[1][11], "userNum2" : userNum[2][11],
			"userNum3" : userNum[3][11], "userNum4" : userNum[4][11], "userNum5" : userNum[5][11], "userNum6" : userNum[6][11]
		}, {
			"date" : "12시",
			"userNum" : userNum[0][12], "userNum1" : userNum[1][12], "userNum2" : userNum[2][12],
			"userNum3" : userNum[3][12], "userNum4" : userNum[4][12], "userNum5" : userNum[5][12], "userNum6" : userNum[6][12]
		}, {
			"date" : "13시",
			"userNum" : userNum[0][13], "userNum1" : userNum[1][13], "userNum2" : userNum[2][13],
			"userNum3" : userNum[3][13], "userNum4" : userNum[4][13], "userNum5" : userNum[5][13], "userNum6" : userNum[6][13]
		}, {
			"date" : "14시",
			"userNum" : userNum[0][14], "userNum1" : userNum[1][14], "userNum2" : userNum[2][14],
			"userNum3" : userNum[3][14], "userNum4" : userNum[4][14], "userNum5" : userNum[5][14], "userNum6" : userNum[6][14]
		}, {
			"date" : "15시",
			"userNum" : userNum[0][15], "userNum1" : userNum[1][15], "userNum2" : userNum[2][15],
			"userNum3" : userNum[3][15], "userNum4" : userNum[4][15], "userNum5" : userNum[5][15], "userNum6" : userNum[6][15]
		}, {
			"date" : "16시",
			"userNum" : userNum[0][16], "userNum1" : userNum[1][16], "userNum2" : userNum[2][16],
			"userNum3" : userNum[3][16], "userNum4" : userNum[4][16], "userNum5" : userNum[5][16], "userNum6" : userNum[6][16]
		}, {
			"date" : "17시",
			"userNum" : userNum[0][17], "userNum1" : userNum[1][17], "userNum2" : userNum[2][17],
			"userNum3" : userNum[3][17], "userNum4" : userNum[4][17], "userNum5" : userNum[5][17], "userNum6" : userNum[6][17]
		}, {
			"date" : "18시",
			"userNum" : userNum[0][18], "userNum1" : userNum[1][18], "userNum2" : userNum[2][18],
			"userNum3" : userNum[3][18], "userNum4" : userNum[4][18], "userNum5" : userNum[5][18], "userNum6" : userNum[6][18]
		}, {
			"date" : "19시",
			"userNum" : userNum[0][19], "userNum1" : userNum[1][19], "userNum2" : userNum[2][19],
			"userNum3" : userNum[3][19], "userNum4" : userNum[4][19], "userNum5" : userNum[5][19], "userNum6" : userNum[6][19]
		}, {
			"date" : "20시",
			"userNum" : userNum[0][20], "userNum1" : userNum[1][20], "userNum2" : userNum[2][20],
			"userNum3" : userNum[3][20], "userNum4" : userNum[4][20], "userNum5" : userNum[5][20], "userNum6" : userNum[6][20]
		}, {
			"date" : "21시",
			"userNum" : userNum[0][21], "userNum1" : userNum[1][21], "userNum2" : userNum[2][21],
			"userNum3" : userNum[3][21], "userNum4" : userNum[4][21], "userNum5" : userNum[5][21], "userNum6" : userNum[6][21]
		}, {
			"date" : "22시",
			"userNum" : userNum[0][22], "userNum1" : userNum[1][22], "userNum2" : userNum[2][22],
			"userNum3" : userNum[3][22], "userNum4" : userNum[4][22], "userNum5" : userNum[5][22], "userNum6" : userNum[6][22]
		}, {
			"date" : "23시",
			"userNum" : userNum[0][23], "userNum1" : userNum[1][23], "userNum2" : userNum[2][23],
			"userNum3" : userNum[3][23], "userNum4" : userNum[4][23], "userNum5" : userNum[5][23], "userNum6" : userNum[6][23]
		} ];
	
	fn_makeGraph1(data);
	
	var data2 = [ {
		"date" : "0시",
		"userNum" : userNum2[0][0], "userNum1" : userNum2[1][0], "userNum2" : userNum2[2][0]
	}, {
		"date" : "1시",
		"userNum" : userNum2[0][1], "userNum1" : userNum2[1][1], "userNum2" : userNum2[2][1]
	}, {
		"date" : "2시",
		"userNum" : userNum2[0][2], "userNum1" : userNum2[1][2], "userNum2" : userNum2[2][2]
	}, {
		"date" : "3시",
		"userNum" : userNum2[0][3], "userNum1" : userNum2[1][3], "userNum2" : userNum2[2][3]
	}, {
		"date" : "4시",
		"userNum" : userNum2[0][4], "userNum1" : userNum2[1][4], "userNum2" : userNum2[2][4]
	}, {
		"date" : "5시",
		"userNum" : userNum2[0][5], "userNum1" : userNum2[1][5], "userNum2" : userNum2[2][5]
	}, {
		"date" : "6시",
		"userNum" : userNum2[0][6], "userNum1" : userNum2[1][6], "userNum2" : userNum2[2][6]
	}, {
		"date" : "7시",
		"userNum" : userNum2[0][7], "userNum1" : userNum2[1][7], "userNum2" : userNum2[2][7]
	}, {
		"date" : "8시",
		"userNum" : userNum2[0][8], "userNum1" : userNum2[1][8], "userNum2" : userNum2[2][8]
	}, {
		"date" : "9시",
		"userNum" : userNum2[0][9], "userNum1" : userNum2[1][9], "userNum2" : userNum2[2][9]
	}, {
		"date" : "10시",
		"userNum" : userNum2[0][10], "userNum1" : userNum2[1][10], "userNum2" : userNum2[2][10]
	}, {
		"date" : "11시",
		"userNum" : userNum2[0][11], "userNum1" : userNum2[1][11], "userNum2" : userNum2[2][11]
	}, {
		"date" : "12시",
		"userNum" : userNum2[0][12], "userNum1" : userNum2[1][12], "userNum2" : userNum2[2][12]
	}, {
		"date" : "13시",
		"userNum" : userNum2[0][13], "userNum1" : userNum2[1][13], "userNum2" : userNum2[2][13]
	}, {
		"date" : "14시",
		"userNum" : userNum2[0][14], "userNum1" : userNum2[1][14], "userNum2" : userNum2[2][14]
	}, {
		"date" : "15시",
		"userNum" : userNum2[0][15], "userNum1" : userNum2[1][15], "userNum2" : userNum2[2][15]
	}, {
		"date" : "16시",
		"userNum" : userNum2[0][16], "userNum1" : userNum2[1][16], "userNum2" : userNum2[2][16]
	}, {
		"date" : "17시",
		"userNum" : userNum2[0][17], "userNum1" : userNum2[1][17], "userNum2" : userNum2[2][17]
	}, {
		"date" : "18시",
		"userNum" : userNum2[0][18], "userNum1" : userNum2[1][18], "userNum2" : userNum2[2][18]
	}, {
		"date" : "19시",
		"userNum" : userNum2[0][19], "userNum1" : userNum2[1][19], "userNum2" : userNum2[2][19]
	}, {
		"date" : "20시",
		"userNum" : userNum2[0][20], "userNum1" : userNum2[1][20], "userNum2" : userNum2[2][20]
	}, {
		"date" : "21시",
		"userNum" : userNum2[0][21], "userNum1" : userNum2[1][21], "userNum2" : userNum2[2][21]
	}, {
		"date" : "22시",
		"userNum" : userNum2[0][22], "userNum1" : userNum2[1][22], "userNum2" : userNum2[2][22]
	}, {
		"date" : "23시",
		"userNum" : userNum2[0][23], "userNum1" : userNum2[1][23], "userNum2" : userNum2[2][23]
	} ] ;
	
	
	fn_makeGraph2(data2);
	
}

// 일별 그래프 로드
function fn_dateAxis(userNum, userNum2){
	var data = [ {
		    	"date": "1일",
		    	"userNum": userNum[0][1], "userNum1":userNum[1][1], "userNum2":userNum[2][1], 
		        "userNum3":userNum[3][1], "userNum4":userNum[4][1], "userNum5":userNum[5][1],
		        "userNum6":userNum[6][1]
		    }, {
		    	"date": "2일",
		    	"userNum": userNum[0][2], "userNum1":userNum[1][2], "userNum2":userNum[2][2], 
		    	"userNum3":userNum[3][2], "userNum4":userNum[4][2],"userNum5":userNum[5][2], 
		    	"userNum6":userNum[6][2]
		    }, {
		    	"date": "3일",
		        "userNum": userNum[0][3], "userNum1":userNum[1][3], "userNum2":userNum[2][3], 
		    	"userNum3":userNum[3][3], "userNum4":userNum[4][3], "userNum5":userNum[5][3], 
		    	"userNum6":userNum[6][3]
		    }, {
		    	"date": "4일",
		        "userNum": userNum[0][4], "userNum1":userNum[1][4], "userNum2":userNum[2][4], 
		    	"userNum3":userNum[3][4], "userNum4":userNum[4][4], "userNum5":userNum[5][4], 
		    	"userNum6":userNum[6][4]
		    }, {
		    	"date": "5일",
		    	"userNum": userNum[0][5], "userNum1":userNum[1][5], "userNum2":userNum[2][5], 
		    	"userNum3":userNum[3][5], "userNum4":userNum[4][5], "userNum5":userNum[5][5],
		    	"userNum6":userNum[6][5]
		    }, {
		    	"date": "6일",
		    	"userNum": userNum[0][6], "userNum1":userNum[1][6], "userNum2":userNum[2][6], 
		    	"userNum3":userNum[3][6], "userNum4":userNum[4][6], "userNum5":userNum[5][6], 
		    	"userNum6":userNum[6][6]
		    }, {
		    	"date": "7일",
		    	"userNum": userNum[0][7], "userNum1":userNum[1][7], "userNum2":userNum[2][7], 
		    	"userNum3":userNum[3][7], "userNum4":userNum[4][7], "userNum5":userNum[5][7], 
		    	"userNum6":userNum[6][7]
		    }, {
		    	"date": "8일",
		    	"userNum": userNum[0][8], "userNum1":userNum[1][8], "userNum2":userNum[2][8], 
		    	"userNum3":userNum[3][8], "userNum4":userNum[4][8], "userNum5":userNum[5][8], 
		    	"userNum6":userNum[6][8]
		    }, {
		    	"date": "9일",
		    	"userNum": userNum[0][9], "userNum1":userNum[1][9], "userNum2":userNum[2][9], 
		    	"userNum3":userNum[3][9], "userNum4":userNum[4][9], "userNum5":userNum[5][9], 
		    	"userNum6":userNum[6][9]
		    }, {
		    	"date": "10일",
		    	"userNum": userNum[0][10], "userNum1":userNum[1][10], "userNum2":userNum[2][10], 
		    	"userNum3":userNum[3][10], "userNum4":userNum[4][10], "userNum5":userNum[5][10], 
		    	"userNum6":userNum[6][10]
		    }, {
		    	"date": "11일",
		    	"userNum": userNum[0][11], "userNum1":userNum[1][11], "userNum2":userNum[2][11], 
		    	"userNum3":userNum[3][11], "userNum4":userNum[4][11], "userNum5":userNum[5][11], 
		    	"userNum6":userNum[6][11]
		    }, {
		    	"date": "12일",
		    	"userNum": userNum[0][12], "userNum1":userNum[1][12], "userNum2":userNum[2][12], 
		    	"userNum3":userNum[3][12], "userNum4":userNum[4][12], "userNum5":userNum[5][12], 
		    	"userNum6":userNum[6][12]
		    }, {
		    	"date": "13일",
		    	"userNum": userNum[0][13], "userNum1":userNum[1][13], "userNum2":userNum[2][13], 
		    	"userNum3":userNum[3][13], "userNum4":userNum[4][13], "userNum5":userNum[5][13], 
		    	"userNum6":userNum[6][13]
		    }, {
		    	"date": "14일",
		    	"userNum": userNum[0][14], "userNum1":userNum[1][14], "userNum2":userNum[2][14], 
		    	"userNum3":userNum[3][14], "userNum4":userNum[4][14], "userNum5":userNum[5][14], 
		    	"userNum6":userNum[6][14]
		    }, {
		    	"date": "15일",
		    	"userNum": userNum[0][15], "userNum1":userNum[1][15], "userNum2":userNum[2][15], 
		    	"userNum3":userNum[3][15], "userNum4":userNum[4][15], "userNum5":userNum[5][15], 
		    	"userNum6":userNum[6][15]
		    }, {
		    	"date": "16일",
		    	"userNum": userNum[0][16], "userNum1":userNum[1][16], "userNum2":userNum[2][16], 
		    	"userNum3":userNum[3][16], "userNum4":userNum[4][16], "userNum5":userNum[5][16], 
		    	"userNum6":userNum[6][16]
		    }, {
		    	"date": "17일",
		    	"userNum": userNum[0][17], "userNum1":userNum[1][17], "userNum2":userNum[2][17], 
		    	"userNum3":userNum[3][17], "userNum4":userNum[4][17], "userNum5":userNum[5][17], 
		    	"userNum6":userNum[6][17]
		    }, {
		    	"date": "18일",
		    	"userNum": userNum[0][18], "userNum1":userNum[1][18], "userNum2":userNum[2][18], 
		    	"userNum3":userNum[3][18], "userNum4":userNum[4][18], "userNum5":userNum[5][18], 
		    	"userNum6":userNum[6][18]
		    }, {
		    	"date": "19일",
		    	"userNum": userNum[0][19], "userNum1":userNum[1][19], "userNum2":userNum[2][19], 
		    	"userNum3":userNum[3][19], "userNum4":userNum[4][19], "userNum5":userNum[5][19], 
		    	"userNum6":userNum[6][19]
		    }, {
		    	"date": "20일",
		    	"userNum": userNum[0][20], "userNum1":userNum[1][20], "userNum2":userNum[2][20], 
		    	"userNum3":userNum[3][20], "userNum4":userNum[4][20], "userNum5":userNum[5][20], 
		    	"userNum6":userNum[6][20]
		    }, {
		    	"date": "21일",
		    	"userNum": userNum[0][21], "userNum1":userNum[1][21], "userNum2":userNum[2][21], 
		    	"userNum3":userNum[3][21], "userNum4":userNum[4][21], "userNum5":userNum[5][21], 
		    	"userNum6":userNum[6][21]
		    }, {
		    	"date": "22일",
		    	"userNum": userNum[0][22], "userNum1":userNum[1][22], "userNum2":userNum[2][22], 
		    	"userNum3":userNum[3][22], "userNum4":userNum[4][22], "userNum5":userNum[5][22], 
		    	"userNum6":userNum[6][22]
		    }, {
		    	"date": "23일",
		    	"userNum": userNum[0][23], "userNum1":userNum[1][23], "userNum2":userNum[2][23], 
		    	"userNum3":userNum[3][23], "userNum4":userNum[4][23], "userNum5":userNum[5][23], 
		    	"userNum6":userNum[6][23]
		    },{
		    	"date": "24일",
		    	"userNum": userNum[0][24], "userNum1":userNum[1][24], "userNum2":userNum[2][24], 
		    	"userNum3":userNum[3][24], "userNum4":userNum[4][24], "userNum5":userNum[5][24], 
		    	"userNum6":userNum[6][24]
		    } ,{
		    	"date": "25일",
		    	"userNum": userNum[0][25], "userNum1":userNum[1][25], "userNum2":userNum[2][25], 
		    	"userNum3":userNum[3][25], "userNum4":userNum[4][25], "userNum5":userNum[5][25], 
		    	"userNum6":userNum[6][25]
		    } ,{
		    	"date": "26일",
		    	"userNum": userNum[0][26], "userNum1":userNum[1][26], "userNum2":userNum[2][26], 
		    	"userNum3":userNum[3][26], "userNum4":userNum[4][26], "userNum5":userNum[5][26], 
		    	"userNum6":userNum[6][26]
		    } ,{
		    	"date": "27일",
		    	"userNum": userNum[0][27], "userNum1":userNum[1][27], "userNum2":userNum[2][27], 
		    	"userNum3":userNum[3][27], "userNum4":userNum[4][27], "userNum5":userNum[5][27], 
		    	"userNum6":userNum[6][27]
		    } ,{
		    	"date": "28일",
		    	"userNum": userNum[0][28], "userNum1":userNum[1][28], "userNum2":userNum[2][28], 
		    	"userNum3":userNum[3][28], "userNum4":userNum[4][28], "userNum5":userNum[5][28], 
		    	"userNum6":userNum[6][28]
		    } ,{
		    	"date": "29일",
		    	"userNum": userNum[0][29], "userNum1":userNum[1][29], "userNum2":userNum[2][29], 
		    	"userNum3":userNum[3][29], "userNum4":userNum[4][29], "userNum5":userNum[5][29], 
		    	"userNum6":userNum[6][29]
		    } ,{
		    	"date": "30일",
		    	"userNum": userNum[0][30], "userNum1":userNum[1][30], "userNum2":userNum[2][30], 
		    	"userNum3":userNum[3][30], "userNum4":userNum[4][30], "userNum5":userNum[5][30], 
		    	"userNum6":userNum[6][30]
		    } ,{
		    	"date": "31일",
		    	"userNum": userNum[0][31], "userNum1":userNum[1][31], "userNum2":userNum[2][31], 
		    	"userNum3":userNum[3][31], "userNum4":userNum[4][31], "userNum5":userNum[5][31], 
		    	"userNum6":userNum[6][31]
		    } ];
	
	fn_makeGraph1(data);
	
	var data2 = [ {
		    	"date": "1일",
		    	"userNum": userNum2[0][1], "userNum1":userNum2[1][1], "userNum2":userNum2[2][1]
		    }, {
		    	"date": "2일",
		    	"userNum": userNum2[0][2], "userNum1":userNum2[1][2], "userNum2":userNum2[2][2]
		    }, {
		    	"date": "3일",
		        "userNum": userNum2[0][3], "userNum1":userNum2[1][3], "userNum2":userNum2[2][3]
		    }, {
		    	"date": "4일",
		        "userNum": userNum2[0][4], "userNum1":userNum2[1][4], "userNum2":userNum2[2][4]
		    }, {
		    	"date": "5일",
		    	"userNum": userNum2[0][5], "userNum1":userNum2[1][5], "userNum2":userNum2[2][5]
		    }, {
		    	"date": "6일",
		    	"userNum": userNum2[0][6], "userNum1":userNum2[1][6], "userNum2":userNum2[2][6]
		    }, {
		    	"date": "7일",
		    	"userNum": userNum2[0][7], "userNum1":userNum2[1][7], "userNum2":userNum2[2][7]
		    }, {
		    	"date": "8일",
		    	"userNum": userNum2[0][8], "userNum1":userNum2[1][8], "userNum2":userNum2[2][8]
		    }, {
		    	"date": "9일",
		    	"userNum": userNum2[0][9], "userNum1":userNum2[1][9], "userNum2":userNum2[2][9]
		    }, {
		    	"date": "10일",
		    	"userNum": userNum2[0][10], "userNum1":userNum2[1][10], "userNum2":userNum2[2][10]
		    }, {
		    	"date": "11일",
		    	"userNum": userNum2[0][11], "userNum1":userNum2[1][11], "userNum2":userNum2[2][11]
		    }, {
		    	"date": "12일",
		    	"userNum": userNum2[0][12], "userNum1":userNum2[1][12], "userNum2":userNum2[2][12]
		    }, {
		    	"date": "13일",
		    	"userNum": userNum2[0][13], "userNum1":userNum2[1][13], "userNum2":userNum2[2][13]
		    }, {
		    	"date": "14일",
		    	"userNum": userNum2[0][14], "userNum1":userNum2[1][14], "userNum2":userNum2[2][14]
		    }, {
		    	"date": "15일",
		    	"userNum": userNum2[0][15], "userNum1":userNum2[1][15], "userNum2":userNum2[2][15]
		    }, {
		    	"date": "16일",
		    	"userNum": userNum2[0][16], "userNum1":userNum2[1][16], "userNum2":userNum2[2][16]
		    }, {
		    	"date": "17일",
		    	"userNum": userNum2[0][17], "userNum1":userNum2[1][17], "userNum2":userNum2[2][17]
		    }, {
		    	"date": "18일",
		    	"userNum": userNum2[0][18], "userNum1":userNum2[1][18], "userNum2":userNum2[2][18]
		    }, {
		    	"date": "19일",
		    	"userNum": userNum2[0][19], "userNum1":userNum2[1][19], "userNum2":userNum2[2][19]
		    }, {
		    	"date": "20일",
		    	"userNum": userNum2[0][20], "userNum1":userNum2[1][20], "userNum2":userNum2[2][20]
		    }, {
		    	"date": "21일",
		    	"userNum": userNum2[0][21], "userNum1":userNum2[1][21], "userNum2":userNum2[2][21]
		    }, {
		    	"date": "22일",
		    	"userNum": userNum2[0][22], "userNum1":userNum2[1][22], "userNum2":userNum2[2][22]
		    }, {
		    	"date": "23일",
		    	"userNum": userNum2[0][23], "userNum1":userNum2[1][23], "userNum2":userNum2[2][23]
		    },{
		    	"date": "24일",
		    	"userNum": userNum2[0][24], "userNum1":userNum2[1][24], "userNum2":userNum2[2][24]
		    } ,{
		    	"date": "25일",
		    	"userNum": userNum2[0][25], "userNum1":userNum2[1][25], "userNum2":userNum2[2][25]
		    } ,{
		    	"date": "26일",
		    	"userNum": userNum2[0][26], "userNum1":userNum2[1][26], "userNum2":userNum2[2][26]
		    } ,{
		    	"date": "27일",
		    	"userNum": userNum2[0][27], "userNum1":userNum2[1][27], "userNum2":userNum2[2][27]
		    } ,{
		    	"date": "28일",
		    	"userNum": userNum2[0][28], "userNum1":userNum2[1][28], "userNum2":userNum2[2][28]
		    } ,{
		    	"date": "29일",
		    	"userNum": userNum2[0][29], "userNum1":userNum2[1][29], "userNum2":userNum2[2][29]
		    } ,{
		    	"date": "30일",
		    	"userNum": userNum2[0][30], "userNum1":userNum2[1][30], "userNum2":userNum2[2][30]
		    } ,{
		    	"date": "31일",
		    	"userNum": userNum2[0][31], "userNum1":userNum2[1][31], "userNum2":userNum2[2][31]
		    } ];
	
	fn_makeGraph2(data2);
}

// 월별 그래프 로드
function fn_monthAxis(userNum, userNum2){
	var data = [ {
		    	"date": "1월",
		    	"userNum": userNum[0][1], "userNum1":userNum[1][1], "userNum2":userNum[2][1], 
		        "userNum3":userNum[3][1], "userNum4":userNum[4][1], "userNum5":userNum[5][1],
		        "userNum6":userNum[6][1]
		    }, {
		    	"date": "2월",
		    	"userNum": userNum[0][2], "userNum1":userNum[1][2], "userNum2":userNum[2][2], 
		    	"userNum3":userNum[3][2], "userNum4":userNum[4][2],"userNum5":userNum[5][2], 
		    	"userNum6":userNum[6][2]
		    }, {
		    	"date": "3월",
		        "userNum": userNum[0][3], "userNum1":userNum[1][3], "userNum2":userNum[2][3], 
		    	"userNum3":userNum[3][3], "userNum4":userNum[4][3], "userNum5":userNum[5][3], 
		    	"userNum6":userNum[6][3]
		    }, {
		    	"date": "4월",
		        "userNum": userNum[0][4], "userNum1":userNum[1][4], "userNum2":userNum[2][4], 
		    	"userNum3":userNum[3][4], "userNum4":userNum[4][4], "userNum5":userNum[5][4], 
		    	"userNum6":userNum[6][4]
		    }, {
		    	"date": "5월",
		    	"userNum": userNum[0][5], "userNum1":userNum[1][5], "userNum2":userNum[2][5], 
		    	"userNum3":userNum[3][5], "userNum4":userNum[4][5], "userNum5":userNum[5][5],
		    	"userNum6":userNum[6][5]
		    }, {
		    	"date": "6월",
		    	"userNum": userNum[0][6], "userNum1":userNum[1][6], "userNum2":userNum[2][6], 
		    	"userNum3":userNum[3][6], "userNum4":userNum[4][6], "userNum5":userNum[5][6], 
		    	"userNum6":userNum[6][6]
		    }, {
		    	"date": "7월",
		    	"userNum": userNum[0][7], "userNum1":userNum[1][7], "userNum2":userNum[2][7], 
		    	"userNum3":userNum[3][7], "userNum4":userNum[4][7], "userNum5":userNum[5][7], 
		    	"userNum6":userNum[6][7]
		    }, {
		    	"date": "8월",
		    	"userNum": userNum[0][8], "userNum1":userNum[1][8], "userNum2":userNum[2][8], 
		    	"userNum3":userNum[3][8], "userNum4":userNum[4][8], "userNum5":userNum[5][8], 
		    	"userNum6":userNum[6][8]
		    }, {
		    	"date": "9월",
		    	"userNum": userNum[0][9], "userNum1":userNum[1][9], "userNum2":userNum[2][9], 
		    	"userNum3":userNum[3][9], "userNum4":userNum[4][9], "userNum5":userNum[5][9], 
		    	"userNum6":userNum[6][9]
		    }, {
		    	"date": "10월",
		    	"userNum": userNum[0][10], "userNum1":userNum[1][10], "userNum2":userNum[2][10], 
		    	"userNum3":userNum[3][10], "userNum4":userNum[4][10], "userNum5":userNum[5][10], 
		    	"userNum6":userNum[6][10]
		    }, {
		    	"date": "11월",
		    	"userNum": userNum[0][11], "userNum1":userNum[1][11], "userNum2":userNum[2][11], 
		    	"userNum3":userNum[3][11], "userNum4":userNum[4][11], "userNum5":userNum[5][11], 
		    	"userNum6":userNum[6][11]
		    }, {
		    	"date": "12월",
		    	"userNum": userNum[0][12], "userNum1":userNum[1][12], "userNum2":userNum[2][12], 
		    	"userNum3":userNum[3][12], "userNum4":userNum[4][12], "userNum5":userNum[5][12], 
		    	"userNum6":userNum[6][12]
		    }];
	
	fn_makeGraph1(data);
	
	var data2 = [ {
		    	"date": "1월",
		    	"userNum": userNum2[0][1], "userNum1":userNum2[1][1], "userNum2":userNum2[2][1]
		    }, {
		    	"date": "2월",
		    	"userNum": userNum2[0][2], "userNum1":userNum2[1][2], "userNum2":userNum2[2][2]
		    }, {
		    	"date": "3월",
		        "userNum": userNum2[0][3], "userNum1":userNum2[1][3], "userNum2":userNum2[2][3]
		    }, {
		    	"date": "4월",
		        "userNum": userNum2[0][4], "userNum1":userNum2[1][4], "userNum2":userNum2[2][4]
		    }, {
		    	"date": "5월",
		    	"userNum": userNum2[0][5], "userNum1":userNum2[1][5], "userNum2":userNum2[2][5]
		    }, {
		    	"date": "6월",
		    	"userNum": userNum2[0][6], "userNum1":userNum2[1][6], "userNum2":userNum2[2][6]
		    }, {
		    	"date": "7월",
		    	"userNum": userNum2[0][7], "userNum1":userNum2[1][7], "userNum2":userNum2[2][7]
		    }, {
		    	"date": "8월",
		    	"userNum": userNum2[0][8], "userNum1":userNum2[1][8], "userNum2":userNum2[2][8]
		    }, {
		    	"date": "9월",
		    	"userNum": userNum2[0][9], "userNum1":userNum2[1][9], "userNum2":userNum2[2][9]
		    }, {
		    	"date": "10월",
		    	"userNum": userNum2[0][10], "userNum1":userNum2[1][10], "userNum2":userNum2[2][10]
		    }, {
		    	"date": "11월",
		    	"userNum": userNum2[0][11], "userNum1":userNum2[1][11], "userNum2":userNum2[2][11]
		    }, {
		    	"date": "12월",
		    	"userNum": userNum2[0][12], "userNum1":userNum2[1][12], "userNum2":userNum2[2][12]
		    }];
	
	fn_makeGraph2(data2);
}

//연도별 그래프 로드
function fn_yearAxis(userNum, userNum2){
	var data = [ {
		    	"date": "2016년",
		    	"userNum": userNum[0][6], "userNum1":userNum[1][6], "userNum2":userNum[2][6], 
		        "userNum3":userNum[3][6], "userNum4":userNum[4][6], "userNum5":userNum[5][6],
		        "userNum6":userNum[6][6]
		    }, {
		    	"date": "2017년",
		    	"userNum": userNum[0][7], "userNum1":userNum[1][7], "userNum2":userNum[2][7], 
		    	"userNum3":userNum[3][7], "userNum4":userNum[4][7],"userNum5":userNum[5][7], 
		    	"userNum6":userNum[6][7]
		    }, {
		    	"date": "2018년",
		        "userNum": userNum[0][8], "userNum1":userNum[1][8], "userNum2":userNum[2][8], 
		    	"userNum3":userNum[3][8], "userNum4":userNum[4][8], "userNum5":userNum[5][8], 
		    	"userNum6":userNum[6][8]
		    }, {
		    	"date": "2019년",
		        "userNum": userNum[0][9], "userNum1":userNum[1][9], "userNum2":userNum[2][9], 
		    	"userNum3":userNum[3][9], "userNum4":userNum[4][9], "userNum5":userNum[5][9], 
		    	"userNum6":userNum[6][9]
		    }, {
		    	"date": "2020년",
		    	"userNum": userNum[0][10], "userNum1":userNum[1][10], "userNum2":userNum[2][10], 
		    	"userNum3":userNum[3][10], "userNum4":userNum[4][10], "userNum5":userNum[5][10],
		    	"userNum6":userNum[6][10]
		    }, {
		    	"date": "2021년",
		    	"userNum": userNum[0][11], "userNum1":userNum[1][11], "userNum2":userNum[2][11], 
		    	"userNum3":userNum[3][11], "userNum4":userNum[4][11], "userNum5":userNum[5][11], 
		    	"userNum6":userNum[6][11]
		    }, {
		    	"date": "2022년",
		    	"userNum": userNum[0][12], "userNum1":userNum[1][12], "userNum2":userNum[2][12], 
		    	"userNum3":userNum[3][12], "userNum4":userNum[4][12], "userNum5":userNum[5][12], 
		    	"userNum6":userNum[6][12]
		    }, {
		    	"date": "2023년",
		    	"userNum": userNum[0][13], "userNum1":userNum[1][13], "userNum2":userNum[2][13], 
		    	"userNum3":userNum[3][13], "userNum4":userNum[4][13], "userNum5":userNum[5][13], 
		    	"userNum6":userNum[6][13]
		    }, {
		    	"date": "2024년",
		    	"userNum": userNum[0][14], "userNum1":userNum[1][14], "userNum2":userNum[2][14], 
		    	"userNum3":userNum[3][14], "userNum4":userNum[4][14], "userNum5":userNum[5][14], 
		    	"userNum6":userNum[6][14]
		    }, {
		    	"date": "2025년",
		    	"userNum": userNum[0][15], "userNum1":userNum[1][15], "userNum2":userNum[2][15], 
		    	"userNum3":userNum[3][15], "userNum4":userNum[4][15], "userNum5":userNum[5][15], 
		    	"userNum6":userNum[6][15]
		    }, {
		    	"date": "2026년",
		    	"userNum": userNum[0][16], "userNum1":userNum[1][16], "userNum2":userNum[2][16], 
		    	"userNum3":userNum[3][16], "userNum4":userNum[4][16], "userNum5":userNum[5][16], 
		    	"userNum6":userNum[6][16]
		    }, {
		    	"date": "2027년",
		    	"userNum": userNum[0][17], "userNum1":userNum[1][17], "userNum2":userNum[2][17], 
		    	"userNum3":userNum[3][17], "userNum4":userNum[4][17], "userNum5":userNum[5][17], 
		    	"userNum6":userNum[6][17]
		    }, {
		    	"date": "2028년",
		    	"userNum": userNum[0][18], "userNum1":userNum[1][18], "userNum2":userNum[2][18], 
		    	"userNum3":userNum[3][18], "userNum4":userNum[4][18], "userNum5":userNum[5][18], 
		    	"userNum6":userNum[6][18]
		    }, {
		    	"date": "2029년",
		    	"userNum": userNum[0][19], "userNum1":userNum[1][19], "userNum2":userNum[2][19], 
		    	"userNum3":userNum[3][19], "userNum4":userNum[4][19], "userNum5":userNum[5][19], 
		    	"userNum6":userNum[6][19]
		    }];
	
	fn_makeGraph1(data);
	
	var data2 = [ {
		    	"date": "2016년",
		    	"userNum": userNum2[0][6], "userNum1":userNum2[1][6], "userNum2":userNum2[2][6]
		    }, {
		    	"date": "2017년",
		    	"userNum": userNum2[0][7], "userNum1":userNum2[1][7], "userNum2":userNum2[2][7]
		    }, {
		    	"date": "2018년",
		        "userNum": userNum2[0][8], "userNum1":userNum2[1][8], "userNum2":userNum2[2][8]
		    }, {
		    	"date": "2019년",
		        "userNum": userNum2[0][9], "userNum1":userNum2[1][9], "userNum2":userNum2[2][9]
		    }, {
		    	"date": "2020년",
		    	"userNum": userNum2[0][10], "userNum1":userNum2[1][10], "userNum2":userNum2[2][10]
		    }, {
		    	"date": "2021년",
		    	"userNum": userNum2[0][11], "userNum1":userNum2[1][11], "userNum2":userNum2[2][11]
		    }, {
		    	"date": "2022년",
		    	"userNum": userNum2[0][12], "userNum1":userNum2[1][12], "userNum2":userNum2[2][12]
		    }, {
		    	"date": "2023년",
		    	"userNum": userNum2[0][13], "userNum1":userNum2[1][13], "userNum2":userNum2[2][13]
		    }, {
		    	"date": "2024년",
		    	"userNum": userNum2[0][14], "userNum1":userNum2[1][14], "userNum2":userNum2[2][14]
		    }, {
		    	"date": "2025년",
		    	"userNum": userNum2[0][15], "userNum1":userNum2[1][15], "userNum2":userNum2[2][15]
		    }, {
		    	"date": "2026년",
		    	"userNum": userNum2[0][16], "userNum1":userNum2[1][16], "userNum2":userNum2[2][16]
		    }, {
		    	"date": "2027년",
		    	"userNum": userNum2[0][17], "userNum1":userNum2[1][17], "userNum2":userNum2[2][17]
		    }, {
		    	"date": "2028년",
		    	"userNum": userNum2[0][18], "userNum1":userNum2[1][18], "userNum2":userNum2[2][18]
		    }, {
		    	"date": "2029년",
		    	"userNum": userNum2[0][19], "userNum1":userNum2[1][19], "userNum2":userNum2[2][19]
		    }];
	
	fn_makeGraph2(data2);
}

// 새로고침
function fn_selectedDate(){
	var date = new Array();
	date[0] = document.getElementById('s2');	// 년
	date[1] = document.getElementById('s3');	// 월
	date[2] = document.getElementById('s4');	// 일

	if(date[0].disabled==true) date[0] = 0;
	else date[0] = date[0].value.substr(1,date[0].value.length);
	
	if(date[1].disabled==true) date[1] = 0;
	else	date[1] = date[1].value.substr(1,date[1].value.length);
	
	if(date[2].disabled==true) date[2] = 0;
	else date[2] = date[2].value.substr(1,date[2].value.length);

//	alert(year+","+month+","+date);
	fn_loadGraph(date);
}


/* 회원학습 결과추이 */

function fn_changeStudy(study){
	if(study.indexOf("1") > -1) { // 전체
		fn_showTotal();
	} else if(study.indexOf("2") > -1) { // 음절
		fn_showSyllable();
	} else if(study.indexOf("3") > -1) { // 단어
		fn_showWord();
	} else if(study.indexOf("4") > -1) { // 문장
		fn_showSentence();
	}
}

function fn_makeGraph3(data){
	var chart3 = AmCharts.makeChart("chartdiv3", {
		"type" : "serial",
		"theme" : "light",
		"legend" : {
			"equalWidths" : false,
			"useGraphSettings" : true,
			"valueAlign" : "left",
			"valueWidth" : 120
		},
		"dataProvider" : data,
		"valueField" : "userNum",
		"valueAxes" : [ {
			"id" : "userAxis",
			"axisAlpha" : 0,
			"gridAlpha" : 0,
			"position" : "left",
			"title" : "학습정확도 (%)"
		}, {
			"id" : "dateAxis",
			"axisAlpha" : 0,
			"gridAlpha" : 0,
			"labelsEnabled" : false,
			"position" : "right"
		} ],
		"graphs" : [{
			"bullet" : "square",
			"bulletBorderAlpha" : 1,
			"bulletBorderThickness" : 1,
			"dashLengthField" : "dashLength",
			"legendValueText" : "[[value]]%",
			"title" : "1급",
			"fillAlphas" : 0,
			"valueField" : "userNum1",
			"valueAxis" : "userAxis"
		}, {
			"bullet" : "square",
			"bulletBorderAlpha" : 1,
			"bulletBorderThickness" : 1,
			"dashLengthField" : "dashLength",
			"legendValueText" : "[[value]]%",
			"title" : "2급",
			"fillAlphas" : 0,
			"valueField" : "userNum2",
			"valueAxis" : "userAxis"
		}, {
			"bullet" : "square",
			"bulletBorderAlpha" : 1,
			"bulletBorderThickness" : 1,
			"dashLengthField" : "dashLength",
			"legendValueText" : "[[value]]%",
			"title" : "3급",
			"fillAlphas" : 0,
			"valueField" : "userNum3",
			"valueAxis" : "userAxis"
		}, {
			"bullet" : "square",
			"bulletBorderAlpha" : 1,
			"bulletBorderThickness" : 1,
			"dashLengthField" : "dashLength",
			"legendValueText" : "[[value]]%",
			"title" : "4급",
			"fillAlphas" : 0,
			"valueField" : "userNum4",
			"valueAxis" : "userAxis"
		}, {
			"bullet" : "square",
			"bulletBorderAlpha" : 1,
			"bulletBorderThickness" : 1,
			"dashLengthField" : "dashLength",
			"legendValueText" : "[[value]]%",
			"title" : "5급",
			"fillAlphas" : 0,
			"valueField" : "userNum5",
			"valueAxis" : "userAxis"
		}, {
			"bullet" : "square",
			"bulletBorderAlpha" : 1,
			"bulletBorderThickness" : 1,
			"dashLengthField" : "dashLength",
			"legendValueText" : "[[value]]%",
			"title" : "6급",
			"fillAlphas" : 0,
			"valueField" : "userNum6",
			"valueAxis" : "userAxis"
		} ],
		"chartCursor" : {
			"cursorAlpha" : 0.1,
			"cursorColor" : "#000000",
			"fullWidth" : true,
			"valueBalloonsEnabled" : false,
			"zoomable" : false
		},
		"categoryField" : "time",
		"categoryAxis" : {
			"gridPosition" : "start",
			"labelRotation" : 45
		},
		"export" : {
			"enabled" : true
		}
	});
}

function fn_showTotal(){	
	var chart3 = AmCharts.makeChart("chartdiv3", {
		"type" : "serial",
		"theme" : "light",
		"legend" : {
			"equalWidths" : false,
			"useGraphSettings" : true,
			"valueAlign" : "left",
			"valueWidth" : 120
		},
		"dataProvider" :  [ {
			"time" : "1회",
			"userNum" : total_acc[3][0],
			"userNum1" : accuracy1[0][0],
			"userNum2" : accuracy2[0][0],
			"userNum3" : accuracy3[0][0]
		}, {
			"time" : "2회",
			"userNum" : total_acc[3][1],
			"userNum1" : accuracy1[0][1],
			"userNum2" : accuracy2[0][1],
			"userNum3" : accuracy3[0][1]
		}, {
			"time" : "3회",
			"userNum" : total_acc[3][2],
			"userNum1" : accuracy1[0][2],
			"userNum2" : accuracy2[0][2],
			"userNum3" : accuracy3[0][2]
		}, {
			"time" : "4회",
			"userNum" : total_acc[3][3],
			"userNum1" : accuracy1[0][3],
			"userNum2" : accuracy2[0][3],
			"userNum3" : accuracy3[0][3]
		}, {
			"time" : "5회",
			"userNum" : total_acc[3][4],
			"userNum1" : accuracy1[0][4],
			"userNum2" : accuracy2[0][4],
			"userNum3" : accuracy3[0][4]
		}], 
		"valueField" : "userNum",
		"valueAxes" : [ {
			"id" : "userAxis",
			"axisAlpha" : 0,
			"gridAlpha" : 0,
			"position" : "left",
			"title" : "학습정확도 (%)"
		}, {
			"id" : "dateAxis",
			"axisAlpha" : 0,
			"gridAlpha" : 0,
			"labelsEnabled" : false,
			"position" : "right"
		} ],
		"graphs" : [ {
			"balloonText" : "[[value]]%",
			"bullet" : "round",
			"bulletBorderAlpha" : 1,
			"useLineColorForBulletBorder" : true,
			"bulletColor" : "#FFFFFF",
			"bulletSizeField" : "townSize",
			"dashLengthField" : "dashLength",
			"descriptionField" : "townName",
			"legendValueText" : "[[value]]%",
			"title" : "전체 회원",
			"fillAlphas" : 0,
			"valueField" : "userNum",
			"valueAxis" : "userAxis"
		}, {
			"bullet" : "square",
			"bulletBorderAlpha" : 1,
			"bulletBorderThickness" : 1,
			"dashLengthField" : "dashLength",
			"legendValueText" : "[[value]]%",
			"title" : "음절",
			"fillAlphas" : 0,
			"valueField" : "userNum1",
			"valueAxis" : "userAxis"
		}, {
			"bullet" : "square",
			"bulletBorderAlpha" : 1,
			"bulletBorderThickness" : 1,
			"dashLengthField" : "dashLength",
			"legendValueText" : "[[value]]%",
			"title" : "단어",
			"fillAlphas" : 0,
			"valueField" : "userNum2",
			"valueAxis" : "userAxis"
		}, {
			"bullet" : "square",
			"bulletBorderAlpha" : 1,
			"bulletBorderThickness" : 1,
			"dashLengthField" : "dashLength",
			"legendValueText" : "[[value]]%",
			"title" : "문장",
			"fillAlphas" : 0,
			"valueField" : "userNum3",
			"valueAxis" : "userAxis"
		} ],
		"chartCursor" : {
			"cursorAlpha" : 0.1,
			"cursorColor" : "#000000",
			"fullWidth" : true,
			"valueBalloonsEnabled" : false,
			"zoomable" : false
		},
		"categoryField" : "time",
		"categoryAxis" : {
			"gridPosition" : "start",
			"labelRotation" : 45
		},
		"export" : {
			"enabled" : true
		}
	});

}

function fn_showSyllable() {
		var data = [ {
			"time" : "1회",
			"userNum1" : accuracy1[1][0],
			"userNum2" : accuracy1[2][0],
			"userNum3" : accuracy1[3][0],
			"userNum4" : accuracy1[4][0],
			"userNum5" : accuracy1[5][0],
			"userNum6" : accuracy1[6][0]
		}, {
			"time" : "2회",
			"userNum1" : accuracy1[1][1],
			"userNum2" : accuracy1[2][1],
			"userNum3" : accuracy1[3][1],
			"userNum4" : accuracy1[4][1],
			"userNum5" : accuracy1[5][1],
			"userNum6" : accuracy1[6][1]
		}, {
			"time" : "3회",
			"userNum1" : accuracy1[1][2],
			"userNum2" : accuracy1[2][2],
			"userNum3" : accuracy1[3][2],
			"userNum4" : accuracy1[4][2],
			"userNum5" : accuracy1[5][2],
			"userNum6" : accuracy1[6][2]
		}, {
			"time" : "4회",
			"userNum1" : accuracy1[1][3],
			"userNum2" : accuracy1[2][3],
			"userNum3" : accuracy1[3][3],
			"userNum4" : accuracy1[4][3],
			"userNum5" : accuracy1[5][3],
			"userNum6" : accuracy1[6][3]
		}, {
			"time" : "5회",
			"userNum1" : accuracy1[1][4],
			"userNum2" : accuracy1[2][4],
			"userNum3" : accuracy1[3][4],
			"userNum4" : accuracy1[4][4],
			"userNum5" : accuracy1[5][4],
			"userNum6" : accuracy1[6][4]
		} ];

		fn_makeGraph3(data);
	}

function fn_showWord() {
		var data = [ {
			"time" : "1회",
			"userNum1" : accuracy2[1][0],
			"userNum2" : accuracy2[2][0],
			"userNum3" : accuracy2[3][0],
			"userNum4" : accuracy2[4][0],
			"userNum5" : accuracy2[5][0],
			"userNum6" : accuracy2[6][0]
		}, {
			"time" : "2회",
			"userNum1" : accuracy2[1][1],
			"userNum2" : accuracy2[2][1],
			"userNum3" : accuracy2[3][1],
			"userNum4" : accuracy2[4][1],
			"userNum5" : accuracy2[5][1],
			"userNum6" : accuracy2[6][1]
		}, {
			"time" : "3회",
			"userNum1" : accuracy2[1][2],
			"userNum2" : accuracy2[2][2],
			"userNum3" : accuracy2[3][2],
			"userNum4" : accuracy2[4][2],
			"userNum5" : accuracy2[5][2],
			"userNum6" : accuracy2[6][2]
		}, {
			"time" : "4회",
			"userNum1" : accuracy2[1][3],
			"userNum2" : accuracy2[2][3],
			"userNum3" : accuracy2[3][3],
			"userNum4" : accuracy2[4][3],
			"userNum5" : accuracy2[5][3],
			"userNum6" : accuracy2[6][3]
		}, {
			"time" : "5회",
			"userNum1" : accuracy2[1][4],
			"userNum2" : accuracy2[2][4],
			"userNum3" : accuracy2[3][4],
			"userNum4" : accuracy2[4][4],
			"userNum5" : accuracy2[5][4],
			"userNum6" : accuracy2[6][4]
		} ];

		fn_makeGraph3(data);
	}

function fn_showSentence() {
		var data = [ {
			"time" : "1회",
			"userNum1" : accuracy3[1][0],
			"userNum2" : accuracy3[2][0],
			"userNum3" : accuracy3[3][0],
			"userNum4" : accuracy3[4][0],
			"userNum5" : accuracy3[5][0],
			"userNum6" : accuracy3[6][0]
		}, {
			"time" : "2회",
			"userNum1" : accuracy3[1][1],
			"userNum2" : accuracy3[2][1],
			"userNum3" : accuracy3[3][1],
			"userNum4" : accuracy3[4][1],
			"userNum5" : accuracy3[5][1],
			"userNum6" : accuracy3[6][1]
		}, {
			"time" : "3회",
			"userNum1" : accuracy3[1][2],
			"userNum2" : accuracy3[2][2],
			"userNum3" : accuracy3[3][2],
			"userNum4" : accuracy3[4][2],
			"userNum5" : accuracy3[5][2],
			"userNum6" : accuracy3[6][2]
		}, {
			"time" : "4회",
			"userNum1" : accuracy3[1][3],
			"userNum2" : accuracy3[2][3],
			"userNum3" : accuracy3[3][3],
			"userNum4" : accuracy3[4][3],
			"userNum5" : accuracy3[5][3],
			"userNum6" : accuracy3[6][3]
		}, {
			"time" : "5회",
			"userNum1" : accuracy3[1][4],
			"userNum2" : accuracy3[2][4],
			"userNum3" : accuracy3[3][4],
			"userNum4" : accuracy3[4][4],
			"userNum5" : accuracy3[5][4],
			"userNum6" : accuracy3[6][4]
		} ];

		fn_makeGraph3(data);
	}
