package solugate.ajax.web;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.json.MappingJacksonJsonView;

import egovframework.rte.psl.dataaccess.util.EgovMap;
import solugate.ajax.service.AjaxService;



@Controller
public class AjaxController {
	@Resource MappingJacksonJsonView ajaxMainView;
	
	@Resource(name = "ajaxService")
	private AjaxService ajaxService;
		
	@RequestMapping(value ="/ajax/selectCombo.do")
	public ModelAndView SelectCombo(String selectA)  throws Exception{
		List<EgovMap> list =  ajaxService.selectList(selectA);
		ModelAndView mav = new ModelAndView(ajaxMainView);
		mav.addObject("selectList",list);
		return mav;
	}
	
}
