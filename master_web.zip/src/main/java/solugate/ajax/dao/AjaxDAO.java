package solugate.ajax.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import egovframework.rte.psl.dataaccess.util.EgovMap;


@Repository("ajaxDAO")
public class AjaxDAO extends EgovAbstractDAO{
	
	public List<EgovMap> selectList(String select) throws Exception{
		return (List<EgovMap>) list("ajaxDAO.select", select);
	}

}
