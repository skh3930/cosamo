package solugate.ajax.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;
import egovframework.rte.psl.dataaccess.util.EgovMap;
import solugate.ajax.dao.AjaxDAO;

@Service("ajaxService")
public class AjaxService extends EgovAbstractServiceImpl {
	@Resource(name = "ajaxDAO")
	private AjaxDAO ajaxDAO;

	public List<EgovMap> selectList(String select) throws Exception {
		return ajaxDAO.selectList(select);
	}

}
