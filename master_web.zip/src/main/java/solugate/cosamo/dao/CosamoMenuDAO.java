package solugate.cosamo.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import solugate.cosamo.vo.EngineStudyVO;
import solugate.cosamo.vo.ManagerVO;
import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import egovframework.rte.psl.dataaccess.util.EgovMap;

@Repository("cosamoMenuDAO")
public class CosamoMenuDAO extends EgovAbstractDAO {

	//로그인 
	public List<EgovMap> search_M(ManagerVO mv) throws Exception {
		return (List<EgovMap>) list("CosamoMenuDAO.search_M",mv);
	}

	//버전 콤보박스
	public List<EgovMap> selectVerComboBox() throws Exception {
		return (List<EgovMap>) list("CosamoMenuDAO.selectVerComboBox");
	}
	//음성파일이름
	public List<EgovMap> selectSoundPath() throws Exception {
		return (List<EgovMap>) list("CosamoMenuDAO.selectSoundPath");
	}
	// ID 콤보박스
	public List<EgovMap> selectIDComboBox() throws Exception {
		return (List<EgovMap>) list("CosamoMenuDAO.selectIDComboBox");
	}
	// 학습 콤보박스 1
	public List<EgovMap> search_SC1(EngineStudyVO esv) throws Exception {
		return (List<EgovMap>) list("CosamoMenuDAO.studyCombo1", esv);
	}
	
	// 학습 콤보박스 2
		public List<EgovMap> search_SC2(EngineStudyVO esv) throws Exception {
			return (List<EgovMap>) list("CosamoMenuDAO.studyCombo2", esv);
		}
		
		// 학습 콤보박스 3
		public List<EgovMap> search_SC3(EngineStudyVO esv) throws Exception {
			return (List<EgovMap>) list("CosamoMenuDAO.studyCombo3", esv);
		}
		// 학습 콤보박스 3 - 모범 발음
		public List<EgovMap> search_SC4(EngineStudyVO esv) throws Exception {
			return (List<EgovMap>) list("CosamoMenuDAO.studyCombo4", esv);
		}
	// 결과 리스트
		public List<EgovMap> selectAll_RS() throws Exception {
			return (List<EgovMap>) list("CosamoMenuDAO.selectAll_RS");
		}
		// 결과리스트 - 그래프
		public List<EgovMap> search_ACC() throws Exception {
			return  (List<EgovMap>) list("CosamoMenuDAO.searchACC");
		}
		
		// 학습 완료
		public List<EgovMap> selectAll_ES() throws Exception {
			return (List<EgovMap>) list("CosamoMenuDAO.selectAll_ES");
		}
		
		// 학습 전
		public List<EgovMap> selectAll_ENS() throws Exception {
			return (List<EgovMap>) list("CosamoMenuDAO.selectAll_ENS");
		}	
		
		// 학습 예정
		public List<EgovMap> selectAll_EPS() throws Exception {
			return (List<EgovMap>) list("CosamoMenuDAO.selectAll_EPS");
		}
	public List<EgovMap> selectComboBox_AM() throws Exception {
		return (List<EgovMap>) list("CosamoMenuDAO.selectVer");
	}
	
	public List<EgovMap> selectAll_AM() throws Exception {
		return (List<EgovMap>) list("CosamoMenuDAO.selectAll_AM");
	}

	public List<EgovMap> selectAll_USER() {
		return (List<EgovMap>) list("CosamoMenuDAO.selectAll_USER");
	}

	public List<EgovMap> selectSavingPath() {
		return (List<EgovMap>) list("CosamoMenuDAO.selectSavingPath");
	
	}

	public List<EgovMap> selectSchedule() {
		return (List<EgovMap>) list("CosamoMenuDAO.selectSchedule");
	}

	public List<EgovMap> selectSchedule_ver() {

		return (List<EgovMap>) list("CosamoMenuDAO.selectSchedule_ver");
	}


}
