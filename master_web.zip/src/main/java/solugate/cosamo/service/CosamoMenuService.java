package solugate.cosamo.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import solugate.cosamo.dao.CosamoMenuDAO;
import solugate.cosamo.vo.EngineStudyVO;
import solugate.cosamo.vo.ManagerVO;
import solugate.cosamo.vo.RealtimeGraphVO;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;
import egovframework.rte.psl.dataaccess.util.EgovMap;

@Service("cosamoMenuService")
public class CosamoMenuService extends EgovAbstractServiceImpl {
	@Resource(name = "cosamoMenuDAO")
	private CosamoMenuDAO cosamoMenuDAO;
	
	// 로그인
	public List<EgovMap> search_M(String arr[]) throws Exception {

		ManagerVO mv = new ManagerVO();
		mv.setId(arr[0]);
		mv.setPwd(arr[1]);
		
		return cosamoMenuDAO.search_M(mv);
	}

	// 버전 콤보박스 로드
	public List<EgovMap> selectVerComboBox() throws Exception {
		
		return cosamoMenuDAO.selectVerComboBox();
	}
	// 아이디 콤보박스 로드
	public List<EgovMap> selectIDComboBox() throws Exception {
		
		return cosamoMenuDAO.selectIDComboBox();
	}
	
	//음성파일경로 로드
	public List<EgovMap> selectSoundPath() throws Exception {
		
		return cosamoMenuDAO.selectSoundPath();
	}
	// 학습 콤보박스 1
	public List<EgovMap> search_SC1(String study) throws Exception {
		
		EngineStudyVO esv = new EngineStudyVO();
		esv.setStudy1(study);
		
		return cosamoMenuDAO.search_SC1(esv);
	}
	
	// 학습 콤보박스 2
	public List<EgovMap> search_SC2(String study) throws Exception {
		
		EngineStudyVO esv = new EngineStudyVO();
		esv.setStudy2(study);
		
		return cosamoMenuDAO.search_SC2(esv);
	}

	// 학습 콤보박스 3
	public List<EgovMap> search_SC3(String study) throws Exception {
		
		EngineStudyVO esv = new EngineStudyVO();
		esv.setStudy3(study);
		
		return cosamoMenuDAO.search_SC3(esv);
	}
	// 학습 콤보박스 3 - 모범 발음
	public List<EgovMap> search_SC4(String study) throws Exception {
		
		EngineStudyVO esv = new EngineStudyVO();
		esv.setStudy3(study);
		
		return cosamoMenuDAO.search_SC4(esv);
	}
	//답안관리
	public List<EgovMap> selectComboBox_AM() throws Exception {
		return cosamoMenuDAO.selectComboBox_AM();
	}
	//결과 리스트
	public List<EgovMap> selectAll_RS() throws Exception {
		
		return cosamoMenuDAO.selectAll_RS();
	}
	//결과리스트 - 그래프
	public List<EgovMap> search_ACC() throws Exception {
		
		return cosamoMenuDAO.search_ACC();
	}

	
	// 학습 완료
	public List<EgovMap> selectAll_ES() throws Exception {
		
		return cosamoMenuDAO.selectAll_ES();
	}
	
	// 학습 전
	public List<EgovMap> selectAll_ENS() throws Exception {
		
		return cosamoMenuDAO.selectAll_ENS();
	}
	
	// 학습 예정
	public List<EgovMap> selectAll_EPS() throws Exception {
		
		return cosamoMenuDAO.selectAll_EPS();
	}
	public List<EgovMap> selectAll_AM() throws Exception {
		return cosamoMenuDAO.selectAll_AM();
	}
	

	
	//환경설정
	public List<EgovMap> selectAll_USER() throws Exception {
		return cosamoMenuDAO.selectAll_USER();
	}
	public List<EgovMap> selectPath() throws Exception{
		return cosamoMenuDAO.selectSavingPath();

	}
	public List<EgovMap> selectAll_Schedule() throws Exception{
		return cosamoMenuDAO.selectSchedule();
	}

	public List<EgovMap> selectVer_Schedule() throws Exception{
	
		return cosamoMenuDAO.selectSchedule_ver();
	}





}