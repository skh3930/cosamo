package solugate.cosamo.vo;

public class AnswerManagementVO {
	private String comboSearch;
	private String inputSearch;
	private String inputS4;
	private String comboVer;
	private String comboType;
	private String comboS1;
	private String comboS2;
	private String comboS3;
	private String videoPath;
	private String voicePath;

	private String acc;
	private String sort;
	private String id;
	private String answer;
	private String type;
	
	public String getFb() {
		return fb;
	}
	public void setFb(String fb) {
		this.fb = fb;
	}
	private String fb;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getComboSearch() {
		return comboSearch;
	}
	public void setComboSearch(String comboSearch) {
		this.comboSearch = comboSearch;
	}
	public String getInputSearch() {
		return inputSearch;
	}
	public void setInputSearch(String inputSearch) {
		this.inputSearch = inputSearch;
	}
	public String getComboVer() {
		return comboVer;
	}
	public void setComboVer(String comboVer) {
		this.comboVer = comboVer;
	}
	public String getComboType() {
		return comboType;
	}
	public void setComboType(String comboType) {
		this.comboType = comboType;
	}
	public String getComboS1() {
		return comboS1;
	}
	public void setComboS1(String comboS1) {
		this.comboS1 = comboS1;
	}
	public String getComboS2() {
		return comboS2;
	}
	public void setComboS2(String comboS2) {
		this.comboS2 = comboS2;
	}
	public String getComboS3() {
		return comboS3;
	}
	public void setComboS3(String comboS3) {
		this.comboS3 = comboS3;
	}

	public String getSort() {
		return sort;
	}
	public void setSort(String sort) {
		this.sort = sort;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getInputS4() {
		return inputS4;
	}
	public void setInputS4(String inputS4) {
		this.inputS4 = inputS4;
	}
	public String getVoicePath() {
		return voicePath;
	}
	public void setVoicePath(String voicePath) {
		this.voicePath = voicePath;
	}
	public String getVideoPath() {
		return videoPath;
	}
	public void setVideoPath(String videoPath) {
		this.videoPath = videoPath;
	}
	public String getAcc() {
		return acc;
	}
	public void setAcc(String acc) {
		this.acc = acc;
	}
	


}
