package solugate.cosamo.vo;

public class SettingESSVO {
 private String no;

public String getNo() {
	return no;
}

public void setNo(String no) {
	this.no = no;
}
}
