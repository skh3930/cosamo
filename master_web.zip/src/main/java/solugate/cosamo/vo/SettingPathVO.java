package solugate.cosamo.vo;

public class SettingPathVO {

	public String getUserVoice() {
		return userVoice;
	}
	public void setUserVoice(String userVoice) {
		this.userVoice = userVoice;
	}
	public String getCorrectVoice() {
		return correctVoice;
	}
	public void setCorrectVoice(String correctVoice) {
		this.correctVoice = correctVoice;
	}
	public String getWrongVoice() {
		return wrongVoice;
	}
	public void setWrongVoice(String wrongVoice) {
		this.wrongVoice = wrongVoice;
	}
	public String getCorrectVideo() {
		return correctVideo;
	}
	public void setCorrectVideo(String correctVideo) {
		this.correctVideo = correctVideo;
	}
	private String userVoice;
	private String correctVoice;
	private String wrongVoice;
	private String correctVideo;
}
