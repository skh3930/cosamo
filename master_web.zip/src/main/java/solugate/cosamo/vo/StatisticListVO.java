package solugate.cosamo.vo;

public class StatisticListVO {
	private String year;
	private String month;
	private String date;
	private String time;
	private String totalD; // 날짜필터별 검색을 위한 날짜 string 
	private String totalD2; // 현재접속자수 검색을 위한 날짜 string
	
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getTotalD() {
		return totalD;
	}
	public void setTotalD(String totalD) {
		this.totalD = totalD;
	}
	public String getTotalD2() {
		return totalD2;
	}
	public void setTotalD2(String totalD2) {
		this.totalD2 = totalD2;
	}
}
