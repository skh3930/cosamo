package solugate.cosamo.vo;

public class SettingESVO {

	private int chArr;

	public int getChArr() {
		return chArr;
	}

	public void setChArr(int chArr) {
		this.chArr = chArr;
	}


}
