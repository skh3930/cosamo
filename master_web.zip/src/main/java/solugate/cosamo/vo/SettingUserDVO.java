package solugate.cosamo.vo;

public class SettingUserDVO {
	private int delete;
	public int getDelete() {
		return delete;
	}
	public void setDelete(int delete) {
		this.delete = delete;
	}

}
