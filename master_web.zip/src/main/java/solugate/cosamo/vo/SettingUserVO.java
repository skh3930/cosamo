package solugate.cosamo.vo;

public class SettingUserVO {
	
	private String comboSearch;
	private String inputSearch;

	
	public String getComboSearch() {
		return comboSearch;
	}
	public void setComboSearch(String comboSearch) {
		this.comboSearch = comboSearch;
	}
	public String getInputSearch() {
		return inputSearch;
	}
	public void setInputSearch(String inputSearch) {
		this.inputSearch = inputSearch;
	}





}
