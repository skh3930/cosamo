package solugate.cosamo.vo;

public class SettingESMVO {
	private String inputVer; 
	private String startDate; 
	private String studyDate; 
	private String no; 




	public String getNo() {
		return no;
	}
	public void setNo(String no) {
		this.no = no;
	}
	public String getInputVer() {
		return inputVer;
	}
	public void setInputVer(String inputVer) {
		this.inputVer = inputVer;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getStudyDate() {
		return studyDate;
	}
	public void setStudyDate(String studyDate) {
		this.studyDate = studyDate;
	}

}
