package solugate.cosamo.vo;

public class SettingESAVO {

		private String inputKey;
		private String inputVer; 
		private String startDate; 
		private String studyDate; 
		public String getInputVer() {
			return inputVer;
		}
		public void setInputKey(String inputKey) {
			this.inputKey = inputKey;
		}
		public String getInputKey() {
			return inputKey;
		}
		public void setInputVer(String inputVer) {
			this.inputVer = inputVer;
		}
		public String getStartDate() {
			return startDate;
		}
		public void setStartDate(String startDate) {
			this.startDate = startDate;
		}
		public String getStudyDate() {
			return studyDate;
		}
		public void setStudyDate(String studyDate) {
			this.studyDate = studyDate;
		}
	

	


}
