package solugate.cosamo.vo;

public class ResultListVO {


	
	private String comboID;
	private String inputAcc;
	private String startDate;
	private String endDate;
	private String comboVer;
	private String comboS1;
	private String comboS2;
	private String comboS3;
	private String comboS4;
	public String getComboID() {
		return comboID;
	}
	public void setComboID(String comboID) {
		this.comboID = comboID;
	}
	public String getInputAcc() {
		return inputAcc;
	}
	public void setInputAcc(String inputAcc) {
		this.inputAcc = inputAcc;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getComboVer() {
		return comboVer;
	}
	public void setComboVer(String comboVer) {
		this.comboVer = comboVer;
	}
	public String getComboS1() {
		return comboS1;
	}
	public void setComboS1(String comboS1) {
		this.comboS1 = comboS1;
	}
	public String getComboS2() {
		return comboS2;
	}
	public void setComboS2(String comboS2) {
		this.comboS2 = comboS2;
	}
	public String getComboS3() {
		return comboS3;
	}
	public void setComboS3(String comboS3) {
		this.comboS3 = comboS3;
	}
	public String getComboS4() {
		return comboS4;
	}
	public void setComboS4(String comboS4) {
		this.comboS4 = comboS4;
	}
}
