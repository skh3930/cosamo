package solugate.cosamo.vo;

public class EngineStudyVO {
	// 엔진학습 리스트 키
	private String sndKey;

	// 검색 필터 적용 여부
	private int searchFT;

	// 정확도 오름차순(asc), 내림차순(desc)
	private String sort;

	// 검색콤보 (답안,정확도)
	private String searchCB;
	
	// 검색 입력
	private String input;
	
	// 버전
	private String version;
	
	// 답안 종류
	private String answer;
	
	// 학습 유형
	private String study1;
	
	// 분류
	private String study2;
	
	// 관련 학습
	private String study3;
	
	// 음성 경로
	private String sndPath;
	
	// 오 답안
	private String wrongAns;
	
	// 발음
	private String stdPron;
	
	public String getStdPron() {
		return stdPron;
	}

	public void setStdPron(String stdPron) {
		this.stdPron = stdPron;
	}

	public String getWrongAns() {
		return wrongAns;
	}

	public void setWrongAns(String wrongAns) {
		this.wrongAns = wrongAns;
	}

	public String getSndPath() {
		return sndPath;
	}

	public void setSndPath(String sndPath) {
		this.sndPath = sndPath;
	}

	public String getSndKey() {
		return sndKey;
	}

	public void setSndKey(String sndKey) {
		this.sndKey = sndKey;
	}
	
	// 초기값 0
	public int getSearchFT() {
		return searchFT;
	}

	public void setSearchFT(int searchFT) {
		this.searchFT = searchFT;
	}
	
	public String getSort() {
		return sort;
	}

	public void setSort(String sort) {
		this.sort = sort;
	}
	
	public String getSearchCB() {
		return searchCB;
	}

	public void setSearchCB(String searchCB) {
		this.searchCB = searchCB;
	}

	public String getInput() {
		return input;
	}

	public void setInput(String input) {
		this.input = input;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public String getStudy1() {
		return study1;
	}

	public void setStudy1(String study1) {
		this.study1 = study1;
	}

	public String getStudy2() {
		return study2;
	}

	public void setStudy2(String study2) {
		this.study2 = study2;
	}

	public String getStudy3() {
		return study3;
	}

	public void setStudy3(String study3) {
		this.study3 = study3;
	}

}
