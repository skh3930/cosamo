package solugate.cosamo.web;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.json.MappingJacksonJsonView;

import egovframework.rte.psl.dataaccess.util.EgovMap;
import solugate.cosamo.realtimegraph.service.RealtimeGraphService;
import solugate.cosamo.service.CosamoMenuService;

@Controller
public class CosamoMainController {

	@Resource(name = "cosamoMenuService")
	private CosamoMenuService cosamoMenuService;
	
	@Resource
	MappingJacksonJsonView ajaxMainView;

	@RequestMapping(value="/menu/login.do")
	public ModelAndView managerLogin(String arr[]) throws Exception{
		ModelAndView mav = new ModelAndView(ajaxMainView);
		
		List<EgovMap> resultList = cosamoMenuService.search_M(arr);
		System.out.println(resultList);
		
		if (resultList.size() > 0)
			mav.addObject("login", true);
		else
			mav.addObject("login", false);	
	
		return mav;
	}
//model.addAttribute("webPath", "192.168.0.232") ;
	/* 학습 콤보 시작 */
	@RequestMapping(value="/menu/Modal_AddAnswer.do")
	
	public String addModalPath(HttpServletRequest request, ModelMap model) throws Exception{
		
		//model.addAttribute("fbPath", "http://192.168.0.232:8080") ;
		return "main/Menu/Modal_AddAnswer";
	}
	
	/* 학습 콤보 시작 */
	@RequestMapping(value="/menu/searchSCombo1.do")
	public ModelAndView searchSCombo1(String study) throws Exception{
		ModelAndView mav = new ModelAndView(ajaxMainView);
		
		List<EgovMap> resultList = cosamoMenuService.search_SC1(study);
		System.out.println(resultList+"1");
		
		mav.addObject("resultList", resultList);
		return mav;
	}
	
	@RequestMapping(value="/menu/searchSCombo2.do")
	public ModelAndView searchSCombo2(String study) throws Exception{
		ModelAndView mav = new ModelAndView(ajaxMainView);
		
		List<EgovMap> resultList = cosamoMenuService.search_SC2(study);
		System.out.println(resultList+"2");
		
		mav.addObject("resultList", resultList);
		return mav;
	}
	
	// 오답안
	@RequestMapping(value = "/menu/searchSCombo3.do")
	public ModelAndView searchSCombo3(String study) throws Exception {
		ModelAndView mav = new ModelAndView(ajaxMainView);

		List<EgovMap> resultList = cosamoMenuService.search_SC3(study);
		System.out.println(resultList);

		mav.addObject("resultList", resultList);
		return mav;
	}

	// 모범답안 발음
		@RequestMapping(value="/menu/searchSCombo4.do")
		public ModelAndView searchSCombo4(String study) throws Exception{
			ModelAndView mav = new ModelAndView(ajaxMainView);
			
			List<EgovMap> resultList = cosamoMenuService.search_SC4(study);
			System.out.println(resultList);
			
			mav.addObject("resultList", resultList);
			return mav;
		}
		
	/* 학습 콤보 끝 */
	
	
	@RequestMapping(value="/menu/realtimeGraph.do")
	public String realtimeGraph(HttpServletRequest request, ModelMap model) throws Exception{
		return "main/Menu/RealtimeGraph";
	}
	
	@RequestMapping(value="/menu/statisticList.do")
	public String statisticList(HttpServletRequest request, ModelMap model) throws Exception{
		return "main/Menu/StatisticList";
	}
	
	@RequestMapping(value="/menu/resultList.do")
	public String resultList(HttpServletRequest request, ModelMap model) throws Exception{
		List<EgovMap> soundPathList = cosamoMenuService.selectIDComboBox();
		model.addAttribute("soundPath",soundPathList );
		List<EgovMap> comboIDList = cosamoMenuService.selectIDComboBox();
		model.addAttribute("comboID",comboIDList );
		List<EgovMap> comboList = cosamoMenuService.selectVerComboBox();
		model.addAttribute("comboVer",comboList );
		List<EgovMap> resultList = cosamoMenuService.selectAll_RS();
		model.addAttribute("totalList",resultList );
		return "main/Menu/ResultList";
	}


	@RequestMapping(value="/menu/studiedList.do")
	public String studiedList(HttpServletRequest request, ModelMap model) throws Exception{
		List<EgovMap> comboList = cosamoMenuService.selectVerComboBox();
		model.addAttribute("comboVer",comboList );
		List<EgovMap> esList = cosamoMenuService.selectAll_ES();
		model.addAttribute("totalList",esList );
		return "main/Menu/Engine_StudiedList";
	}

	@RequestMapping(value="/menu/notstudiedList.do")
	public String notstudiedList(HttpServletRequest request, ModelMap model) throws Exception{
		List<EgovMap> ensList = cosamoMenuService.selectAll_ENS();
		model.addAttribute("totalList",ensList );
		System.out.println(ensList);
		return "main/Menu/Engine_NotStudiedList";
	}

	@RequestMapping(value="/menu/prestudiedList.do")
	public String prestudiedList(HttpServletRequest request, ModelMap model) throws Exception{
		List<EgovMap> comboList = cosamoMenuService.selectVerComboBox();
		model.addAttribute("comboVer",comboList );
		List<EgovMap> epsList = cosamoMenuService.selectAll_EPS();
		model.addAttribute("totalList",epsList );
		System.out.println(epsList);
		List<EgovMap> engineVer = cosamoMenuService.selectVer_Schedule();
		model.addAttribute("inputVer",engineVer);
		System.out.println(engineVer);
		return "main/Menu/Engine_PreStudiedList";
	}
	

	@RequestMapping(value="/menu/answerManagement.do")
	public String answerManagement(HttpServletRequest request, ModelMap model) throws Exception{
		
		List<EgovMap> comboList = cosamoMenuService.selectComboBox_AM();
		model.addAttribute("comboVer",comboList );
		List<EgovMap> answerManagement = cosamoMenuService.selectAll_AM();
		model.addAttribute("totalList",answerManagement);
		
		System.out.println(answerManagement);
		return "main/Menu/AnswerManagement";
	}
	
	@RequestMapping(value="/menu/engineScheduler.do")
	public String engineScheduler(HttpServletRequest request, ModelMap model) throws Exception{
		
		List<EgovMap> engineVer = cosamoMenuService.selectVer_Schedule();
		model.addAttribute("inputVer",engineVer);
		System.out.println(engineVer);

		List<EgovMap> engineScheduler = cosamoMenuService.selectAll_Schedule();
		model.addAttribute("totalList",engineScheduler);
		System.out.println(engineScheduler);
		return "main/Menu/Setting_EngineScheduler";
	}
	
	@RequestMapping(value="/menu/savingPath.do")
	public String savingPath(HttpServletRequest request, ModelMap model) throws Exception{
		List<EgovMap> savingPath = cosamoMenuService.selectPath();
		model.addAttribute("inputPath",savingPath);
		System.out.println(savingPath);
		return "main/Menu/Setting_SavingPath";
	}
	
	@RequestMapping(value="/menu/userManagement.do")
	public String userManagement(HttpServletRequest request, ModelMap model) throws Exception{
		List<EgovMap> userManagement = cosamoMenuService.selectAll_USER();
		model.addAttribute("totalList",userManagement);
		System.out.println(userManagement);
		return "main/Menu/Setting_UserManagement";
	}
}
