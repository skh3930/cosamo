package solugate.cosamo.resultlist.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import solugate.cosamo.vo.AnswerManagementVO;
import solugate.cosamo.vo.ResultListVO;
import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import egovframework.rte.psl.dataaccess.util.EgovMap;

@Repository("resultListDAO")
public class ResultListDAO extends EgovAbstractDAO{

	@SuppressWarnings("unchecked")
	public List<EgovMap> search_ACC() throws Exception {
	
		return  (List<EgovMap>) list("ResultListDAO.searchACC");
	}


	@SuppressWarnings("unchecked")
	public List<EgovMap> searchAll(ResultListVO rlv) {
		System.out.println("dao");
		return (List<EgovMap>) list("ResultListDAO.searchAll" , rlv);
	}
	
}
