package solugate.cosamo.resultlist.web;

import java.util.List;

import javax.annotation.Resource;

import org.apache.xmlbeans.impl.xb.xsdschema.Public;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.json.MappingJacksonJsonView;

import solugate.cosamo.realtimegraph.service.RealtimeGraphService;
import solugate.cosamo.resultlist.service.ResultListService;
import egovframework.rte.psl.dataaccess.util.EgovMap;

@Controller 
public class ResultListController {
	@Resource MappingJacksonJsonView ajaxMainView;
	
	@Resource(name = "resultListService")
	private ResultListService resultListService;
	
	@RequestMapping(value="/ResultList/search.do")
	public ModelAndView searchResultList(String arr[]){
		
	
		ModelAndView mav = new ModelAndView(ajaxMainView);
		System.out.println("controller");
		for(int i = 0; i<arr.length; i++){
			//System.out.println(arr[i]);
		}
		List<EgovMap> resultList = resultListService.searchAll(arr);
		mav.addObject("SearchResultList",resultList);
		//System.out.println(resultList);

		
		return mav;

	}
	
	// 회원학습정확도 그래프
	@RequestMapping(value = "/ResultList/accuracy.do")
	public ModelAndView searchAccuracy() throws Exception {
		System.out.println("control");
		ModelAndView mav = new ModelAndView(ajaxMainView);

		List<EgovMap> resultList = resultListService.search_ACC();
		System.out.println(resultList);

		mav.addObject("resultList",resultList);

		return mav;
	}

}
