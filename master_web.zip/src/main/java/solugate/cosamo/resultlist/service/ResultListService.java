package solugate.cosamo.resultlist.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import solugate.cosamo.realtimegraph.dao.RealtimeGraphDAO;
import solugate.cosamo.resultlist.dao.ResultListDAO;
import solugate.cosamo.vo.AnswerManagementVO;
import solugate.cosamo.vo.RealtimeGraphVO;
import solugate.cosamo.vo.ResultListVO;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;
import egovframework.rte.psl.dataaccess.util.EgovMap;

@Service("resultListService")
public class ResultListService extends EgovAbstractServiceImpl  {
	@Resource(name = "resultListDAO")
	private ResultListDAO resultListDAO;

	private ResultListVO rlv = new ResultListVO();

	// 회원 학습정확도
	public List<EgovMap> search_ACC() throws Exception {
		System.out.println("service");
		return resultListDAO.search_ACC();

	}

	public List<EgovMap> searchAll(String arr[]) {
		ResultListVO rlv=new ResultListVO();
	System.out.println("service");
		rlv.setComboVer(arr[0]);
		rlv.setComboID(arr[1]);
		rlv.setInputAcc(arr[2]);
		rlv.setStartDate(arr[3]);
		rlv.setEndDate(arr[4]);
		rlv.setComboS1(arr[5]);
		rlv.setComboS2(arr[6]);
		rlv.setComboS3(arr[7]);
		rlv.setComboS4(arr[8]);
		
	
		return resultListDAO.searchAll(rlv);
	}

}



