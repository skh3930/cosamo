package solugate.cosamo.enginestudy.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import solugate.cosamo.vo.EngineStudyVO;
import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import egovframework.rte.psl.dataaccess.util.EgovMap;

@Repository("esModalDAO")
public class ESModalDAO extends EgovAbstractDAO{
	
	public void add_C(EngineStudyVO esv) throws Exception {
		//for (int i = 0; i < esv.length; i++){
			
		insert("ESModalDAO.insertCStudy", esv);
		
	}
	
	public void add_W(EngineStudyVO esv) throws Exception {
		insert("ESModalDAO.insertWStudy", esv);
	}	
}
