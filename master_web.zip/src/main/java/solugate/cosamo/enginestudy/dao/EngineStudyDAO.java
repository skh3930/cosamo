package solugate.cosamo.enginestudy.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import solugate.cosamo.vo.EngineStudyVO;
import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import egovframework.rte.psl.dataaccess.util.EgovMap;


@Repository("engineStudyDAO")
public class EngineStudyDAO extends EgovAbstractDAO{

	/* search */

	// 학습 완료
	public List<EgovMap> search_ES(EngineStudyVO esv) throws Exception {
		if(!esv.getAnswer().equals("전체"))
			return (List<EgovMap>) list("EngineStudyDAO.searchES1",esv);
				
		else // 전체 필터 (모범, 오답)
			return  (List<EgovMap>) list("EngineStudyDAO.searchES2",esv);
	}
	
	// 학습 전
	public List<EgovMap> search_ENS(EngineStudyVO esv) throws Exception {
		if (!esv.getAnswer().equals("전체"))
			return (List<EgovMap>) list("EngineStudyDAO.searchENS1", esv);
		else
			// 전체 필터 (모범, 오답)
			return (List<EgovMap>) list("EngineStudyDAO.searchENS2", esv);

	}

	
	// 학습 예정
	public List<EgovMap> search_EPS(EngineStudyVO esv) throws Exception {
		if(!esv.getAnswer().equals("전체")) 
			return (List<EgovMap>) list("EngineStudyDAO.searchEPS1",esv);
			
		else // 전체 필터 (모범, 오답)
			return  (List<EgovMap>) list("EngineStudyDAO.searchEPS2",esv);

	}
	
	/* show modal */
	
	
	// 음성 상세보기 모달
	public List<EgovMap> selectMediaPath() throws Exception {
		return (List<EgovMap>) list("EngineStudyDAO.selectMediaPath");
	}
	
	// 학습 완료
	public List<EgovMap> show_ES(EngineStudyVO esv) throws Exception {

		return  (List<EgovMap>) list("EngineStudyDAO.showES",esv);
	}
	
	// 학습 전
	public List<EgovMap> show_ENS(EngineStudyVO esv) throws Exception {

		return  (List<EgovMap>) list("EngineStudyDAO.showENS",esv);
	}
	
	// 학습 예정 (학습 전)
	public List<EgovMap> show_EPS(EngineStudyVO esv) throws Exception {

		return (List<EgovMap>) list("EngineStudyDAO.showEPS", esv);
	}

	
	/* add to Pre Study */

	// 학습 완료
	public void add_ES(EngineStudyVO[] esv) throws Exception {
		for (int i = 0; i < esv.length; i++)
			insert("EngineStudyDAO.addES", esv[i]);
	}

	// 학습 전
	public void add_ENS(EngineStudyVO[] esv) throws Exception {
		for (int i = 0; i < esv.length; i++){
			if(esv[i].getAnswer().equals("모범 답안"))
				insert("EngineStudyDAO.addENS", esv[i]);
			else 
				insert("EngineStudyDAO.addENS2", esv[i]);
		}
	}

	/* delete from list */
	
	// 학습 완료
	public void delete_ES(EngineStudyVO esv) throws Exception {
		delete("EngineStudyDAO.deleteES",esv);
	}

	// 학습 전
	public void delete_ENS(EngineStudyVO esv) throws Exception {
		if(esv.getAnswer().equals("모범 답안"))
			delete("EngineStudyDAO.deleteENS",esv);
		else
			delete("EngineStudyDAO.deleteENS2",esv);
	}
	
	// 학습 예정
	public void delete_EPS(EngineStudyVO esv[]) throws Exception {
		for (int i = 0; i < esv.length; i++)
			delete("EngineStudyDAO.deleteEPS",esv[i]);
	}
	
	/* insert study */

	// 학습 전 - 모범답안 추가
	public void insert_ENS(EngineStudyVO esv[]) throws Exception {
		for (int i = 0; i < esv.length; i++)
			insert("EngineStudyDAO.insertCStudy", esv[i]);
	}

	// 학습 전 - 오답안 추가
	public void insert_ENS2(EngineStudyVO esv[]) throws Exception {
		for (int i = 0; i < esv.length; i++)
			insert("EngineStudyDAO.insertWStudy", esv[i]);
	}	
}

