package solugate.cosamo.enginestudy.web;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import egovframework.com.cmm.service.EgovFileMngService;
import egovframework.com.cmm.service.EgovFileMngUtil;
import egovframework.com.cmm.service.FileVO;
import egovframework.rte.ptl.mvc.bind.annotation.CommandMap;
import solugate.cosamo.enginestudy.service.ESModalService;

@Controller 
public class ESModalController {
	
	@Resource(name = "esmodalService")
	private ESModalService esmodalService;

    @Resource(name = "EgovFileMngService")
    private EgovFileMngService fileMngService;

    @Resource(name = "EgovFileMngUtil")
    private EgovFileMngUtil fileUtil;

	// 답안 추가 - 모범
	@RequestMapping(value="/ES_Modal/addC.do")
	public void addCStudy_ES(final MultipartHttpServletRequest multiRequest) throws Exception{
			String arr[] = new String[4];
		    arr[0] = new String(multiRequest.getParameter("mc1"));
		    arr[1] = new String(multiRequest.getParameter("mc2"));
		    arr[2] = new String(multiRequest.getParameter("mc3"));
		    arr[3] = new String(multiRequest.getParameter("f1"));
		   
		    // 학습전 답안 db에 추가
			esmodalService.add_C(arr);
			
		    // 파일 서버에 올리기
		    List<FileVO> result = null;
		    String atchFileId = "";
		    final Map<String, MultipartFile> files = multiRequest.getFileMap();
		    
		    if (!files.isEmpty()) {
		    //	for(int i=0; i<files.size(); i++){
		    		result = fileUtil.parseFileInf(files, "", 0, "", "");
		    		atchFileId = fileMngService.insertFileInfs(result);	    		
		    	//}
		    }
		    
		    // board.setAtchFileId(atchFileId);
	}
	
	// 답안 추가 - 오답
	@RequestMapping(value="/ES_Modal/addW.do")
	public void addWStudy_ES(final MultipartHttpServletRequest multiRequest) throws Exception{
		String arr[] = new String[5];
	    arr[0] = new String(multiRequest.getParameter("mc1"));
	    arr[1] = new String(multiRequest.getParameter("mc2"));
	    arr[2] = new String(multiRequest.getParameter("mc3"));
	    arr[3] = new String(multiRequest.getParameter("mc4"));
	    arr[4] = new String(multiRequest.getParameter("f1"));
	   
	    // 학습전 답안 db에 추가
		esmodalService.add_W(arr);
		
	    // 파일 서버에 올리기
	    List<FileVO> result = null;
	    String atchFileId = "";
	    final Map<String, MultipartFile> files = multiRequest.getFileMap();
	    
	    if (!files.isEmpty()) {
	    	result = fileUtil.parseFileInf(files, "", 0, "", "");
	    	atchFileId = fileMngService.insertFileInfs(result);	    
	    }
	}

}
