package solugate.cosamo.enginestudy.web;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.json.MappingJacksonJsonView;

import solugate.cosamo.enginestudy.service.EngineStudyService;
import solugate.cosamo.service.CosamoMenuService;
import egovframework.rte.psl.dataaccess.util.EgovMap;

@Controller 
public class EngineStudyController {
	@Resource MappingJacksonJsonView ajaxMainView;
	
	@Resource(name = "engineStudyService")
	private EngineStudyService engineStudyService;
		
	// 학습 완료 - 검색
	@RequestMapping(value="/Engine_StudiedList/search.do")
	public ModelAndView searchEngineStudiedList(String arr[]) throws Exception{
		ModelAndView mav = new ModelAndView(ajaxMainView);
		for(int i = 0; i<arr.length; i++)
			System.out.println(arr[i]);

		List<EgovMap> resultList = engineStudyService.search_ES(arr);
		mav.addObject("searchResult",resultList);
		System.out.println(resultList);
		
		return mav;
			}
	
	// 학습 완료 - 모달
	@RequestMapping(value="/Engine_StudiedList/modal.do")
	public ModelAndView showStudiedInfo(String arr[]) throws Exception{
		ModelAndView mav = new ModelAndView(ajaxMainView);
		for(int i = 0; i<arr.length; i++)
			System.out.println(arr[i]);

		List<EgovMap> resultList = engineStudyService.show_ES(arr);
		mav.addObject("infoResult",resultList);

		List<EgovMap> mediaPath = engineStudyService.selectMediaPath();
		mav.addObject("mediaPath", mediaPath);
		
		System.out.println(resultList);
		System.out.println(mediaPath);
		return mav;
	}
	
	// 학습 완료 - 학습예정에 추가
	@RequestMapping(value="/Engine_StudiedList/addPrestudy.do")
	public ModelAndView addPreStudy_ES(String arr[]) throws Exception{
		ModelAndView mav = new ModelAndView(ajaxMainView);
		for(int i = 0; i<arr.length; i++)
			System.out.println(arr[i]);

		engineStudyService.add_ES(arr);
		
		return mav;
	}

	// 학습 완료 - 삭제
	@RequestMapping(value="/Engine_StudiedList/deleteStudy.do")
	public ModelAndView delete_ES(String key) throws Exception{
		ModelAndView mav = new ModelAndView(ajaxMainView);
		engineStudyService.delete_ES(key);
		
		return mav;
	}

	//학습 전	
	@RequestMapping(value="/Engine_NotStudiedList/search.do")
	public ModelAndView searchEngineNotStudiedList(String arr[]) throws Exception{
		ModelAndView mav = new ModelAndView(ajaxMainView);
		for(int i = 0; i<arr.length; i++)
			System.out.println(arr[i]);

		List<EgovMap> resultList = engineStudyService.search_ENS(arr);
		mav.addObject("searchResult",resultList);
		System.out.println(resultList);
		
		return mav;
		
	}
	
	// 학습 전 - 모달
	@RequestMapping(value = "/Engine_NotStudiedList/modal.do")
	public ModelAndView showNotStudiedInfo(String arr[]) throws Exception {
		ModelAndView mav = new ModelAndView(ajaxMainView);
		for (int i = 0; i < arr.length; i++) 
			System.out.println(arr[i]);

		List<EgovMap> resultList = engineStudyService.show_ENS(arr);
		mav.addObject("infoResult", resultList);
		System.out.println(resultList);

		List<EgovMap> mediaPath = engineStudyService.selectMediaPath();
		mav.addObject("mediaPath", mediaPath);
		System.out.println(mediaPath);
		
		return mav;
	}

	// 학습 전 - 학습예정에 추가
	@RequestMapping(value="/Engine_NotStudiedList/addPrestudy.do")
	public ModelAndView addPreStudy_ENS(String arr[]) throws Exception{
		ModelAndView mav = new ModelAndView(ajaxMainView);
		for(int i = 0; i<arr.length; i++)
			System.out.println(arr[i]);

		engineStudyService.add_ENS(arr);
		
		return mav;
	}	


	// 학습 전 - 삭제
	@RequestMapping(value="/Engine_NotStudiedList/deleteStudy.do")
	public ModelAndView delete_ENS(String arr[]) throws Exception{
		ModelAndView mav = new ModelAndView(ajaxMainView);
		for(int i = 0; i<arr.length; i++)
			System.out.println(arr[i]);

		engineStudyService.delete_ENS(arr);
		
		return mav;
	}

/*	// 학습 전 - 모범답안 추가
	@RequestMapping(value="Engine_NotStudiedList/insertCStudy.do")
	@ResponseBody
	public void insert_ENS(String arr[]) throws Exception{
		System.out.println("controller" + arr[0]);
		//ModelAndView mav = new ModelAndView(ajaxMainView);
//		for(int i = 0; i<arr.length; i++)
//			System.out.println(arr[i]);
//
		engineStudyService.insert_ENS(arr);
		
		//return mav;
	}

	// 학습 전 - 오답안 추가
	@RequestMapping(value="/Engine_NotStudiedList/insertWStudy.do")
	public ModelAndView insert_ENS2(String arr[]) throws Exception{
		System.out.println("controller2");
		ModelAndView mav = new ModelAndView(ajaxMainView);
		for(int i = 0; i<arr.length; i++)
			System.out.println(arr[i]);

		engineStudyService.insert_ENS2(arr);
		
		return mav;
	}*/
	
	// 학습 예정
	@RequestMapping(value = "/Engine_PreStudiedList/search.do")
	public ModelAndView searchEnginePreStudiedList(String arr[])
			throws Exception {
		ModelAndView mav = new ModelAndView(ajaxMainView);
		for (int i = 0; i < arr.length; i++) 
			System.out.println(arr[i]);

		List<EgovMap> resultList = engineStudyService.search_EPS(arr);
		mav.addObject("searchResult", resultList);
		System.out.println(resultList);

		List<EgovMap> mediaPath = engineStudyService.selectMediaPath();
		mav.addObject("mediaPath", mediaPath);

		return mav;

	}

	// 학습 예정 - 모달
	@RequestMapping(value = "/Engine_PreStudiedList/modal.do")
	public ModelAndView showPreStudiedInfo(String arr[]) throws Exception {
		ModelAndView mav = new ModelAndView(ajaxMainView);
		for (int i = 0; i < arr.length; i++) 
			System.out.println(i+"="+arr[i]);

		List<EgovMap> resultList = engineStudyService.show_EPS(arr);
		mav.addObject("infoResult", resultList);
		System.out.println(resultList);
		
		List<EgovMap> mediaPath = engineStudyService.selectMediaPath();
		mav.addObject("mediaPath", mediaPath);


		return mav;
	}


	// 학습 예정 - 삭제
	@RequestMapping(value="/Engine_PreStudiedList/deleteStudy.do")
	public ModelAndView delete_EPS(String arr[]) throws Exception{
		ModelAndView mav = new ModelAndView(ajaxMainView);
		for(int i = 0; i<arr.length; i++)
			System.out.println(arr[i]);

		engineStudyService.delete_EPS(arr);
		
		return mav;
	}

}
