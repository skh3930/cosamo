package solugate.cosamo.enginestudy.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;
import egovframework.rte.psl.dataaccess.util.EgovMap;
import solugate.cosamo.enginestudy.dao.ESModalDAO;
import solugate.cosamo.vo.EngineStudyVO;

@Service("esmodalService")
public class ESModalService  extends EgovAbstractServiceImpl  {

	@Resource(name = "esModalDAO")
	private ESModalDAO esModalDAO;
	
	public void add_C(String arr[]) throws Exception {
		EngineStudyVO esv = new EngineStudyVO();
		esv.setStudy1(arr[0]);
		esv.setStudy2(arr[1]);
		esv.setStudy3(arr[2]);
		esv.setSndPath(arr[3]);
		
		/*EngineStudyVO esv[] = new EngineStudyVO[arr.length-3]; // 음성파일 개수 만큼 객체 생성
		
		for(int i=0;i<esv.length;i++){
			esv[i] = new EngineStudyVO();
			esv[i].setStudy1(arr[0]);
			esv[i].setStudy2(arr[1]);
			esv[i].setStudy3(arr[2]);
			esv[i].setSndPath(arr[i+3]);
			System.out.println(esv[i].getSndPath());
		}*/
		esModalDAO.add_C(esv);
	}
	
	public void add_W(String arr[]) throws Exception {
		EngineStudyVO esv = new EngineStudyVO();
		esv.setWrongAns(arr[3]);
		esv.setSndPath(arr[4]);
		
		esModalDAO.add_W(esv);
	}
}
