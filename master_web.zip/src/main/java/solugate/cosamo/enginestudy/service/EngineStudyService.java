package solugate.cosamo.enginestudy.service;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import solugate.cosamo.dao.CosamoMenuDAO;
import solugate.cosamo.enginestudy.dao.EngineStudyDAO;
import solugate.cosamo.vo.EngineStudyVO;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;
import egovframework.rte.psl.dataaccess.util.EgovMap;

@Service("engineStudyService")
public class EngineStudyService extends EgovAbstractServiceImpl  {

	@Resource(name = "engineStudyDAO")
	private EngineStudyDAO engineStudyDAO;

	private EngineStudyVO esv = new EngineStudyVO();
	
	/* search */
	
	// 버전 콤보를 포함한 학습완료와 학습 예정 목록 묶어둠
	public void contain_V(String arr[]){
		esv.setVersion(arr[0]);
		esv.setAnswer(arr[1]);
		esv.setStudy1(arr[2]);
		esv.setStudy2(arr[3]);
		esv.setStudy3(arr[4]);
		esv.setStudy3(arr[4]);
		esv.setStdPron(arr[5]);
		esv.setSort(arr[6]);

		// 검색 필터 다 초기 값이면
		if (esv.getVersion().equals("전체") && esv.getAnswer().equals("전체")
				&& esv.getStudy1().equals("전체") && esv.getStudy2().equals("전체")
				&& esv.getStudy3().equals("전체")
				&& esv.getStdPron().equals("전체")) {
			esv.setSearchFT(1);
		}
		// 답안 선택 외의 검색필터 다 초기값이면
		else if (esv.getVersion().equals("전체") && esv.getStudy1().equals("전체")
				&& esv.getStudy2().equals("전체") && esv.getStudy3().equals("전체")
				&& esv.getStdPron().equals("전체")) {
			esv.setSearchFT(2);
		}
		// 답안선택 + 그외 검색필터 적용
		else if (!esv.getAnswer().equals("전체")) {
			esv.setSearchFT(3);
		}
		// 답안선택x + 그외 검색필터 적용
		else
			esv.setSearchFT(4);
	}
	// 학습 완료
	public List<EgovMap> search_ES(String arr[]) throws Exception {
		contain_V(arr);

		return engineStudyDAO.search_ES(esv);
	}

	// 학습 전
	public List<EgovMap> search_ENS(String arr[]) throws Exception {
	//	esv.setSearchCB(arr[0]);
	//	esv.setInput(arr[1]);
		esv.setAnswer(arr[0]);
		esv.setStudy1(arr[1]);
		esv.setStudy2(arr[2]);
		esv.setStudy3(arr[3]);
		esv.setStdPron(arr[4]);
		esv.setSort(arr[5]);

		// 검색 필터 다 초기 값이면
		if (esv.getAnswer().equals("전체") && esv.getStudy1().equals("전체")
				&& esv.getStudy2().equals("전체") && esv.getStudy3().equals("전체")
				&& esv.getStdPron().equals("전체")) {
			esv.setSearchFT(1);
		}
		// 답안 선택 외의 검색필터 다 초기값이면
		else if (esv.getStudy1().equals("전체") && esv.getStudy2().equals("전체")
				&& esv.getStudy3().equals("전체")
				&& esv.getStdPron().equals("전체")) {
			esv.setSearchFT(2);
		}
		// 답안선택 + 그외 검색필터 적용
		else if (!esv.getAnswer().equals("전체")) {
			esv.setSearchFT(3);
		}
		// 답안선택x + 그외 검색필터 적용
		else
			esv.setSearchFT(4);

		return engineStudyDAO.search_ENS(esv);
	}
	
	// 학습 예정
	public List<EgovMap> search_EPS(String arr[]) throws Exception {
		contain_V(arr);
		return engineStudyDAO.search_EPS(esv);
	}
	
	/* show modal */
	
	public List<EgovMap> selectMediaPath() throws Exception {
		return engineStudyDAO.selectMediaPath();
	}
	
	// 학습 완료
	public List<EgovMap> show_ES(String arr[]) throws Exception {
		esv.setSndKey(arr[0]);
		
	    if(arr[1].equals("1")) esv.setAnswer("모범 답안");
	    else if(arr[1].equals("2")) esv.setAnswer("오 답안");
		return engineStudyDAO.show_ES(esv);
	}
	
	// 학습 전
	public List<EgovMap> show_ENS(String arr[]) throws Exception {
		esv.setSndKey(arr[0]);
		
	    if(arr[1].equals("1")) esv.setAnswer("모범 답안");
	    else if(arr[1].equals("2")) esv.setAnswer("오 답안");
		return engineStudyDAO.show_ENS(esv);
	}
	

	// 학습 예정
	public List<EgovMap> show_EPS(String arr[]) throws Exception {
		esv.setSndKey(arr[0]);
		
	    if(arr[1].equals("1")) esv.setAnswer("모범 답안");
	    else if(arr[1].equals("2")) esv.setAnswer("오 답안");
	    
	    return engineStudyDAO.show_EPS(esv);
		   
	}
	

	/* add to Pre Study */
	
	// 학습 완료
	public void add_ES(String arr[]) throws Exception {
		EngineStudyVO esv[] = new EngineStudyVO[arr.length];

		for (int i = 0; i < esv.length; i++) {
			esv[i] = new EngineStudyVO();
			esv[i].setSndKey(arr[i]);
		}
		engineStudyDAO.add_ES(esv);
	}

	// 학습 전 - arr에는 (key,value), (key, value), 순으로 들어가 있음.
	public void add_ENS(String arr[]) throws Exception {
		EngineStudyVO esv[] = new EngineStudyVO[arr.length/2];

		for (int i = 0; i < esv.length; i++) {
			esv[i] = new EngineStudyVO();
			esv[i].setSndKey(arr[i*2]);
			esv[i].setAnswer(arr[i*2+1]);
		}

		engineStudyDAO.add_ENS(esv);
	}
	
	
	/* delete from list */
	
	// 학습 완료
	public void delete_ES(String key) throws Exception {
		esv.setSndKey(key);
		engineStudyDAO.delete_ES(esv);
	}
	
	// 학습 전
	public void delete_ENS(String arr[]) throws Exception {
		esv.setSndKey(arr[0]);
		esv.setAnswer(arr[1]);
		engineStudyDAO.delete_ENS(esv);
	}
	
	// 학습 예정
	public void delete_EPS(String arr[]) throws Exception {
		EngineStudyVO esv[] = new EngineStudyVO[arr.length];

		for (int i = 0; i < arr.length; i++) {
			esv[i] = new EngineStudyVO();
			esv[i].setSndKey(arr[i]);
		}

		engineStudyDAO.delete_EPS(esv);
	}
	
	/* insert study */
	

/*	// 학습 전 - 모범답안 추가
	public void insert_ENS(String arr[]) throws Exception {
		EngineStudyVO esv[] = new EngineStudyVO[arr.length-3]; // 음성파일 개수 만큼 객체 생성
		for(int i=0;i<esv.length;i++){
			esv[i].setStudy1(arr[0]);
			esv[i].setStudy2(arr[1]);
			esv[i].setStudy3(arr[2]);
			esv[i].setSndPath(arr[i+3]);
		}
		engineStudyDAO.insert_ENS(esv);
	}
	
	// 학습 전 - 오답안 추가
	public void insert_ENS2(String arr[]) throws Exception {
		EngineStudyVO esv[] = new EngineStudyVO[arr.length-4]; // 음성파일 개수 만큼 객체 생성
		for(int i=0;i<esv.length;i++){
			esv[i].setWrongAns(arr[3]);
			esv[i].setSndPath(arr[i+4]);
		}
		
		engineStudyDAO.insert_ENS2(esv);
	}
	*/
}
