package solugate.cosamo.setting.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import solugate.cosamo.setting.dao.CosamoSettingDAO;
import solugate.cosamo.vo.SettingESAVO;
import solugate.cosamo.vo.SettingESMVO;
import solugate.cosamo.vo.SettingESSVO;
import solugate.cosamo.vo.SettingESVO;
import solugate.cosamo.vo.SettingPathVO;
import solugate.cosamo.vo.SettingUserDVO;
import solugate.cosamo.vo.SettingUserVO;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;
import egovframework.rte.psl.dataaccess.util.EgovMap;
@Service("cosamoSettingService")
public class CosamoSettingService {
	
		@Resource(name = "cosamoSettingDAO")
		private CosamoSettingDAO cosamoSettingDAO;
		
	
		public List<EgovMap> searchAll_USER(String arr[]) throws Exception {
			
			SettingUserVO amv=new SettingUserVO();
			
			
			amv.setComboSearch(arr[0]);
			amv.setInputSearch(arr[1]);
			
			
			return cosamoSettingDAO.searchAll_USER(amv);
		}


		public List<EgovMap> searchAll_USERD(int arr[]) throws Exception {
			
			SettingUserDVO amv=new SettingUserDVO();
			amv.setDelete(arr[0]);
			
			
			return cosamoSettingDAO.searchAll_USERD(amv);
		}
		public void searchAll_PATH(String arr[]) throws Exception {
			
			SettingPathVO amv=new SettingPathVO();
			
			
			amv.setUserVoice(arr[0]);
			amv.setCorrectVoice(arr[1]);
			amv.setWrongVoice(arr[2]);
			amv.setCorrectVideo(arr[3]);
			cosamoSettingDAO.searchAll_PATH(amv);
		}


			public void searchAll_ES(int arr[]) throws Exception {
			int i;
			
			for(i=0;i<arr.length;i++){
			SettingESVO amv=new SettingESVO();
			amv.setChArr(arr[i]);
			cosamoSettingDAO.searchAll_ES(amv);
			}
		}


			public void add_ES(String[] arr) {
				
				SettingESAVO amv=new SettingESAVO();
				
				amv.setInputVer(arr[0]);
				amv.setStartDate(arr[1]);
				amv.setStudyDate(arr[2]);

				// 학습 일정 추가
				cosamoSettingDAO.add_ES(amv);
				
				// 학습 예정 리스트 추가 (arr[3]부터 학습예정답안들의 키가 들어있음)
				for(int i=3;i<arr.length;i++){
					amv.setInputKey(arr[i]);
					cosamoSettingDAO.add_ESP(amv);	
				}
			}


			public void mod_ES(String[] arr) {
				SettingESMVO amv=new SettingESMVO();
				amv.setInputVer(arr[0]);
				amv.setStartDate(arr[1]);
				amv.setStudyDate(arr[2]);
				amv.setNo(arr[3]);
				

				cosamoSettingDAO.mod_ES(amv);
				
			}


			public List<EgovMap> searchMod_ES(String[] arr) throws Exception {
				SettingESSVO amv=new SettingESSVO();
			
				amv.setNo(arr[0]);
				

				return cosamoSettingDAO.searchMod_ES(amv);
				
				
			}

			public List<EgovMap> selectListMod() throws Exception {
				
				return cosamoSettingDAO.selectListMod();
					
				
			}

		
		
		
	
}
