package solugate.cosamo.setting.dao;
import java.util.List;

import org.springframework.stereotype.Repository;

import solugate.cosamo.vo.SettingESAVO;
import solugate.cosamo.vo.SettingESMVO;
import solugate.cosamo.vo.SettingESSVO;
import solugate.cosamo.vo.SettingESVO;
import solugate.cosamo.vo.SettingPathVO;
import solugate.cosamo.vo.SettingUserDVO;
import solugate.cosamo.vo.SettingUserVO;
import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import egovframework.rte.psl.dataaccess.util.EgovMap;


@Repository("cosamoSettingDAO")
public class CosamoSettingDAO  extends EgovAbstractDAO{
	
		@SuppressWarnings("unchecked")
		public List<EgovMap> searchAll_USER(SettingUserVO amv) throws Exception {

			return (List<EgovMap>) list("CosamoSettingDAO.searchAll_USER" , amv);
		}
	
		
		public void searchAll_PATH(SettingPathVO amv) throws Exception {
			insert("CosamoSettingDAO.searchAll_PATH" , amv);

			
		}
		public void searchAll_ES(SettingESVO amv) throws Exception {
			insert("CosamoSettingDAO.searchAll_ES" , amv);

			
		}

		@SuppressWarnings("unchecked")
		public List<EgovMap> searchAll_USERD(SettingUserDVO amv) throws Exception {

			return (List<EgovMap>) list("CosamoSettingDAO.searchAll_USERD" , amv);
		}


		public void add_ES(SettingESAVO amv) {
			// 기존의 예약된 상태들 -> 취소로 바꾸고, 활성화 -> 비활성화로
			// 그 다음 새 일정 예약
			insert("CosamoSettingDAO.add_ES" , amv);
			
		}

		// 학습 예정 리스트 추가
		public void add_ESP(SettingESAVO amv) {
			insert("CosamoSettingDAO.add_ESP" , amv);
			
		}
		
		public void mod_ES(SettingESMVO amv) {
			insert("CosamoSettingDAO.mod_ES" , amv);
			
		}


		public List<EgovMap> searchMod_ES(SettingESSVO amv)  throws Exception{
			
			return (List<EgovMap>) list("CosamoSettingDAO.searchMod_ES" , amv);
		}


		public List<EgovMap> selectListMod()  throws Exception{
			
			return (List<EgovMap>) list("CosamoSettingDAO.selectListMod");
		}

		


}