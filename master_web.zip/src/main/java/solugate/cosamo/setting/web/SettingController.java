package solugate.cosamo.setting.web;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.json.MappingJacksonJsonView;

import solugate.cosamo.setting.service.CosamoSettingService;
import egovframework.rte.psl.dataaccess.util.EgovMap;

@Controller
public class SettingController {

	@Resource
	MappingJacksonJsonView ajaxMainView;
	@Resource(name = "cosamoSettingService")
	private CosamoSettingService cosamoSettingService;

	// 설정-회원 관리-검색
	@RequestMapping(value = "/Setting_UserManagement/search.do")
	public ModelAndView searchSettingUM(String arr[]) throws Exception {
		ModelAndView mav = new ModelAndView(ajaxMainView);
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}

		List<EgovMap> settingUserManagement = cosamoSettingService
				.searchAll_USER(arr);
		mav.addObject("totalSList", settingUserManagement);
		System.out.println(settingUserManagement);

		return mav;

	}

	// 설정-회원 관리-회원삭제
	@RequestMapping(value = "/Setting_UserManagement_del/search.do")
	public ModelAndView searchSettingUMD(int arr[]) throws Exception {
		ModelAndView mav = new ModelAndView(ajaxMainView);
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}

		List<EgovMap> settingUserManagement = cosamoSettingService
				.searchAll_USERD(arr);
		mav.addObject("totalDList", settingUserManagement);
		System.out.println(settingUserManagement);

		return mav;

	}

	// 설정-경로 설정
	@RequestMapping(value = "/SavingPath/search.do")
	public ModelAndView searchSettingSP(String arr[]) throws Exception {
		ModelAndView mav = new ModelAndView(ajaxMainView);
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}

		cosamoSettingService.searchAll_PATH(arr);

		return mav;

	}

	// 설정-엔진학습 설정- 검색
	@RequestMapping(value = "/EngineScheduler/search.do")
	public ModelAndView searchSettingES(int arr[]) throws Exception {
		ModelAndView mav = new ModelAndView(ajaxMainView);
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}

		cosamoSettingService.searchAll_ES(arr);

		return mav;

	}

	// 설정-엔진학습 설정-일정등록
	@RequestMapping(value = "/EngineScheduler_add/search.do")
	public ModelAndView searchSettingESA(String arr[]) throws Exception {
		ModelAndView mav = new ModelAndView(ajaxMainView);
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}
		cosamoSettingService.add_ES(arr);
		return mav;

	}

	// 설정-엔진학습 설정-일정수정
	@RequestMapping(value = "/EngineScheduler_mod/search.do")
	public ModelAndView searchSettingESM(String arr[]) throws Exception {
		ModelAndView mav = new ModelAndView(ajaxMainView);
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}

		cosamoSettingService.mod_ES(arr);

		return mav;

	}

	// 설정-엔진학습 설정-일정수정 초기로드
	@RequestMapping(value = "/EngineScheduler_smod/search.do")
	public ModelAndView searchSettingESM_S(String arr[]) throws Exception {
		ModelAndView mav = new ModelAndView(ajaxMainView);
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}

		List<EgovMap> settingModify = cosamoSettingService.searchMod_ES(arr);
		mav.addObject("totalModList", settingModify);
		System.out.println(settingModify);

		return mav;

	}

	// 설정-엔진학습 목록
	@RequestMapping(value = "/EngineScheduler/studyList.do")
	public ModelAndView searchStudyList() throws Exception {
		ModelAndView mav = new ModelAndView(ajaxMainView);
		System.out.println("zzz");
		List<EgovMap> studyList = cosamoSettingService.selectListMod();
		mav.addObject("studyList", studyList);
		System.out.println(studyList);

		return mav;

	}
}
