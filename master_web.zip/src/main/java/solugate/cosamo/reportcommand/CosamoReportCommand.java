package solugate.cosamo.reportcommand;
import org.springframework.web.multipart.MultipartFile;
public class CosamoReportCommand {

	private MultipartFile voice;
	private MultipartFile video;
	
	public MultipartFile getVoice() {
		return voice;
	}
	public void setVoice(MultipartFile voice) {
		this.voice = voice;
	}
	public MultipartFile getVideo() {
		return video;
	}
	public void setVideo(MultipartFile video) {
		this.video = video;
	}
	
	
	
	
}
