package solugate.cosamo.realtimegraph.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import solugate.cosamo.vo.RealtimeGraphVO;
import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import egovframework.rte.psl.dataaccess.util.EgovMap;

@Repository("realtimeGraphDAO")
public class RealtimeGraphDAO extends EgovAbstractDAO{

	// 시간별
	public List<EgovMap> search_RTT(RealtimeGraphVO rgv) throws Exception {
		return  (List<EgovMap>) list("RealtimeGraphDAO.searchRG",rgv);
	}

}
