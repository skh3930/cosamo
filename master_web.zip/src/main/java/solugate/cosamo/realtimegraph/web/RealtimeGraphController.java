package solugate.cosamo.realtimegraph.web;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.json.MappingJacksonJsonView;

import com.ibm.icu.text.SimpleDateFormat;

import solugate.cosamo.realtimegraph.service.RealtimeGraphService;
import egovframework.rte.psl.dataaccess.util.EgovMap;

@Controller
public class RealtimeGraphController {
	@Resource
	MappingJacksonJsonView ajaxMainView;

	@Resource(name = "realtimeGraphService")
	private RealtimeGraphService realtimeGraphService;

	// 시간별 데이터
	@RequestMapping(value = "/RealtimeGraph/search_t.do")
	public ModelAndView searchRealtime_t(String today) throws Exception {
		ModelAndView mav = new ModelAndView(ajaxMainView);
	
		// 오늘 날짜 전달
		List<EgovMap> resultList = realtimeGraphService.search_RTT(today);
		System.out.println(resultList);
		
		/* 시간대 별 총 접속자 수 계산 */
		String t;
		int u_class;
		int currentUser = 0; // 실시간 접속자 수
		int userNum[] = new int[24]; // 시간별 총 접속자 수(0~23시)
		int time[] = new int[resultList.size()]; // db에서 읽어온 timestamp -> time만 추출
		int userNum_c[] = new int[6]; // 급수별 총 접속자 수 (1~6급)
		int userNum_s[] = new int[3]; // 학습별 총 접속자 수 (음절, 단어, 문장)
		
		for(int i=0;i<userNum.length;i++) 
			userNum[i] = 0;
		
		for(int i=0;i<resultList.size();i++){
			u_class = Integer.parseInt(resultList.get(i).get("class").toString()); 
			 
			switch(u_class){
			case 0:
				t = resultList.get(i).get("start").toString();
				time[i] = Integer.parseInt(t.substring(11,13));// 시간만 추출
				userNum[time[i]]++;
				break;
			case 1: case 2: case 3: case 4: case 5: case 6:
				userNum_c[u_class-1] = Integer.parseInt(resultList.get(i).get("count").toString());
				break;
			case 1000:
				currentUser = Integer.parseInt(resultList.get(i).get("count").toString());
				mav.addObject("currentUser",currentUser); // 현재 접속자 수
				break;
			case 1001:
				mav.addObject("totalLog",Integer.parseInt(resultList.get(i).get("count").toString())); // 오늘까지 접속자 수
				break;
			case 1002:
				mav.addObject("totalUser",Integer.parseInt(resultList.get(i).get("count").toString())); // 총 회원수
				break;
			case 1003:
				mav.addObject("currentEng",resultList.get(i).get("version").toString()); // 현재 엔진
				break;
			case 1004:
				mav.addObject("caNum",Integer.parseInt(resultList.get(i).get("count").toString()));  // 모범답안 수
				break;
			case 1005:
				mav.addObject("waNum",Integer.parseInt(resultList.get(i).get("count").toString()));  // 오답안 수
				break;
			case 2001: case 2002: case 2003:
				userNum_s[u_class-2001] = Integer.parseInt(resultList.get(i).get("count").toString());
				break;
			}
		}
		mav.addObject("userNum", userNum);
		mav.addObject("userNum_c", userNum_c);
		mav.addObject("userNum_s", userNum_s);
		
		int loginToday = 0; // 일일 총 누적 접속자 수
		for(int i=0;i<userNum.length;i++) loginToday += userNum[i];
		mav.addObject("loginToday",loginToday);
		
		return mav;
	}
	
	
}