package solugate.cosamo.realtimegraph.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.ibm.icu.text.SimpleDateFormat;

import solugate.cosamo.realtimegraph.dao.RealtimeGraphDAO;
import solugate.cosamo.vo.EngineStudyVO;
import solugate.cosamo.vo.RealtimeGraphVO;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;
import egovframework.rte.psl.dataaccess.util.EgovMap;

@Service("realtimeGraphService")
public class RealtimeGraphService extends EgovAbstractServiceImpl  {
	
	@Resource(name = "realtimeGraphDAO")
	private RealtimeGraphDAO realtimeGraphDAO;

	private RealtimeGraphVO rgv = new RealtimeGraphVO();

	// 시간별
	public List<EgovMap> search_RTT(String today) throws Exception {

		rgv.setTotalD(today+"%");
	
		return realtimeGraphDAO.search_RTT(rgv);
	}


}

