package solugate.cosamo.statisticlist.web;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.json.MappingJacksonJsonView;

import solugate.cosamo.statisticlist.service.StatisticListService;
import egovframework.rte.psl.dataaccess.util.EgovMap;

@Controller
public class StatisticListController {
	@Resource
	MappingJacksonJsonView ajaxMainView;

	@Resource(name = "statisticListService")
	private StatisticListService statisticListService;

	// 시간별 데이터
	@RequestMapping(value = "/StatisticList/search_t.do")
	public ModelAndView searchRealtime_t(String arr[]) throws Exception {
		ModelAndView mav = new ModelAndView(ajaxMainView);
		for (int i = 0; i < arr.length; i++)
			System.out.println(arr[i]);
	
		// 오늘 날짜 전달
		List<EgovMap> resultList = statisticListService.search_RTT(arr);
		System.out.println(resultList);
		
		/* 시간대 별 총 접속자 수 계산 */
		String t;
		int time[] = new int[resultList.size()]; // db에서 읽어온 timestamp -> time만 추출
		int userNum[][] = new int[7][24]; // 시간별 이용자 수 (0~6급)(0~23시)
		int userNum2[][] = new int[3][24]; // 시간별 학습 접속자 수 (음절,단어,문장)(0~23시)
		
		for(int i=0;i<userNum.length;i++) 
			for(int j=0;j<userNum[0].length;j++)
				userNum[i][j] = 0;
		
		for(int i=0;i<userNum2.length;i++) 
			for(int j=0;j<userNum2[0].length;j++)
				userNum2[i][j] = 0;
		
		int u_class;
		for(int i=0;i<resultList.size();i++){
			u_class = Integer.parseInt(resultList.get(i).get("class").toString()); 
			
			if(u_class == 1000) { // 실시간 접속자 수
				int currentUser = Integer.parseInt(resultList.get(i).get("count").toString());
				System.out.println(currentUser);
				mav.addObject("currentUser",currentUser); 
			}
			else if(u_class > 2000){ // 학습별 접속자 수 (u_class - 2001:음절, 2002:단어, 2003: 문장)
				t = resultList.get(i).get("start").toString();
				if (t != null) {
					time[i] = Integer.parseInt(t.substring(11, 13));
					userNum2[u_class - 2001][time[i]]++; // u_class 학습의 time[i] 시간의 이용자 수
				}
			}
			else{ // 총, 급수별 접속자 수
				t = resultList.get(i).get("start").toString();
				if (t != null) {
					time[i] = Integer.parseInt(t.substring(11,13));// 시간만 추출
					userNum[u_class][time[i]]++;  // u_class급의 time2[i]시간의 이용자 수
				}	
			}	
		}
		
		mav.addObject("userNum", userNum);
		mav.addObject("userNum2", userNum2);
		
		return mav;
	}
	
	// 일별 데이터
	@RequestMapping(value = "/StatisticList/search_d.do")
	public ModelAndView searchRealtime_d(String arr[]) throws Exception {
		ModelAndView mav = new ModelAndView(ajaxMainView);
		for (int i = 0; i < arr.length; i++)
			System.out.println(arr[i]);
	
		// 오늘 날짜 전달 (월까지)
		List<EgovMap> resultList = statisticListService.search_RTD(arr);
		System.out.println(resultList);
		/* 일별 총 접속자 수 계산 */
		String d;
		int date[] = new int[resultList.size()];  // db에서 읽어온 timestamp -> date만
		int userNum[][] = new int[7][32]; // 일별 이용자 수 (0~6급)(1~31일)
		int userNum2[][] = new int[3][32]; // 시간별 학습 접속자 수 (음절,단어,문장)(1~31일)
		
		for(int i=0;i<userNum.length;i++) 
			for(int j=0;j<userNum[0].length;j++)
				userNum[i][j] = 0;
		for(int i=0;i<userNum2.length;i++) 
			for(int j=0;j<userNum2[0].length;j++)
				userNum2[i][j] = 0;
		
		int u_class;
		for(int i=0;i<resultList.size();i++){
			u_class = Integer.parseInt(resultList.get(i).get("class").toString());
			if(u_class == 1000) {
				int currentUser = Integer.parseInt(resultList.get(i).get("count").toString());
				mav.addObject("currentUser",currentUser); 
			}
			else if(u_class > 2000){ // 학습별 접속자 수 (u_class - 2001:음절, 2002:단어, 2003: 문장)
				d = resultList.get(i).get("start").toString();
				if (d != null) {
					date[i] = Integer.parseInt(d.substring(8, 10));
					userNum2[u_class - 2001][date[i]]++;
				}
			}
			else{
				d = resultList.get(i).get("start").toString();
				if(d != null){
					date[i] = Integer.parseInt(d.substring(8,10));
					userNum[u_class][date[i]]++;  // u_class급의 date[i]일의 이용자 수
				}
			}
		}
		
		mav.addObject("userNum", userNum);
		mav.addObject("userNum2", userNum2);
		
		return mav;
	}
	
	// 월별 데이터
	@RequestMapping(value = "/StatisticList/search_m.do")
	public ModelAndView searchRealtime_m(String arr[]) throws Exception {
		ModelAndView mav = new ModelAndView(ajaxMainView);
		for (int i = 0; i < arr.length; i++)
			System.out.println(arr[i]);
	
		// 오늘 날짜 전달 (년도만)
		List<EgovMap> resultList = statisticListService.search_RTM(arr);
		System.out.println(resultList);
		
		/* 월별 총 접속자 수 계산 */
		String m;
		int mon[] = new int[resultList.size()]; // db에서 읽어온 timestamp -> month만
		int userNum[][] = new int[7][13]; // 시간별 이용자 수 (0~6급)(1~12월)
		int userNum2[][] = new int[3][13]; // 시간별 학습 접속자 수 (음절,단어,문장)(1~12월)
		
		for(int i=0;i<userNum.length;i++) 
			for(int j=0;j<userNum[0].length;j++)
				userNum[i][j] = 0;
		for(int i=0;i<userNum2.length;i++) 
			for(int j=0;j<userNum2[0].length;j++)
				userNum2[i][j] = 0;
		
		int u_class;
		for(int i=0;i<resultList.size();i++){
			u_class = Integer.parseInt(resultList.get(i).get("class").toString());			
			if(u_class == 1000) {
				int currentUser = Integer.parseInt(resultList.get(i).get("count").toString());
				mav.addObject("currentUser",currentUser); 
			}
			else if(u_class > 2000){ // 학습별 접속자 수 (u_class - 2001:음절, 2002:단어, 2003: 문장)
				m = resultList.get(i).get("start").toString();
				if (m != null) {
					mon[i] = Integer.parseInt(m.substring(5, 7));
					userNum2[u_class - 2001][mon[i]]++;
				}
			}
			else{
				m = resultList.get(i).get("start").toString();
				if(m!=null){
					mon[i] = Integer.parseInt(m.substring(5,7));
					userNum[u_class][mon[i]]++;  // u_class급의 mon[i]월의 이용자 수
				}	
			}
		}
		
		mav.addObject("userNum", userNum);
		mav.addObject("userNum2", userNum2);
		
		return mav;
	}
	
	// 년별 데이터
	@RequestMapping(value = "/StatisticList/search_y.do")
	public ModelAndView searchRealtime_y(String arr[]) throws Exception {
		ModelAndView mav = new ModelAndView(ajaxMainView);
		for (int i = 0; i < arr.length; i++)
			System.out.println(arr[i]);
	
		// 오늘 날짜 전달
		List<EgovMap> resultList = statisticListService.search_RTY(arr);
		System.out.println(resultList);
		/* 시간대 별 총 접속자 수 계산 */
		String y;
		int year[] = new int[resultList.size()];  // db에서 읽어온 timestamp ->year만
		int userNum[][] = new int[7][30]; // 시간별 이용자 수 (0~6급)(2000~2029년)
		int userNum2[][] = new int[3][30]; // 시간별 학습 접속자 수 (음절,단어,문장)(2000~2029년)
		
		for(int i=0;i<userNum.length;i++) 
			for(int j=0;j<userNum[0].length;j++)
				userNum[i][j] = 0;
		for(int i=0;i<userNum2.length;i++) 
			for(int j=0;j<userNum2[0].length;j++)
				userNum2[i][j] = 0;
		
		int u_class;
		for(int i=0;i<resultList.size();i++){
			u_class = Integer.parseInt(resultList.get(i).get("class").toString());
			if(u_class == 1000) {
				int currentUser = Integer.parseInt(resultList.get(i).get("count").toString());
				mav.addObject("currentUser",currentUser); 
			}
			else if(u_class > 2000){ // 학습별 접속자 수 (u_class - 2001:음절, 2002:단어, 2003: 문장)
				y = resultList.get(i).get("start").toString();
				if (y != null) {
					year[i] = Integer.parseInt(y.substring(0,4)) - 2010;
					userNum2[u_class - 2001][year[i]]++;
				}
			}
			else{
				y =resultList.get(i).get("start").toString();
				if(y!=null){
					year[i] = Integer.parseInt(y.substring(0,4)) - 2010; // 2010을 뺌 ! ex) 2016년 -> year[6]
					userNum[u_class][year[i]]++;  // u_class급의 year[i]년의 이용자 수	
				}	
			}
		}
		
		mav.addObject("userNum", userNum);
		mav.addObject("userNum2", userNum2);
		
		return mav;
	}
}