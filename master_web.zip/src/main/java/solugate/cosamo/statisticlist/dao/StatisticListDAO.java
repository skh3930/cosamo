package solugate.cosamo.statisticlist.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import solugate.cosamo.vo.StatisticListVO;
import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import egovframework.rte.psl.dataaccess.util.EgovMap;

@Repository("statisticListDAO")
public class StatisticListDAO extends EgovAbstractDAO{

	// 시간별, 일별, 월별
	public List<EgovMap> search_RTT(StatisticListVO slv) throws Exception {
		return  (List<EgovMap>) list("StatisticListDAO.searchUN",slv);
	}
	
	// 년별
	public List<EgovMap> search_RTY(StatisticListVO slv) throws Exception {

		return  (List<EgovMap>) list("StatisticListDAO.searchYear",slv);
	}


}
