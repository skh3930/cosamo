package solugate.cosamo.statisticlist.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import solugate.cosamo.statisticlist.dao.StatisticListDAO;
import solugate.cosamo.vo.StatisticListVO;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;
import egovframework.rte.psl.dataaccess.util.EgovMap;

@Service("statisticListService")
public class StatisticListService extends EgovAbstractServiceImpl  {
	
	@Resource(name = "statisticListDAO")
	private StatisticListDAO statisticListDAO;

	private StatisticListVO slv = new StatisticListVO();

	// 시간별
	public List<EgovMap> search_RTT(String arr[]) throws Exception {
		String totalD = arr[0];
		for(int i=1;i<=2;i++){
			if(arr[i].length() < 2) totalD += ("-0"+arr[i]);
			else totalD += ("-"+arr[i]);
		}

		slv.setTotalD(totalD+"%");
		slv.setTotalD2(arr[3]+"%"); // 실시간 접속자 수를 위한 date
	//	System.out.println("1:"+totalD);
	//	System.out.println("2:"+arr[3]);
	
		return statisticListDAO.search_RTT(slv);
	}

	// 일별
	public List<EgovMap> search_RTD(String arr[]) throws Exception {
		String totalD = arr[0];
		
		// 월까지만
		if(arr[1].length() < 2) totalD += ("-0"+arr[1]);
		else totalD += ("-"+arr[1]);

		slv.setTotalD(totalD+"%");		
		slv.setTotalD2(arr[3]+"%");
		//System.out.println("1:"+totalD);
	//	System.out.println("2:"+arr[3]);

		return statisticListDAO.search_RTT(slv);
	}

	// 월별
	public List<EgovMap> search_RTM(String arr[]) throws Exception {
		String totalD = arr[0];

		slv.setTotalD(totalD+"%");		
		slv.setTotalD2(arr[3]+"%");
		//System.out.println("1:"+totalD);
		//System.out.println("2:"+arr[3]);
		
		return statisticListDAO.search_RTT(slv);
	}

	// 년별
	public List<EgovMap> search_RTY(String arr[]) throws Exception {
		slv.setTotalD2(arr[3]+"%");
		return statisticListDAO.search_RTY(slv);
	}

}

