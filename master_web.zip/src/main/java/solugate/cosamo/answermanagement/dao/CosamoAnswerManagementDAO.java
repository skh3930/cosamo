package solugate.cosamo.answermanagement.dao;
import java.util.List;

import org.springframework.stereotype.Repository;

import solugate.cosamo.vo.AnswerManagementVO;
import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import egovframework.rte.psl.dataaccess.util.EgovMap;


@Repository("cosamoAnswerManagementDAO")
public class CosamoAnswerManagementDAO  extends EgovAbstractDAO{
	
	// 음성 상세보기 모달
	public List<EgovMap> selectMediaPath() throws Exception {
		return (List<EgovMap>) list("EngineStudyDAO.selectMediaPath");
	}
	
	@SuppressWarnings("unchecked")
	public List<EgovMap> searchAll_AM(AnswerManagementVO amv) throws Exception {
		
	
		return (List<EgovMap>) list("CosamoAnswerManagementDAO.searchAll_AM" , amv);
	}

	@SuppressWarnings("unchecked")
	public List<EgovMap> search_AMM(AnswerManagementVO amv) {
		return (List<EgovMap>) list("CosamoAnswerManagementDAO.search_AMM" , amv);
	}



	@SuppressWarnings("unchecked")
	public List<EgovMap> search_AMM_m(AnswerManagementVO amv) {
		return (List<EgovMap>) list("CosamoAnswerManagementDAO.search_AMM_m" , amv);
	}


	@SuppressWarnings("unchecked")
	public List<EgovMap> search_AMM_i(AnswerManagementVO amv) {
		return (List<EgovMap>) list("CosamoAnswerManagementDAO.search_AMM_i" , amv);
	}


	@SuppressWarnings("unchecked")
	public List<EgovMap> search_D(AnswerManagementVO amv) {
		return (List<EgovMap>) list("CosamoAnswerManagementDAO.search_D" , amv);
	}

	public List<EgovMap> addC_AM(AnswerManagementVO amv) {
		return (List<EgovMap>) list("CosamoAnswerManagementDAO.addC_AM" , amv);
	}

	public List<EgovMap> addW_AM(AnswerManagementVO amv) {
		return (List<EgovMap>) list("CosamoAnswerManagementDAO.addW_AM" , amv);
	}
}
