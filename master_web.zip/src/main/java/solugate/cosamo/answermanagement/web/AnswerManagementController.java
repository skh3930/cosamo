package solugate.cosamo.answermanagement.web;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.json.MappingJacksonJsonView;

import solugate.cosamo.answermanagement.service.CosamoAnswerManagementService;
import egovframework.com.cmm.service.EgovFileMngService;
import egovframework.com.cmm.service.EgovFileMngUtil;
import egovframework.com.cmm.service.FileVO;
import egovframework.rte.psl.dataaccess.util.EgovMap;

@Controller 
public class AnswerManagementController {
		@Resource (name="EgovFileMngService")
		private EgovFileMngService fileMngService;
		@Resource (name="EgovFileMngUtil")
		private EgovFileMngUtil fileUtil;
		
		@Resource MappingJacksonJsonView ajaxMainView;
		@Resource (name="cosamoAnswerManagementService")
		private CosamoAnswerManagementService cosamoAnswerManagementService; 
		// 학습 완료
		@RequestMapping(value="/AnswerManagement/search.do")
		public ModelAndView searchAnswerManagement(String arr[]) throws Exception{
			ModelAndView mav = new ModelAndView(ajaxMainView);
			for(int i = 0; i<arr.length; i++){
				System.out.println(arr[i]);
			}
		
			List<EgovMap> answerManagement = cosamoAnswerManagementService.searchAll_AM(arr);
			mav.addObject("totalSList",answerManagement);
			System.out.println(answerManagement);
		
			return mav;
			
		}
		
		//상세보기-모범답안
		@RequestMapping(value="/AnswerManagement/smodal.do")
		public ModelAndView searchAnswerManagementModal(String arr[]) throws Exception{
			ModelAndView mav = new ModelAndView(ajaxMainView);
			for(int i = 0; i<arr.length; i++)
				System.out.println(arr[i]);
			//arr[3]=arr[3].toString();
			List<EgovMap> answerManagement= cosamoAnswerManagementService.search_AMM(arr);
			mav.addObject("searchModalList",answerManagement);
			System.out.println(answerManagement);
			
			List<EgovMap> mediaPath = cosamoAnswerManagementService.selectMediaPath();
			mav.addObject("mediaPath", mediaPath);
			
			
			return mav;
			
		}
		//모범답안 추가
		@RequestMapping(value="/AnswerManagement/acModal.do")
		public ModelAndView searchAnswerManagementACModal(MultipartHttpServletRequest request) throws Exception{

			
			List<FileVO> _result=null;
			String _atchFileId="";
			ModelAndView mav = new ModelAndView(ajaxMainView);
			//for(int i = 0; i<arr.length; i++)
			//	System.out.println(arr[i]);

			String mac1=request.getParameter("mac1");
			String mac2=request.getParameter("mac2");
			String mac3=request.getParameter("mac3");
			String mac4=request.getParameter("mac4");
			String macFB=request.getParameter("macFB");
			MultipartFile video=request.getFile("video");
			MultipartFile voice=request.getFile("voice");
			System.out.println("***"+mac1+mac2+mac3+mac4+macFB);
			
			final Map<String,MultipartFile> files = request.getFileMap();
			if(!files.isEmpty()){
				_result=fileUtil.parseFileInf(files,"BBS_",0,"","");
				_atchFileId = fileMngService.insertFileInfs(_result);
			}
			
			//List<EgovMap> answerManagement= cosamoAnswerManagementService.addC_AM(arr);
			//mav.addObject("addModalListC",answerManagement);
			//System.out.println(answerManagement);
			
			return mav;
			
		}
		//오답안 추가
		@RequestMapping(value="/AnswerManagement/awModal.do")
		public ModelAndView searchAnswerManagementAWModal(String arr[]) throws Exception{
			ModelAndView mav = new ModelAndView(ajaxMainView);
			for(int i = 0; i<arr.length; i++)
				System.out.println(arr[i]);

			List<EgovMap> answerManagement= cosamoAnswerManagementService.addW_AM(arr);
			mav.addObject("addModalListW",answerManagement);
			System.out.println(answerManagement);
			
			return mav;
			
		}
		
		@RequestMapping(value="/AnswerManagement/mModal.do")
		public ModelAndView searchAnswerManagementmModal(String arr[]) throws Exception{
			ModelAndView mav = new ModelAndView(ajaxMainView);
			for(int i = 0; i<arr.length; i++)
				System.out.println(arr[i]);

			List<EgovMap> answerManagement= cosamoAnswerManagementService.search_AMM_m(arr);
			mav.addObject("modifyModalList",answerManagement);
			System.out.println(answerManagement);
			
			return mav;
			
		}
	
		
		//수정 모달 초기로드
		@RequestMapping(value="/AnswerManagement/iModal.do")
		public ModelAndView searchAnswerManagementiModal(String arr[]) throws Exception{
			ModelAndView mav = new ModelAndView(ajaxMainView);
			for(int i = 0; i<arr.length; i++)
				System.out.println(arr[i]);

			List<EgovMap> answerManagement= cosamoAnswerManagementService.search_AMM_i(arr);
			mav.addObject("initModalList",answerManagement);
			System.out.println(answerManagement);
			
			List<EgovMap> mediaPath = cosamoAnswerManagementService.selectMediaPath();
			mav.addObject("mediaPath", mediaPath);
			
			return mav;
			
		}
	
		
		// 답안삭제
		@RequestMapping(value="/AnswerManagement/delete.do")
		public ModelAndView searchAnswerManagementD(String arr[]) throws Exception{
			ModelAndView mav = new ModelAndView(ajaxMainView);
			for(int i = 0; i<arr.length; i++){
				System.out.println(arr[i]);
			}
		
			List<EgovMap> answerManagement= cosamoAnswerManagementService.search_D(arr);
			mav.addObject("totalDList",answerManagement);
			System.out.println(answerManagement);
		
			return mav;
			
		}
		
		
}
