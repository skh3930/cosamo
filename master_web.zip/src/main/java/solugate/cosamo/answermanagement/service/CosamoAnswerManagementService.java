package solugate.cosamo.answermanagement.service;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import solugate.cosamo.answermanagement.dao.CosamoAnswerManagementDAO;
import solugate.cosamo.vo.AnswerManagementVO;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;
import egovframework.rte.psl.dataaccess.util.EgovMap;
@Service("cosamoAnswerManagementService")
public class CosamoAnswerManagementService {
	
		@Resource(name = "cosamoAnswerManagementDAO")
		private CosamoAnswerManagementDAO cosamoAnswerManagementDAO;
		
		
		public List<EgovMap> selectMediaPath() throws Exception {
			return cosamoAnswerManagementDAO.selectMediaPath();
		}
		
	
		public List<EgovMap> searchAll_AM(String arr[]) throws Exception {
			
			AnswerManagementVO amv=new AnswerManagementVO();

		//	amv.setComboSearch(arr[0]);
		//	amv.setInputSearch(arr[1]);
			amv.setComboS1(arr[0]);
			amv.setComboS2(arr[1]);
			amv.setComboS3(arr[2]);
			
			return cosamoAnswerManagementDAO.searchAll_AM(amv);
		}

	
	public List<EgovMap> search_AMM(String arr[]) throws Exception {
			
			AnswerManagementVO amv=new AnswerManagementVO();

			
			amv.setId(arr[0]);
			
			return cosamoAnswerManagementDAO.search_AMM(amv);
		}

	

	public List<EgovMap> search_AMM_m(String arr[]) throws Exception {
		
		AnswerManagementVO amv=new AnswerManagementVO();
	
		amv.setInputS4(arr[0]);
		amv.setFb(arr[1]);
		amv.setId(arr[2]);

	
		return cosamoAnswerManagementDAO.search_AMM_m(amv);
	}



//modify 모달 초기화
public List<EgovMap> search_AMM_i(String arr[]) throws Exception {
	
	AnswerManagementVO amv=new AnswerManagementVO();
	 // 모범:1, 오답:2
	System.out.println("서비스"+arr[0]);
	amv.setId(arr[0]);


	return cosamoAnswerManagementDAO.search_AMM_i(amv);
}


public List<EgovMap> search_D(String arr[]) throws Exception {

		AnswerManagementVO amv=new AnswerManagementVO();
		 // 모범:1, 오답:2
		
		amv.setId(arr[0]);


		return cosamoAnswerManagementDAO.search_D(amv);
}

//모범답안 추가
public List<EgovMap> addC_AM(String[] arr) {
	
	AnswerManagementVO amv=new AnswerManagementVO();
	amv.setComboS1(arr[0]);
	amv.setComboS2(arr[1]);
	amv.setComboS3(arr[2]);
	amv.setInputS4(arr[3]);
	amv.setVoicePath(arr[4]);
	amv.setVideoPath(arr[5]);


	return cosamoAnswerManagementDAO.addC_AM(amv);
}
//오답안 추가
public List<EgovMap> addW_AM(String[] arr) {
	
	AnswerManagementVO amv=new AnswerManagementVO();

	amv.setComboS1(arr[0]);
	amv.setComboS2(arr[1]);
	amv.setComboS3(arr[2]);
	amv.setInputS4(arr[3]);
	amv.setAcc(arr[4]);
	amv.setVoicePath(arr[5]);


	return cosamoAnswerManagementDAO.addW_AM(amv);
}



	
}
