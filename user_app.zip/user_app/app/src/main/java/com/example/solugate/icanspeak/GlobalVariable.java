package com.example.solugate.icanspeak;

import android.app.Application;

/**
 * Created by solugate on 2016-07-25.
 */
public class GlobalVariable extends Application {
    public String studyType = "";
    public String studyCategory = "";
    private String imageFileName = "";

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public void onTerminate() {
        super.onTerminate();
    }

    public void setStudyType(String studyType) {
        this.studyType = studyType;
    }

    public String getStudyType() {
        return studyType;
    }

    public void setStudyCategory(String studyCategory) {
        this.studyCategory = studyCategory;
    }

    public String getStudyCategory() {
        return studyCategory;
    }

    public void setImageFileName(String imageFileName) {
        this.imageFileName = imageFileName;
    }

    public String getImageFileName() {
        return imageFileName;
    }
}