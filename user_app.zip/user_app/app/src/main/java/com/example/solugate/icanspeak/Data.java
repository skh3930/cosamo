package com.example.solugate.icanspeak;


import android.os.Parcelable;

/**
 * Created by sgdev on 2016-08-11.
 */
public class Data {
    public String s_name;
    public String s_value;

    public Data(String s_name, String s_value){
        this.s_name = s_name;
        this.s_value = s_value;
    }
    public Data(){
        s_name = "";
        s_value = "";
    }
}