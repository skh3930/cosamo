package com.example.solugate.icanspeak;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

/**
 * Created by Samsung on 2016-07-31.
 */

public class StudyInitActivity extends FragmentActivity implements View.OnClickListener {

    SharedPreferences studyPref;

    private ImageView _circle01, _circle02, _circle03, _circle04, _circle05;  // circle indicator
    private ViewPager pager;              // 뷰 페이저
    private Button btn_close;
    private TextViewPlus init_title;
    public int numSubCategory;
    public String title_file, word_sentence_img, study_type;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_study_init);

        // 프리퍼런스 설정
        studyPref = getSharedPreferences("study", 0);

        title_file = studyPref.getString("IMAGE_FILE_NAME", "");           // 타이틀 이미지 파일명
        study_type = studyPref.getString("STUDY_TYPE", "");                // 음절/단어/문장
        numSubCategory = studyPref.getInt("NUMBER_OF_SUB_CATEGORY", 0);   // 하위 카테고리 개수

        // 학습 종류가 음절이 아닌 경우 하나의 세부 카테고리에 1개의 이미지만 있으므로 바로 이미지 설정
        if (study_type != "syllable")
            word_sentence_img = studyPref.getString("STUDY_INIT_IMAGE_FILE", "");

        // 초기 화면 타이틀 설정
        init_title = (TextViewPlus) findViewById(R.id.textViewPlus1);
        String resName = "@string/" + title_file;             // resource 이름
        String resType = "string";                            // resource 타입
        String packageName = "com.example.solugate.icanspeak";  // package 이름
        int resID = getResources().getIdentifier(resName, resType, packageName);
        init_title.setText(getString(resID)); // 해당 resource file 로 타이틀 이미지 변경

        // 나가기 버튼 설정
        btn_close = (Button) findViewById(R.id.btn_close);
        btn_close.setOnClickListener(this);

        setUpView();
        setTab();

        // circle indicator 설정
        onCircleIndicatorClick();
    }

    private void setUpView() {
        // 뷰 페이저에 어댑터 설정
        pager = (ViewPager) findViewById(R.id.viewPager);
        MyPagerAdapter mAdapter = new MyPagerAdapter(getSupportFragmentManager());
        pager.setAdapter(mAdapter);
        pager.setOffscreenPageLimit(3);
        pager.setCurrentItem(0, true);
        pager.setPageMargin(70);
        pager.setFadingEdgeLength(30);

        initCircleIndicator();
    }

    private void setTab() {
        pager.addOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
            @Override
            public void onPageScrollStateChanged(int position) {
            }

            @Override
            public void onPageScrolled(int arg0, float arg1, int arg2) {
            }

            @Override
            public void onPageSelected(int position) {
                // TODO Auto-generated method stub
                _circle01.setImageResource(R.drawable.holo_circle);
                _circle02.setImageResource(R.drawable.holo_circle);
                _circle03.setImageResource(R.drawable.holo_circle);
                _circle04.setImageResource(R.drawable.holo_circle);
                _circle05.setImageResource(R.drawable.holo_circle);
                indicatorAction(position);  // 현재 위치 indicator 활성화
            }
        });
    }

    // circle indicator 클릭 리스너
    private void onCircleIndicatorClick() {
        _circle01.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                _circle01.setImageResource(R.drawable.fill_circle);
                pager.setCurrentItem(0);
            }
        });

        _circle02.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                _circle02.setImageResource(R.drawable.fill_circle);
                pager.setCurrentItem(1);
            }
        });
        _circle03.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                _circle03.setImageResource(R.drawable.fill_circle);
                pager.setCurrentItem(2);
            }
        });
        _circle04.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                _circle04.setImageResource(R.drawable.fill_circle);
                pager.setCurrentItem(3);
            }
        });
        _circle05.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                _circle05.setImageResource(R.drawable.fill_circle);
                pager.setCurrentItem(4);
            }
        });
    }

    // 현재 위치해 있는 indicator 활성화
    private void indicatorAction(int action) {
        switch (action) {
            case 0:
                _circle01.setImageResource(R.drawable.fill_circle);
                break;
            case 1:
                _circle02.setImageResource(R.drawable.fill_circle);
                break;
            case 2:
                _circle03.setImageResource(R.drawable.fill_circle);
                break;
            case 3:
                _circle04.setImageResource(R.drawable.fill_circle);
                break;
            case 4:
                _circle05.setImageResource(R.drawable.fill_circle);
                break;
        }
    }

    // circle indicator 초기화 설정
    private void initCircleIndicator() {
        _circle01 = (ImageView) findViewById(R.id.circle_1);
        _circle01.setImageResource(R.drawable.fill_circle); // 활성화 이미지로 초기화
        _circle02 = (ImageView) findViewById(R.id.circle_2);
        _circle03 = (ImageView) findViewById(R.id.circle_3);
        _circle04 = (ImageView) findViewById(R.id.circle_4);
        _circle05 = (ImageView) findViewById(R.id.circle_5);

        if (numSubCategory == 3) {
            _circle01.setVisibility(View.INVISIBLE);
            _circle02.setVisibility(View.VISIBLE);
            _circle02.setImageResource(R.drawable.fill_circle);
            _circle05.setVisibility(View.INVISIBLE);
        } else if (numSubCategory == 2) {
            _circle01.setVisibility(View.INVISIBLE);
            _circle02.setVisibility(View.VISIBLE);
            _circle02.setImageResource(R.drawable.fill_circle);
            _circle03.setVisibility(View.INVISIBLE);
            _circle05.setVisibility(View.INVISIBLE);
        } else if (numSubCategory == 1) {
            _circle01.setVisibility(View.INVISIBLE);
            _circle02.setVisibility(View.INVISIBLE);
            _circle03.setVisibility(View.INVISIBLE);
            _circle04.setVisibility(View.INVISIBLE);
            _circle05.setVisibility(View.INVISIBLE);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_close:
                onBackPressed();
                break;
        }
    }

    private class MyPagerAdapter extends FragmentPagerAdapter {
        private String image_file_name;
        private String text_string_1, text_string_2, text_string_3, text_string_4, text_string_5;

        public MyPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int pos) {
            /**
             *
             * sub category 개수에 따라 음절/단어/문장 구분한다.
             * image_file_name : 학습 초기 화면의 이미지 파일 명
             * text_string_1 ... : 음절 학습의 경우 - 모음연습1, 모음연습2 과 같은 텍스트 지정
             *
             **/
            if (numSubCategory == 3) {
                image_file_name = "init_syllable_1";
                text_string_1 = "syllable1";
                text_string_2 = "syllable2";
                text_string_3 = "syllable3";
            } else if (numSubCategory == 5) {
                image_file_name = "init_syllable_2";
                text_string_1 = "syllable4";
                text_string_2 = "syllable5";
                text_string_3 = "syllable6";
                text_string_4 = "syllable7";
                text_string_5 = "syllable8";
            } else if (numSubCategory == 2) {
                image_file_name = "init_syllable_3";
                text_string_1 = "syllable9";
                text_string_2 = "syllable10";
            } else {
                if (study_type.equals("syllable")) {
                    image_file_name = "init_syllable_4";
                    text_string_1 = "syllable11";
                } else  // 단어/문장 학습인 경우 text_string 은 필요 없다.
                    image_file_name = word_sentence_img;
            }

            switch (pos) {
                case 0:
                    return StudyInitFragment.newInstance(image_file_name, text_string_1, study_type);
                case 1:
                    return StudyInitFragment.newInstance(image_file_name, text_string_2, study_type);
                case 2:
                    return StudyInitFragment.newInstance(image_file_name, text_string_3, study_type);
                case 3:
                    return StudyInitFragment.newInstance(image_file_name, text_string_4, study_type);
                case 4:
                    return StudyInitFragment.newInstance(image_file_name, text_string_5, study_type);
                default:
                    return StudyInitFragment.newInstance(image_file_name, text_string_5, study_type);
            }
        }

        @Override
        public int getCount() {
            return numSubCategory;
        }
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(this, StudyMainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
        finish();
    }
}