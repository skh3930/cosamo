package com.example.solugate.icanspeak;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Created by solugate on 2016-07-27.
 */
public class StatusListActivity extends AppCompatActivity implements View.OnClickListener {

    // 어플리케이션 종료 handler
    private BackPressCloseHandler backPressCloseHandler;

    // 액션바
    private Button btn_back, btn_check;     // 액션 바 버튼
    private ImageView actionBarTitle;       // 현재 화면 타이틀
    private TextView txtVoice;              // 음성인식 상태 텍스트

    // 탭
    private Button btn_tab1, btn_tab2, btn_tab3;

    //검색바
    private EditText edit_search;

    //리스트
    private ArrayList<StatusListAdapter> adapter_list;
    private ArrayList<View> view_list;
    private LinearLayout layout_table;
    private TextView list_title;
    private ListView listview_list;
    private Data item;

    //전 activity에서 넘어온 변수
    private String para;
    private ArrayList<String> s_category_list;
    private ArrayList<Study> s_study_list;

    LoginActivity login;
    private String u_no;
    SharedPreferences pref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_status_list);

        pref = getSharedPreferences(login.PREFS_NAME, 0);

        // pref 에서 사용자 정보 가져오기
        u_no = pref.getString("userNo", "");

        s_category_list = new ArrayList<String>();
        s_study_list = new ArrayList<Study>();
        adapter_list = new ArrayList<StatusListAdapter>();
        view_list = new ArrayList<View>();

        //전 activity에서 값 가져옴
        Intent intent = getIntent();
        para = intent.getExtras().getString("para");

        selectCategoryResultInfoFromDB(para);
        selectUserStudyResultInfoFromDB(para);

        // 두번 클릭 시 어플리케이션 종료
        backPressCloseHandler = new BackPressCloseHandler(this);

        setCustomActionbar();   // 커스텀 액션 바 적용
        setCustomTab();     // 커스텀 탭 적용

        //검색바
        edit_search = (EditText) findViewById(R.id.edit_search);
        // Capture Text in EditText
        edit_search.addTextChangedListener(new TextWatcher() {

            @Override
            public void afterTextChanged(Editable arg0) {
                // TODO Auto-generated method stub
                String text = edit_search.getText().toString().toLowerCase(Locale.getDefault());
                for (int i = 0; i < adapter_list.size(); i++)
                    adapter_list.get(i).filter(text,view_list.get(i));
            }

            @Override
            public void beforeTextChanged(CharSequence arg0, int arg1,
                                          int arg2, int arg3) {
                // TODO Auto-generated method stub
            }

            @Override
            public void onTextChanged(CharSequence arg0, int arg1, int arg2,
                                      int arg3) {
                // TODO Auto-generated method stub
            }
        });

        //동적 리스트 추가
        layout_table = (LinearLayout) findViewById(R.id.layout_list_table);

        for (int i = 0; i < s_category_list.size(); i++) {
            final List<Data> item_list = new ArrayList<Data>();

            LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View view = inflater.inflate(R.layout.layout_status_list, null);
            list_title = (TextView) view.findViewById(R.id.text_list_title);
            listview_list = (ListView) view.findViewById(R.id.listview_list);

            //제목 설정
            list_title.setText(s_category_list.get(i));

            //값 입력
            for (int j = 0; j < s_study_list.size(); j++) {
                if (s_category_list.get(i).equals(s_study_list.get(j).s_category)) {
                    item = new Data(s_study_list.get(j).s_txt, s_study_list.get(j).s_acc + "%");
                    item_list.add(item);
                }
            }

            //아무 학습이 없을 경우 빈 리스트 하나 추가
            if (item_list.size() == 0) {
                TextView text_noStudy = (TextView) view.findViewById(R.id.text_noStudy);
                text_noStudy.setVisibility(View.VISIBLE);
            }

            layout_table.addView(view);

            //Adatpter 생성
            StatusListAdapter adapter = new StatusListAdapter(this, item_list);
            listview_list.setAdapter(adapter);
            listview_list.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
            listViewHeightSet(adapter, listview_list);

            adapter_list.add(adapter);
            view_list.add(view);

            listview_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    //리스트 아이템 선택시 이벤트
                    if (item_list.get(position).s_name.length() != 0) { //빈 리스트가 아닐때
                        Intent intent = new Intent(StatusListActivity.this, StudyActivity.class);
                        intent.putExtra("type", "");
                        intent.putExtra("category", "single");
                        intent.putExtra("ca_txt", item_list.get(position).s_name);
                        startActivity(intent);

                     //   Toast.makeText(StatusListActivity.this, item_list.get(position).s_name, Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

    }

    //스크롤 방지를 위해 LIST VIEW 아이템 갯수만큼 높이 설정
    private static void listViewHeightSet(BaseAdapter listAdapter, ListView listView) {
        int totalHeight = 0;
        for (int i = 0; i < listAdapter.getCount(); i++) {
            View listItem = listAdapter.getView(i, null, listView);
            listItem.measure(0, 0);
            totalHeight += listItem.getMeasuredHeight();
        }

        ViewGroup.LayoutParams params = listView.getLayoutParams();
        params.height = totalHeight + (listView.getDividerHeight() * (listAdapter.getCount() - 1));
        listView.setLayoutParams(params);
    }


    // 커스텀 액션 바
    private void setCustomActionbar() {
        ActionBar actionBar = getSupportActionBar();

        // Custom Action bar를 사용하기 위한 설정
        actionBar.setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        actionBar.setDisplayShowCustomEnabled(true);
        actionBar.setCustomView(R.layout.layout_actionbar);
        //    actionBar.setDisplayHomeAsUpEnabled(false);
        //   actionBar.setDisplayShowTitleEnabled(false);

        // Set Custom view layout
        View mCustomView = getSupportActionBar().getCustomView();

        // 액션바 뒤로가기 버튼
        btn_back = (Button) findViewById(R.id.btn_back);
        btn_back.setOnClickListener(this);

        // 액션 바 타이틀
        actionBarTitle = (ImageView) findViewById(R.id.actionbar_title);

        if (para.equals("syllable_average")) {
            actionBarTitle.setImageResource(R.drawable.actionbar_syllable_status);
        } else if (para.equals("syllable_favorites")) {
            actionBarTitle.setImageResource(R.drawable.actionbar_syllable_favorites);
        } else if (para.equals("syllable_weak_studies")) {
            actionBarTitle.setImageResource(R.drawable.actionbar_syllable_weak);
        } else if (para.equals("word_average")) {
            actionBarTitle.setImageResource(R.drawable.actionbar_word_status);
        } else if (para.equals("word_favorites")) {
            actionBarTitle.setImageResource(R.drawable.actionbar_word_favorites);
        } else if (para.equals("word_weak_studies")) {
            actionBarTitle.setImageResource(R.drawable.actionbar_word_weak);
        } else if (para.equals("sentence_average")) {
            actionBarTitle.setImageResource(R.drawable.actionbar_sentence_status);
        } else if (para.equals("sentence_favorites")) {
            actionBarTitle.setImageResource(R.drawable.actionbar_sentence_favorites);
        } else if (para.equals("sentence_weak_studies")) {
            actionBarTitle.setImageResource(R.drawable.actionbar_sentence_weak);
        }

        actionBarTitle.setVisibility(View.VISIBLE);

        // 액션바 확인 버튼 비활성화
        btn_check = (Button) findViewById(R.id.btn_check);
        btn_check.setVisibility(View.INVISIBLE);

        // set action bar layout layoutparams
        ActionBar.LayoutParams params = new ActionBar.LayoutParams(ActionBar.LayoutParams.MATCH_PARENT, ActionBar.LayoutParams.MATCH_PARENT);
        actionBar.setCustomView(mCustomView, params);

        Toolbar parent = (Toolbar) mCustomView.getParent();
        parent.setContentInsetsAbsolute(0, 0);

    }

    private void setCustomTab() {
        btn_tab1 = (Button) findViewById(R.id.tab_01);
        btn_tab1.setOnClickListener(this);

        btn_tab2 = (Button) findViewById(R.id.tab_02);
        btn_tab2.setOnClickListener(this);

        btn_tab3 = (Button) findViewById(R.id.tab_03);
        btn_tab3.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tab_01:
                Intent intent1 = new Intent(this, StudyMainActivity.class);
                startActivity(intent1);
                finish();
                break;
            case R.id.tab_02:
                Intent intent2 = new Intent(this, StatusMainActivity.class);
                startActivity(intent2);
                finish();
                break;
            case R.id.tab_03:
                Intent intent3 = new Intent(this, MyPageMainActivity.class);
                startActivity(intent3);
                finish();
                break;
            case R.id.btn_back:
                onBackPressed();
                break;
        }
    }

    //유저의 음절,단어, 문장의 학습 정보를 가져옴
    public void selectUserStudyResultInfoFromDB(String s_flag) {

        DBManager dbManager = new DBManager();

        dbManager.setAParameter("U_NO", u_no);
        dbManager.setAParameter("FLAG", s_flag);

        dbManager.db_connect("http://211.210.32.57:9907/COSAMO/get_status_study_list.php");

        while (true) {
            Study s = new Study();
            s.s_no = dbManager.getResult("S_NO");
            s.s_acc = dbManager.getResult("W_ACC");
            s.s_txt = dbManager.getResult("CA_TXT");
            s.s_category = dbManager.getResult("CA_CATEGORY");
            s_study_list.add(s);

            if (!dbManager.setNextData()) {
                break;
            }
        }
    }

    public void selectCategoryResultInfoFromDB(String s_flag) {

        DBManager dbManager = new DBManager();

        if (s_flag.equals("syllable_average") || s_flag.equals("syllable_favorites") || s_flag.equals("syllable_weak_studies")) {
            dbManager.setAParameter("FLAG", "syllable");
        } else if (s_flag.equals("word_average") || s_flag.equals("word_favorites") || s_flag.equals("word_weak_studies")) {
            dbManager.setAParameter("FLAG", "word");
        } else {
            dbManager.setAParameter("FLAG", "sentence");
        }

        dbManager.db_connect("http://211.210.32.57:9907/COSAMO/get_status_category_list.php");

        while (true) {
            s_category_list.add(dbManager.getResult("CA_CATEGORY"));

            if (!dbManager.setNextData()) {
                break;
            }
        }
    }

    public void onBackPressed() {
        super.onBackPressed();
    }

    private class Study {
        public String s_no;
        public String s_acc;
        public String s_category;
        public String s_txt;
    }
}