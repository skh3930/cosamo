package com.example.solugate.icanspeak;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Created by solugate on 2016-07-19.
 */
public class LoginActivity extends Activity implements View.OnClickListener {

    SharedPreferences pref;
    SharedPreferences.Editor editor;

    private BackPressCloseHandler backPressCloseHandler;    // 어플리케이션 종료 handler
    private EditText input_id, input_pw;
    private Button btn_login, btn_join;         // 로그인, 회원가입 버튼
    private CheckBox checkBox_auto_login, checkBox_save_id;
    private String user_id, user_pw;
    private Boolean idChecked, loginChecked;

    public static String userName, userClass, userSeqNum, userLogSeqNum;  // 사용자 고유번호

    public static final String PREFS_NAME = "LoginPrefs";
    public static final String STATUS_ON = "1";     // 사용자 접속 상태 (접속중)
    public static final String STATUS_OFF = "0";    // 사용자 접속 상태 (접속 종료)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        idChecked = loginChecked = false;
        userLogSeqNum = ""; // 사용자 로그 고유번호

        // 프리퍼런스 설정
        pref = getSharedPreferences(PREFS_NAME, 0);
        editor = pref.edit();

        // 두번 클릭 시 어플리케이션 종료
        backPressCloseHandler = new BackPressCloseHandler(this);

        input_id = (EditText) findViewById(R.id.userId);
        input_pw = (EditText) findViewById(R.id.userPassword);

        // 로그인 버튼
        btn_login = (Button) findViewById(R.id.btn_login);
        btn_login.setOnClickListener(this);

        // 회원가입 버튼
        btn_join = (Button) findViewById(R.id.btn_join);
        btn_join.setOnClickListener(this);

        // 아이디 저장 체크박스
        checkBox_save_id = (CheckBox) findViewById(R.id.checkBox_id);
        checkBox_save_id.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if (isChecked) {
                    idChecked = true;
                } else {
                    // 아이디 저장 체크박스 해제시 저장된 정보 삭제
                    idChecked = false;
                    editor.clear();
                    editor.commit();
                }
            }
        });

        // 자동 로그인 체크박스
        checkBox_auto_login = (CheckBox) findViewById(R.id.checkBox_auto_login);
        checkBox_auto_login.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if (isChecked) {
                    loginChecked = true;
                    idChecked = false;
                }
                else {
                    // 자동 로그인 체크박스 해제시 저장된 정보 삭제
                    loginChecked = false;
                    editor.clear();
                    editor.commit();
                }
            }
        });

        // 프리퍼런스에 자동 로그인이 설정된 경우
        if (pref.getBoolean("autoLogin", false)) {
            // 저장된 아이디와 비밀번호 가져오기
            input_id.setText(pref.getString("userID", ""));
            input_pw.setText(pref.getString("userPW", ""));
            checkBox_auto_login.setChecked(true);

            checkToday();   //오늘 날짜인지 확인
            // 메인 학습 페이지로 이동
            Intent intent = new Intent(this, StudyMainActivity.class);
            startActivity(intent);
            finish();
        }

        // 프리퍼런스에 아이디 저장이 설정된 경우
        else if (pref.getBoolean("saveID", false)) {
            // saveID 세팅 값을 가져오고, 값이 없으면 기본값 false 가져옴
            input_id.setText(pref.getString("userID", ""));
            checkBox_save_id.setChecked(true);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_login:
                loginProcess();
                break;

            case R.id.btn_join:
                Intent intent2 = new Intent(this, JoinActivity.class);
                intent2.putExtra("ACTIONBAR_TITLE", "actionbar_member_join");
                startActivity(intent2);
                break;
        }
    }

    private void loginProcess() {
        if (checkLoginInfoFromDB()) {
            user_id = input_id.getText().toString();
            user_pw = input_pw.getText().toString();

            if (idChecked) {
                // 아이디 저장 설정 시
                editor.putString("userID", user_id);    // 사용자 아이디
                editor.putBoolean("saveID", true);      // 아이디 저장 여부
                editor.commit();
            } else if (loginChecked) {
                // 자동 로그인 설정 시
                editor.putString("userID", user_id);    // 사용자 아이디
                editor.putString("userPW", user_pw);    // 사용자 패스워드
                editor.putBoolean("autoLogin", true);   // 자동 로그인 설정 여부
                editor.commit();
            }
            editor.putString("userID", user_id);    // 사용자 아이디
            editor.putString("userName", userName);     // 사용자 이름
            editor.putString("userClass", userClass);   // 사용자 장애등급
            editor.putString("userNo", userSeqNum);   // 사용자 고유번호
            editor.commit();

            // 사용자 로그 저장
            insertUserLogToDB();

            checkToday();   //오늘 날짜인지 확인
            // 메인 학습 화면으로 이동
            Intent intent1 = new Intent(this, StudyMainActivity.class);
            startActivity(intent1);
            finish();
        } else {
            Toast.makeText(this, "ID 또는 PW가 올바르지 않습니다.", Toast.LENGTH_LONG).show();
        }
    }

    // id, pw validation check
    private boolean checkLoginInfoFromDB() {
        DBManager dbManager = new DBManager();
        dbManager.setAParameter("U_ID", input_id.getText().toString());
        dbManager.setAParameter("U_PW", input_pw.getText().toString());

        dbManager.db_connect("http://211.210.32.57:9907/COSAMO/login.php");

        userSeqNum = dbManager.getResult("U_NO");

        if (!userSeqNum.equals("-1")) {
            // 사용자 고유번호, 이름, 아이디, 장애등급
            userName = dbManager.getResult("U_NAME");
            userClass = dbManager.getResult("U_CLASS");
            return true;
        } else
            return false;
    }

    // 사용자 로그
    private void insertUserLogToDB() {

        DBManager dbManager = new DBManager();

        dbManager.setAParameter("UL_NO", "");
        dbManager.setAParameter("U_NO", userSeqNum);  // 사용자 고유번호
        dbManager.setAParameter("UL_STATUS", STATUS_ON);    // 유저 접속상태
        // 1: 접속중(STATUS_ON) / 0: 접속 종료(STATUS_OFF)
        dbManager.setAParameter("UL_END_REASON", "");     // 접속 종료 이유

        dbManager.db_connect("http://211.210.32.57:9907/COSAMO/user_log.php");

        userLogSeqNum = dbManager.getResult();
    }

    // 오늘인지 체크하기
    private void checkToday() {

        DBManager dbManager = new DBManager();

        dbManager.setAParameter("U_ID", user_id);

        dbManager.db_connect("http://211.210.32.57:9907/COSAMO/check_today.php");
    }

    @Override
    public void onBackPressed() {
        backPressCloseHandler.onBackPressed();
    }
}