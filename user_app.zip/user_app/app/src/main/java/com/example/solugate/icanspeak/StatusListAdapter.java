package com.example.solugate.icanspeak;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Created by sgdev on 2016-08-02.
 */


public class StatusListAdapter extends BaseAdapter {

    // Declare Variables
    private Context mContext;
    private LayoutInflater inflater;
    private List<Data> Datalist = null;
    private ArrayList<Data> arraylist;

    public StatusListAdapter(Context context, List<Data> Datalist) {
        mContext = context;
        this.Datalist = Datalist;
        inflater = LayoutInflater.from(mContext);
        this.arraylist = new ArrayList<Data>();
        this.arraylist.addAll(Datalist);
    }

    public class ViewHolder {
        TextView text_title;
        TextView text_accuracy;
    }

    @Override
    public int getCount() {
        return Datalist.size();
    }

    @Override
    public Data getItem(int position) {
        return Datalist.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public View getView(final int position, View view, ViewGroup parent) {
        final ViewHolder holder;
        if (view == null) {
            holder = new ViewHolder();
            view = inflater.inflate(R.layout.layout_status_item, null);
            // Locate the TextViews in listview_item.xml
            holder.text_title = (TextView) view.findViewById(R.id.text_title);
            holder.text_accuracy = (TextView)view.findViewById(R.id.text_accuracy);
            view.setTag(holder);
        } else {
            holder = (ViewHolder) view.getTag();
        }
        // Set the results into TextViews
        holder.text_title.setText(Datalist.get(position).s_name);
        holder.text_accuracy.setText(Datalist.get(position).s_value);

        return view;
    }

    // Filter Class
    public void filter(String charText, View view) {
        charText = charText.toLowerCase(Locale.getDefault());
        TextView text_noStudy = (TextView) view.findViewById(R.id.text_noStudy);
        Datalist.clear();
        if (charText.length() == 0) {
            text_noStudy.setVisibility(View.GONE);
            Datalist.addAll(arraylist);
        } else {
            for (Data wp : arraylist) {
                if (wp.s_name.toLowerCase(Locale.getDefault()).contains(charText)) {
                    Datalist.add(wp);
                }
            }
            if(Datalist.size() == 0) {   //아무런 검색 결과가 없을 때,
                text_noStudy.setVisibility(View.VISIBLE);
            }else {
                text_noStudy.setVisibility(View.GONE);
            }
        }
        notifyDataSetChanged();
    }
}