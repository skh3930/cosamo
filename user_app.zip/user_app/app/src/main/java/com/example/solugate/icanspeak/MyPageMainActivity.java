package com.example.solugate.icanspeak;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;

/**
 * Created by solugate on 2016-07-27.
 */
public class MyPageMainActivity extends AppCompatActivity implements View.OnClickListener {

    // 어플리케이션 종료 handler
    private BackPressCloseHandler backPressCloseHandler;

    // 액션바
    private Button btn1, btn2;
    private ImageView actionBarTitle;

    private Button btn_tab1, btn_tab2, btn_tab3;    // 탭
    private Button btn_logout, btn_modify;                      // 로그아웃 버튼
    private TextView text_id, text_name, text_class, text_total_study_day, text_average_acc;    //유저 정보
    private LineChart lineChart;                    // 주간 그래프
    private ArrayList<Entry> entries;

    private String u_id, u_name, u_class, u_img_path;
    private int n_day_acc[];
    private int n_acc_sum, n_day_cnt;

    LoginActivity login;
    SharedPreferences pref;
    SharedPreferences.Editor editor;

    public static final String LOGOUT = "LOGOUT";    // 사용자 접속 상태 (접속 종료)
    public static final String FINISH = "FINISH";    // 사용자 접속 상태 (접속 종료)
    public static final String UNKNOWN = "UNKNOWN";    // 사용자 접속 상태 (접속 종료)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mypage);

        // 프리퍼런스 설정
        pref = getSharedPreferences(login.PREFS_NAME, 0);
        editor = pref.edit();

        entries = new ArrayList<>();
        n_day_acc = new int[7];
        n_acc_sum = 0;
        n_day_cnt = 0;

        // 두번 클릭 시 어플리케이션 종료
        backPressCloseHandler = new BackPressCloseHandler(this);

        // pref 에서 사용자 정보 가져오기
        u_id = pref.getString("userID", "");
        u_name = pref.getString("userName", "");
        u_class = pref.getString("userClass", "");

        // 로그아웃 버튼
        btn_logout = (Button) findViewById(R.id.btn_logout);
        btn_logout.setOnClickListener(this);

        // 회원정보 수정 버튼
        btn_modify = (Button) findViewById(R.id.btn_modify);
        btn_modify.setOnClickListener(this);

        // 유저 정보
        text_id = (TextView) findViewById(R.id.user_id);
        text_id.setText(u_id);

        text_name = (TextView) findViewById(R.id.user_name);
        text_name.setText(u_name);

        text_class = (TextView) findViewById(R.id.user_class);
        text_class.setText("청각 장애 " + u_class + "급");

        selectUserInfoFromDB(); // db에서 현재 유저의 정보를 가져옴

        // 총 학습일, 평균 정확도 설정
        text_total_study_day = (TextView) findViewById(R.id.text_total_study_day);
        text_total_study_day.setText(Integer.toString(n_day_cnt));

        text_average_acc = (TextView) findViewById(R.id.text_average_acc);
        text_average_acc.setText(Integer.toString(n_acc_sum / n_day_cnt));

        setUserResultGraph();   // 사용자 주간 학습 그래프 적용

        setCustomActionbar();   // 커스텀 액션 바 적용
        setCustomTab();         // 커스텀 탭 적용
    }

    // 사용자 주간 학습 그래프 설정
    private void setUserResultGraph() {
        // x 축 라벨 추가
        ArrayList<String> labels = new ArrayList<String>();
        labels.add("수");
        labels.add("목");
        labels.add("금");
        labels.add("토");
        labels.add("일");
        labels.add("월");
        labels.add("화");

        for (int i = 0; i < 7; i++)
            entries.add(new Entry(n_day_acc[i], i));

        // initialize line data set
        LineDataSet lineDataSet = new LineDataSet(entries, "# of Ex-Rates");
        lineDataSet.setDrawCubic(true);     // 곡선 그래프
        lineDataSet.setDrawValues(true);    // 각 데이터 값 출력
        lineDataSet.setAxisDependency(YAxis.AxisDependency.LEFT);
        lineDataSet.setColor(Color.rgb(157, 195, 230));          // 라인 색
        lineDataSet.setCircleColor(Color.rgb(157, 195, 230));    // circle 색
        lineDataSet.setLineWidth(2f);
        lineDataSet.setCircleSize(4f);
        lineDataSet.setFillColor(ColorTemplate.getHoloBlue());
        lineDataSet.setHighLightColor(Color.rgb(244, 117, 177));
        lineDataSet.setValueTextColor(Color.rgb(157, 195, 230));
        lineDataSet.setValueTextSize(10f);

        // create line chart
        lineChart = (LineChart) findViewById(R.id.chart);

        // 데이터를 line chart 에 추가
        LineData lineData = new LineData(labels, lineDataSet);
        lineChart.setData(lineData); // set the data and list of lables into chart
        lineChart.setGridBackgroundColor(Color.WHITE);

        // customize line chart
        lineChart.setDescription("");
        lineChart.setNoDataTextDescription("No data for the moment");

        // X축 값 하단에 배치
        lineChart.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);
        lineChart.getXAxis().setLabelsToSkip(0);

        lineChart.setTouchEnabled(false);
        lineChart.setDragEnabled(true);
        lineChart.setScaleEnabled(true);
        lineChart.setDrawGridBackground(false);
        lineChart.setPinchZoom(false);
        lineChart.getLegend().setEnabled(false);

        XAxis xl = lineChart.getXAxis();
        xl.setDrawGridLines(false);

        YAxis yl = lineChart.getAxisLeft();
        yl.setAxisMaxValue(100f);

        YAxis yr = lineChart.getAxisRight();
        yr.setEnabled(false);

        // 차트의 데이터가 변경되었을 시에 차트 변경
        lineChart.notifyDataSetChanged();
    }

    // 커스텀 액션 바
    private void setCustomActionbar() {
        ActionBar actionBar = getSupportActionBar();

        // Custom Action bar 사용하기 위한 설정
        actionBar.setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        actionBar.setDisplayShowCustomEnabled(true);
        actionBar.setCustomView(R.layout.layout_actionbar);

        // Set Custom view layout
        View mCustomView = getSupportActionBar().getCustomView();

        // 액션바 뒤로가기 버튼 비활성화
        btn1 = (Button) findViewById(R.id.btn_back);
        btn1.setVisibility(View.INVISIBLE);

        // 액션바 타이틀
        actionBarTitle = (ImageView) findViewById(R.id.actionbar_title);
        actionBarTitle.setImageResource(R.drawable.app_title);

        // 액션바 음성테스트 버튼
        btn2 = (Button) findViewById(R.id.btn_check);
        btn2.setVisibility(View.INVISIBLE);

        // set action bar layout layoutparams
        ActionBar.LayoutParams params = new ActionBar.LayoutParams(ActionBar.LayoutParams.MATCH_PARENT, ActionBar.LayoutParams.MATCH_PARENT);
        actionBar.setCustomView(mCustomView, params);

        Toolbar parent = (Toolbar) mCustomView.getParent();
        parent.setContentInsetsAbsolute(0, 0);

    }

    // 탭 설정
    private void setCustomTab() {
        btn_tab1 = (Button) findViewById(R.id.tab_01);
        btn_tab1.setOnClickListener(this);

        btn_tab2 = (Button) findViewById(R.id.tab_02);
        btn_tab2.setOnClickListener(this);

        btn_tab3 = (Button) findViewById(R.id.tab_03);
        btn_tab3.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tab_01:
                Intent intent1 = new Intent(this, StudyMainActivity.class);
                startActivity(intent1);
                finish();
                break;
            case R.id.tab_02:
                Intent intent2 = new Intent(this, StatusMainActivity.class);
                startActivity(intent2);
                finish();
                break;
            case R.id.tab_03:
                Intent intent3 = new Intent(this, MyPageMainActivity.class);
                startActivity(intent3);
                finish();
                break;
            case R.id.btn_modify:
                Intent intent4 = new Intent(this, JoinActivity.class);
                intent4.putExtra("ACTIONBAR_TITLE", "actionbar_modify_user_info");
                intent4.putExtra("USER_ID", u_id);
                startActivity(intent4);
                break;
            case R.id.btn_logout:
                userLogout();
                break;
        }
    }

    // 사용자 로그아웃 다이얼로그
    private void userLogout() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("로그아웃 하시겠습니까?");
        builder.setPositiveButton("네", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if (pref.getBoolean("autoLogin", false)) {
                    editor.putBoolean("autoLogin", false);
                    editor.clear(); // pref 에 저장된 내용 모두 삭제
                    editor.commit();
                }
                updateUserLogToDB(LOGOUT);    // 접속 종료 로그

                Intent intent4 = new Intent(MyPageMainActivity.this, LoginActivity.class);
                startActivity(intent4);
                finish();
            }
        });
        builder.setNegativeButton("아니오", null);
        builder.show();
    }

    // 마이페이지에 표시할 사용자 정보 가져오기
    public void selectUserInfoFromDB() {

        DBManager dbManager = new DBManager();

        dbManager.setAParameter("U_ID", u_id);

        dbManager.db_connect("http://211.210.32.57:9907/COSAMO/get_user_info.php");

        u_img_path = dbManager.getResult("U_IMG_PATH");

        int today_acc = Integer.valueOf(dbManager.getResult("TODAY_ACC"));
        int today_cnt = Integer.valueOf(dbManager.getResult("TODAY_CNT"));
        //오늘의 정확도 50이라고 가정
        if(today_cnt!=0)
            n_day_acc[6] = today_acc/today_cnt;
        else
            n_day_acc[6] = 0;
        n_day_acc[5] = Integer.valueOf(dbManager.getResult("DAY1_ACC"));
        n_day_acc[4] = Integer.valueOf(dbManager.getResult("DAY2_ACC"));
        n_day_acc[3] = Integer.valueOf(dbManager.getResult("DAY3_ACC"));
        n_day_acc[2] = Integer.valueOf(dbManager.getResult("DAY4_ACC"));
        n_day_acc[1] = Integer.valueOf(dbManager.getResult("DAY5_ACC"));
        n_day_acc[0] = Integer.valueOf(dbManager.getResult("DAY6_ACC"));

        //주간 평균 정확도 계산
        for (int i = 0; i < 7; i++) {
            if (n_day_acc[i] != 0) {
                n_acc_sum += n_day_acc[i];
                n_day_cnt++;
            }
        }
    }

    // 사용자 로그 업데이트
    public void updateUserLogToDB(String end_reason) {
        DBManager dbManager = new DBManager();

        dbManager.setAParameter("UL_NO", login.userLogSeqNum);  // 사용자 로그 고유번호
        dbManager.setAParameter("U_NO", login.userSeqNum);      // 사용자 고유번호
        dbManager.setAParameter("UL_STATUS", login.STATUS_OFF);     // 유저 접속상태
        // 1: 접속중(STATUS_ON) / 0: 접속 종료(STATUS_OFF)
        dbManager.setAParameter("UL_END_REASON", end_reason);     // 접속 종료 이유

        dbManager.db_connect("http://211.210.32.57:9907/COSAMO/user_log.php");

        dbManager = null;
    }

    @Override
    public void onBackPressed() {
        updateUserLogToDB(FINISH);
        backPressCloseHandler.onBackPressed();
    }
}