package com.example.solugate.icanspeak;

import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.ArrayList;

/**
 * Created by solugate on 2016-07-21.
 */
public class TCPSocket extends Thread {
    public Socket socket;
    private BufferedReader networkReader;

    private String ip = "211.210.32.57"; // IP
    public int port = 12345; // PORT번호

    ArrayList<String> queue = new ArrayList<String>(); // 서버에서 받아온 값 큐에 저장

    public void run() {
        try {
            setSocket(ip, port);
        } catch (IOException e1) {
            e1.printStackTrace();
        }
        checkUpdate.start();
    }

    public Thread checkUpdate = new Thread() {

        public void run() {
            int i = 0;
            while (true) {
                Log.d("ERROR", "1");
                try {
                    Log.d("ERROR", "2");
                    Log.w("TCPSocket", "start TCP connection");
                    String line = networkReader.readLine();     // 서버에서 값 읽어오기
                    Log.i("TAG", "서버에서 읽어온 값 : " + line);
                    queue.add(line);        // 읽어온 값 큐에 저장
                    Log.i("TAG", "큐에서 꺼내온값 : " + queue.get(i++));
                    Log.i("TAG", "서버에서 읽어온 값 큐에 넣은 다음 : " + line);
                    Log.d("ERROR", "3");
                    if (i == 3){
                        Log.d("ERROR", "4");
                        closeSocket();
                        Log.d("ERROR", "5");
                        break;
                    }
                    Log.d("ERROR", "6");
                } catch (Exception e) {
                    Log.d("ERROR", "7");
                    Log.w("TCPSocket", e.toString());

                }
                Log.d("ERROR", "8");
            }
        }
    };

    public void setSocket(String ip, int port) throws IOException {

        try {
            socket = new Socket(ip, port);
            networkReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        } catch (IOException e) {
            System.out.println(e);
            e.printStackTrace();
        }
    }

    public void closeSocket() {
        try {
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}