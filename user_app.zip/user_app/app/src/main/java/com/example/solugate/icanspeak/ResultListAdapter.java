package com.example.solugate.icanspeak;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by sgdev on 2016-08-05.
 */
public class ResultListAdapter extends BaseAdapter {

    private Context maincon ;
    private ArrayList<String> data;
    private int layout ;
    private LayoutInflater inflater;

    public ResultListAdapter(Context context, int layout, ArrayList<String> data){
        this.maincon = context ;
        this.layout = layout ;
        this.data = data;
        inflater = (LayoutInflater) maincon.getSystemService(context.LAYOUT_INFLATER_SERVICE);
    }
    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int i) {
        return data.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if(view == null){
            view = inflater.inflate(layout, viewGroup, false);
        }

        TextView text_wor_syl = (TextView) view.findViewById(R.id.text_wrong_syl);
        text_wor_syl.setText(data.get(i));
        final String s = data.get(i);

        Button btn_study = (Button) view.findViewById(R.id.btn_wrong_study);
        btn_study.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(maincon, StudySyllableActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra("type", "syllable");
                intent.putExtra("category", "single");
                intent.putExtra("ca_txt", s);
                intent.putExtra("max", 1);
                intent.putExtra("now", 0);
                v.getContext().startActivity(intent);
            }
        });
        return view;
    }
}