package com.example.solugate.icanspeak;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by solugate on 2016-07-19.
 */
public class JoinActivity extends AppCompatActivity implements View.OnClickListener {

    private ListView listUserClass;         // 장애 등급 리스트 뷰
    private ArrayList<String> userClass;    // 장애 등급 array list
    private int n_class;                    // 사용자 장애 등급

    private boolean id_check;               //아이디 중복 검사 여부

    private Button btn_back, btn_check, btn_duplicate;  // 액션 바 버튼
    private ImageView actionbar_title;                  // 액션 바 타이틀
    private String title, u_id;

    private Button btn_upload_profile;                  // 사진 업로드 버튼
    private ImageButton btn_clear_id, btn_clear_pw, btn_clear_name;
    private EditText edit_id, edit_name, edit_pw;
    private TextView user_id;
    private ImageView iv_profile;                       // 사용자 이미지
    private String user_password, user_name, user_class, selected;

    private static final int SELECT_FILE = 1;
    private Boolean isJoin; // true: 회원가입, false: 회원정보수정 디비에정보 업데이트할 때 사용

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join);

        StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder().detectDiskReads().detectDiskWrites().detectNetwork().penaltyLog().build());

        Intent intent = getIntent();
        title = intent.getExtras().getString("ACTIONBAR_TITLE");

        if (title.equals("actionbar_modify_user_info"))
            isJoin = false; // 회원 정보 수정
        else
            isJoin = true;  // 회원 가입

        setCustomActionbar();   // 커스텀 액션 바 적용
        setListView();          // 리스트 뷰 설정

        id_check = false;   // 아이디 중복 검사 여부
        n_class = -1;       // 급수 default

        btn_duplicate = (Button) findViewById(R.id.btn_duplicate);
        btn_duplicate.setOnClickListener(this);

        btn_clear_id = (ImageButton) findViewById(R.id.clear_id);
        btn_clear_id.setOnClickListener(this);

        btn_clear_pw = (ImageButton) findViewById(R.id.clear_pw);
        btn_clear_pw.setOnClickListener(this);

        btn_clear_name = (ImageButton) findViewById(R.id.clear_name);
        btn_clear_name.setOnClickListener(this);

        edit_id = (EditText) findViewById(R.id.editText_id);
        edit_id.addTextChangedListener(textWatcher("id"));

        edit_pw = (EditText) findViewById(R.id.editText_pw);
        edit_pw.addTextChangedListener(textWatcher("pw"));

        edit_name = (EditText) findViewById(R.id.editText_name);
        edit_name.addTextChangedListener(textWatcher("name"));

        iv_profile = (ImageView) findViewById(R.id.image_profile);

        // 사용자 프로필 사진 업로드 버튼
        btn_upload_profile = (Button) findViewById(R.id.imageButton_profile);
        btn_upload_profile.setOnClickListener(this);

        // 회원 정보 수정인 경우
        if (!isJoin) {
            u_id = intent.getExtras().getString("USER_ID"); // 마이페이지에서 사용자 아이디 가져오기

            // 아이디 수정 막아놓기
            edit_id.setVisibility(View.INVISIBLE);
            btn_duplicate.setVisibility(View.INVISIBLE);
            user_id = (TextView) findViewById(R.id.textView_id);
            user_id.setText(u_id);
            user_id.setVisibility(View.VISIBLE);
            user_id.bringToFront();

            selectUserInfoFromDB();

            edit_pw.setText(user_password);
            edit_pw.setTransformationMethod(PasswordTransformationMethod.getInstance());
            edit_name.setText(user_name);
        }
    }

    private TextWatcher textWatcher(String str) {
        final String result = str;
        return new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                selected = result;
                if (selected.equals("id")) {
                    if (!edit_id.getText().toString().equals(""))  //if edittext include text
                        btn_clear_id.setVisibility(View.VISIBLE);
                    else  //not include text
                        btn_clear_id.setVisibility(View.GONE);
                } else if (selected.equals("pw")) {
                    if (!edit_pw.getText().toString().equals(""))  //if edittext include text
                        btn_clear_pw.setVisibility(View.VISIBLE);
                    else  //not include text
                        btn_clear_pw.setVisibility(View.GONE);
                } else if (selected.equals("name")) {
                    if (!edit_name.getText().toString().equals(""))  //if edittext include text
                        btn_clear_name.setVisibility(View.VISIBLE);
                    else  //not include text
                        btn_clear_name.setVisibility(View.GONE);
                }
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        };
    }

    // 장애 등급 리스트 뷰

    private void setListView() {
        // 데이터 원본
        userClass = new ArrayList<String>();
        userClass.add("-");
        userClass.add("2급");
        userClass.add("3급");
        userClass.add("4급");
        userClass.add("5급");
        userClass.add("6급");

        // 어댑터
        ArrayAdapter<String> Adapter;
        Adapter = new ArrayAdapter<String>(this, R.layout.list_item_user_class, userClass);

        // 어댑터 연결
        listUserClass = (ListView) findViewById(R.id.listView_class);
        listUserClass.setAdapter(Adapter);

        // 리스트 뷰 속성
        // 항목 선택하는 모드
        listUserClass.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        // 항목 사이의 구분선 지정
        listUserClass.setDivider(new ColorDrawable(Color.GRAY));
        // 구분선의 높이 지정
        listUserClass.setDividerHeight(1);

        listUserClass.setOnItemClickListener(new ListViewItemClickListener());

    }

    private class ListViewItemClickListener implements AdapterView.OnItemClickListener {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            n_class = position + 1;
        }
    }

    // 커스텀 액션 바
    private void setCustomActionbar() {
        ActionBar actionBar = getSupportActionBar();

        // Custom Action bar를 사용하기 위한 설정
        actionBar.setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        actionBar.setDisplayShowCustomEnabled(true);
        actionBar.setCustomView(R.layout.layout_actionbar);

        // Set Custom view layout
        View mCustomView = getSupportActionBar().getCustomView();

        // 액션바 뒤로가기 버튼
        btn_back = (Button) findViewById(R.id.btn_back);
        btn_back.setOnClickListener(this);

        // 액션바 타이틀 설정
        actionbar_title = (ImageView) findViewById(R.id.actionbar_title);
        String resName = "@drawable/" + title;             // resource 이름
        String resType = "drawable";                            // resource 타입
        int resID = getResources().getIdentifier(resName, resType, getPackageName());
        actionbar_title.setImageResource(resID); // 해당 resource file 로 타이틀 이미지 변경

        // 액션바 확인 버튼
        btn_check = (Button) findViewById(R.id.btn_check);
        btn_check.setOnClickListener(this);

        // set action bar layout layoutparams
        ActionBar.LayoutParams params = new ActionBar.LayoutParams(ActionBar.LayoutParams.MATCH_PARENT, ActionBar.LayoutParams.MATCH_PARENT);
        actionBar.setCustomView(mCustomView, params);

        Toolbar parent = (Toolbar) mCustomView.getParent();
        parent.setContentInsetsAbsolute(0, 0);
    }

    // 완료 버튼 눌렀을 시에 입력 완료 됐는지 확인
    private boolean inputCheck() {
        if (isJoin) {   // 회원가입인 경우 아이디 입력 확인
            // 회원 정보 수정인 경우 막아 놓기
            if (edit_id.getText().length() == 0) {
                Toast.makeText(JoinActivity.this, "아이디를 입력해주세요.", Toast.LENGTH_SHORT).show();
                return false;
            } else if (!id_check) {
                Toast.makeText(JoinActivity.this, "아이디 중복 검사를 해주세요.", Toast.LENGTH_SHORT).show();
                return false;
            }
        } else if (edit_pw.getText().length() == 0) {
            Toast.makeText(JoinActivity.this, "비밀번호를 입력해주세요.", Toast.LENGTH_SHORT).show();
            return false;
        } else if (edit_name.getText().length() == 0) {
            Toast.makeText(JoinActivity.this, "이름을 입력해주세요.", Toast.LENGTH_SHORT).show();
            return false;
        } else if (n_class == -1) {
            Toast.makeText(JoinActivity.this, "급수를 선택해주세요.", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    // 클릭 리스너
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_back:
                onBackPressed();
                break;

            case R.id.btn_check:
                if (inputCheck()) {
                    InsertUserInfoToDB();
                    onBackPressed();
                }
                break;

            case R.id.btn_duplicate:
                if (edit_id.getText().length() == 0) {
                    Toast.makeText(JoinActivity.this, "아이디를 입력하세요", Toast.LENGTH_LONG).show();
                } else {
                    if (CheckIdFromDB()) {
                        id_check = true;
                        Toast.makeText(JoinActivity.this, "사용 가능한 아이디입니다.", Toast.LENGTH_LONG).show();
                    } else {
                        id_check = false;
                        Toast.makeText(JoinActivity.this, "사용할 수 없는 아이디입니다.", Toast.LENGTH_LONG).show();
                    }
                }
                break;

            case R.id.imageButton_profile:
                selectImage();
                break;
            case R.id.clear_id:
                edit_id.setText("");
                break;
            case R.id.clear_pw:
                edit_pw.setText("");
                break;
            case R.id.clear_name:
                edit_name.setText("");
                break;
        }
    }

    private void selectImage() {
        // Set Dialog box items
        final CharSequence[] items = {"사진첩에서 불러오기", "취소"};
        AlertDialog.Builder builder = new AlertDialog.Builder(JoinActivity.this);
        builder.setTitle("프로필 이미지 업로드");

        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                if (items[item].equals("사진첩에서 불러오기"))
                    galleryIntent();
                else if (items[item].equals("취소"))
                    dialog.dismiss();
            }
        });
        builder.show();
    }

    // 갤러리에서 이미지 잘라서 가져오기
    private void galleryIntent() {
        Intent intent = new Intent();
        // 갤러리 호출
        intent.setType("image/*");  // media storage에서 image만 선택
        intent.setAction(Intent.ACTION_GET_CONTENT);
        // 잘라내기 세팅
        intent.putExtra("crop", "true");
        intent.putExtra("aspectX", 0);
        intent.putExtra("aspectY", 0);
        intent.putExtra("outputX", 80);
        intent.putExtra("outputY", 80);
        try {
            intent.putExtra("return-data", true);
            startActivityForResult(Intent.createChooser(intent,
                    "Select File"), SELECT_FILE);
        } catch (ActivityNotFoundException e) {

        }
    }

    // 다시 액티비티로 복귀했을 때 이미지 세팅
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        // When an Image is picked
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == SELECT_FILE) {
                Bundle extras = data.getExtras();
                if (extras != null) {
                    Bitmap photo = extras.getParcelable("data");
                    iv_profile.setImageBitmap(photo);
                }
            }
        } else {
            Toast.makeText(this, "You haven't picked Image", Toast.LENGTH_LONG).show();
        }
    }

    /******
     * db연동
     *******/

    // 마이페이지에 표시할 사용자 정보 가져오기
    private void selectUserInfoFromDB() {

        DBManager dbManager = new DBManager();

        dbManager.setAParameter("U_ID", u_id);

        dbManager.db_connect("http://211.210.32.57:9907/COSAMO/get_user_info.php");

        user_password = dbManager.getResult("U_PW");
        user_name = dbManager.getResult("U_NAME");
        user_class = dbManager.getResult("U_CLASS");
    }

    private void InsertUserInfoToDB() {
        DBManager dbManager = new DBManager();

        dbManager.setAParameter("U_ID", edit_id.getText().toString());
        dbManager.setAParameter("U_PW", edit_pw.getText().toString());
        dbManager.setAParameter("U_NAME", edit_name.getText().toString());
        dbManager.setAParameter("U_CLASS", Integer.toString(n_class));
        dbManager.setAParameter("U_IMG_PATH", "default");

        dbManager.db_connect("http://211.210.32.57:9907/COSAMO/join.php");
    }

    private boolean CheckIdFromDB() {
        DBManager dbManager = new DBManager();

        dbManager.setAParameter("U_ID", edit_id.getText().toString());
        dbManager.db_connect("http://211.210.32.57:9907/COSAMO/join_id_check.php");

        Log.i("result", dbManager.getResult());
        if (dbManager.getResult().equals("yes"))
            return true;
        else
            return false;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}