package com.example.solugate.icanspeak;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

/**
 * Created by solugate on 2016-08-09.
 */
public class StudyFinishActivity extends Activity implements View.OnClickListener {

    SharedPreferences studyPref;
    SharedPreferences.Editor studyEditor;

    private Button btn_study_again, btn_stop_study;
    private TextViewPlus txt_study_type, txt_study_finish, txt_average;
    private String study_type, study_category, study_average;
    private ImageView img_study;

    private GlobalVariable m_gVar = null;

    private int max;
    private int accuracy_sum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_study_finish);

        // 프리퍼런스 설정
        studyPref = getSharedPreferences("study", 0);
        studyEditor = studyPref.edit();

        Intent intent = getIntent();
        max = intent.getExtras().getInt("max");
        accuracy_sum = intent.getExtras().getInt("accuracy_sum");

        m_gVar = (GlobalVariable) getApplicationContext();
        study_type = m_gVar.getStudyType();
        study_category = m_gVar.getStudyCategory();

        btn_study_again = (Button) findViewById(R.id.btn_study_again);
        btn_study_again.setOnClickListener(this);

        btn_stop_study = (Button) findViewById(R.id.btn_stop_study);
        btn_stop_study.setOnClickListener(this);

        img_study = (ImageView) findViewById(R.id.image_study_result);
        String img_str = m_gVar.getImageFileName();
        int resId = getResources().getIdentifier("@drawable/" + img_str, "drawable", getPackageName());
        img_study.setImageResource(resId);    // 해당하는 이미지로 image button 변경

        txt_study_type = (TextViewPlus) findViewById(R.id.title_study_type);
        txt_study_type.setText(study_category);

        txt_study_finish = (TextViewPlus) findViewById(R.id.study_finish_message);
        txt_study_finish.setText(study_type + "학습 완료");

        txt_average = (TextViewPlus) findViewById(R.id.study_average);
        txt_average.setText("전체 정확도 : "+Integer.toString(accuracy_sum/max)+"%");
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_study_again:
                Intent intent1 = new Intent(this, StudyInitActivity.class);
                startActivity(intent1);
                finish();
                break;

            case R.id.btn_stop_study:
                Intent intent2 = new Intent(this, StudyMainActivity.class);
                intent2.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                studyEditor.clear();    // 학습 정보 삭제
                studyEditor.commit();
                startActivity(intent2);
                finish();
                break;
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}