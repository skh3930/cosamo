package com.example.solugate.icanspeak;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.akexorcist.roundcornerprogressbar.RoundCornerProgressBar;

/**
 * Created by Samsung on 2016-07-31.
 */

public class StudyActivity extends Activity implements View.OnClickListener {

    private Button btn_close;
    private ToggleButton btn_done;
    private TextView study_title;
    private RoundCornerProgressBar study_progress;
    private String type, category;
    private int accuracy_sum;
    private int accuracy_now;
    private int wa_no, ca_no;

    private int max;
    private int now;
    private String sl_no;

    //학습 정보 저장
    private String s_no;
    private String s_txt;
    private String s_std_pron;
    private String s_sound_path;
    private String u_no;
private String ca_txt;
    LoginActivity login;
    private SharedPreferences pref;
    private boolean isFinish;

    AudioRecording audio_recording;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_study);

        pref = getSharedPreferences(login.PREFS_NAME, 0);   // 프리퍼런스 설정
        u_no = pref.getString("userNo", "");                // pref 에서 사용자 정보 가져오기
        sl_no = "";                                         // 학습 고유 번호
        isFinish = false;

        Intent intent = getIntent();
        type = intent.getExtras().getString("type");
        category = intent.getExtras().getString("category");
        if(category.equals("single"))
            ca_txt = intent.getExtras().getString("ca_txt");
        accuracy_sum = intent.getExtras().getInt("accuracy_sum");
        now = intent.getExtras().getInt("now"); // 현재 학습 진행도
        max = intent.getExtras().getInt("max"); // 해당 카테고리의 총 학습 개수

        String s_category = getCategory(category);  // 해당 카테고리의 이름 (ex. 음식, 사람)

        //초기에만 한번 스터디 전체갯수 가져옴
        if (now == 0)
            SelectStudyMaxFromDB(s_category);

        SelectStudyInfoFromDB(now, s_category); // 해당 카테고리에서 현재 진행하고 있는 학습 정보 가져오기

        Log.i("TAG", "현재 학습 번호 : " + now);
        Log.i("TAG", "현재 학습 : " + s_txt);

        study_progress = (RoundCornerProgressBar) findViewById(R.id.study_progress);
        study_progress.setMax(max);
        study_progress.setProgress(now + 1);

        // 나가기 버튼 설정
        btn_close = (Button) findViewById(R.id.btn_close);
        btn_close.setOnClickListener(this);

        // 완료 버튼
        btn_done = (ToggleButton) findViewById(R.id.btn_done);
        btn_done.setOnClickListener(this);

        study_title = (TextView) findViewById(R.id.study_title);
        study_title.setText(Html.fromHtml(s_txt + "<br/> " + "<small>" + "[" + s_std_pron + "]" + "</small>"));
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_close:
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setMessage("학습을 중지하시겠습니까?");
                builder.setPositiveButton("네", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        onBackPressed();
                    }
                });
                builder.setNegativeButton("아니오", null);
                builder.show();
                break;
            case R.id.btn_done:
                if (btn_done.isChecked()) { // 시작

                    Toast.makeText(StudyActivity.this, "발음하신 후에 완료 버튼을 눌러주세요.", Toast.LENGTH_SHORT).show();
                    btn_done.setBackgroundDrawable(getResources().getDrawable(R.drawable.btn_done_disabled));

                    audio_recording = new AudioRecording();

                    // 음성 녹음 시작
                    audio_recording.setUpAudioRecording();
                    audio_recording.record();

                } else if(!btn_done.isChecked()) {
 //                   btn_close.setEnabled(false);
                    btn_done.setBackgroundDrawable(getResources().getDrawable(R.drawable.btn_done_enabled));

                    audio_recording.stopRecording();
                    audio_recording.waitBackground();

                    Intent intent2 = new Intent(StudyActivity.this, StudyResultActivity.class);
                    intent2.putExtra("type", type);
                    intent2.putExtra("category", category);
                    intent2.putExtra("s_no", s_no);
                    intent2.putExtra("s_std_pron", s_std_pron);
                    intent2.putExtra("s_sound_path", s_sound_path);
                    intent2.putExtra("max", max);
                    intent2.putExtra("accuracy_sum", accuracy_sum);
                    intent2.putExtra("STT_RESULT", audio_recording.stt_result);

                    wa_no = ca_no = accuracy_now = 0;   // 초기화
                    checkResultAndGetAccuracy(audio_recording.stt_result);

                    if (wa_no > 0 | ca_no > 0) {
                        if (wa_no > 0)
                            intent2.putExtra("result", "wrong");
                        else
                            intent2.putExtra("result", "correct");

                        intent2.putExtra("accuracy_now", accuracy_now);
                        intent2.putExtra("now", now);//++now
                        SetStudyLogFromDB("FINISH");
                        isFinish = true;

                        saveStudyResultToDB();

                        startActivity(intent2);
                    } else {
                            Toast.makeText(StudyActivity.this, "음성 인식에 실패하였습니다. 다시 실행해 주세요.", Toast.LENGTH_SHORT).show();
                    }
                }
                btn_done.setEnabled(true);
                break;
        }
    }

    private String getCategory(String s_para) {
        String s_cate = "";
        if (s_para.equals("init_word_1"))
            s_cate = "사람";
        else if (s_para.equals("init_word_2"))
            s_cate = "음식";
        else if (s_para.equals("init_word_3"))
            s_cate = "과일";
        else if (s_para.equals("init_word_4"))
            s_cate = "색깔";
        else if (s_para.equals("init_word_5"))
            s_cate = "직업";
        else if (s_para.equals("init_word_6"))
            s_cate = "요일";
        else if (s_para.equals("init_sentence_1"))
            s_cate = "인사말";
        else if (s_para.equals("init_sentence_2"))
            s_cate = "질문";
        else if (s_para.equals("init_sentence_3"))
            s_cate = "감정";
        else if (s_para.equals("init_sentence_4"))
            s_cate = "식당";
        else if (s_para.equals("init_sentence_5"))
            s_cate = "쇼핑";
        else if (s_para.equals("init_sentence_6"))
            s_cate = "교통";
        else if(s_para.equals("single"))
            s_cate = "single";
        return s_cate;
    }

    // 현재 학습 카테고리에 있는 학습들의 총 개수 가져오기
    private void SelectStudyMaxFromDB(String s_category) {

        DBManager dbManager = new DBManager();

        dbManager.setAParameter("CATEGORY", s_category);
        dbManager.db_connect("http://211.210.32.57:9907/COSAMO/get_study_num.php");

        max = Integer.parseInt(dbManager.getResult("STUDY_NUM"));
    }

    // 디비에 현재 학습 로그 설정
    private void SetStudyLogFromDB(String s_flag) {
        DBManager dbManager = new DBManager();

        dbManager.setAParameter("FLAG", s_flag);
        dbManager.setAParameter("U_NO", u_no);
        dbManager.setAParameter("S_NO", s_no);
        dbManager.setAParameter("S_NO", s_no);
        dbManager.setAParameter("SL_NO", sl_no);

        dbManager.db_connect("http://211.210.32.57:9907/COSAMO/set_study_log.php");

        if (s_flag.equals("START")) {
            sl_no = dbManager.getResult();
        }
    }

    private void saveStudyResultToDB() {
        DBManager dbManager = new DBManager();

        dbManager.setAParameter("STUDY_TYPE", type);
        dbManager.setAParameter("U_NO", u_no);
        dbManager.setAParameter("S_NO", s_no);
        dbManager.setAParameter("W_NO", Integer.toString(wa_no));
        dbManager.setAParameter("W_ACC", Integer.toString(accuracy_now));
        dbManager.setAParameter("R_SOUND_PATH", audio_recording.file_path);

        dbManager.db_connect("http://211.210.32.57:9907/COSAMO/save_study_result.php");
    }

    // 디비에서 해당 학습 정보 가져오기
    private void SelectStudyInfoFromDB(int n_count, String s_category) {
        DBManager dbManager = new DBManager();

        if(s_category.equals("single"))
            dbManager.setAParameter("CA_TXT", ca_txt);
        else
            dbManager.setAParameter("COUNT", Integer.toString(n_count));    // 학습 순서
        dbManager.setAParameter("CATEGORY", s_category);                // 현재 카테고리 정보

        dbManager.db_connect("http://211.210.32.57:9907/COSAMO/get_study_info.php");

        s_no = dbManager.getResult("CA_NO");
        s_txt = dbManager.getResult("CA_TXT");
        s_std_pron = dbManager.getResult("CA_STD_PRON");
        s_sound_path = dbManager.getResult("CA_SOUND_PATH");
    }

    // 디비에서 정확도 체크
    private void checkResultAndGetAccuracy(String result) {

        DBManager dbManager = new DBManager();

        dbManager.setAParameter("WA_TXT", result);
        dbManager.setAParameter("CA_NO", s_no);     // 학습 고유 번호

        dbManager.db_connect("http://211.210.32.57:9907/COSAMO/check_wrong_answer.php");
        String no = dbManager.getResult("WA_NO");
        String accuracy = dbManager.getResult("WA_ACCURACY");

        wa_no = Integer.parseInt(no);
        accuracy_now = Integer.parseInt(accuracy);

        // 오답 테이블에 결과가 존재하지 않으면
        if (wa_no < 0) {
            DBManager dbManager2 = new DBManager();

            dbManager2.setAParameter("CA_TXT", result);
            dbManager2.setAParameter("CA_NO", s_no);     // 학습 고유 번호

            dbManager2.db_connect("http://211.210.32.57:9907/COSAMO/check_correct_answer.php");

            ca_no = Integer.parseInt(dbManager2.getResult("CA_NO"));

            // 텍스트에 매치되는 correct answer가 존재하면
            if (ca_no > 0)
                accuracy_now = 100;  // 정확도 100으로 지정
        }
    }

    @Override
    protected void onPause() {
        if(audio_recording!=null)
            audio_recording.stopRecording();
        super.onPause();
        if (!isFinish) {
            SetStudyLogFromDB("PAUSE");
        }
    }

    @Override
    protected void onStop() {
        if(audio_recording!=null) {
            audio_recording.stopRecording();
            btn_done.setChecked(false);
            btn_done.setBackgroundDrawable(getResources().getDrawable(R.drawable.btn_done_enabled));
        }
        super.onStop();
    }
    @Override
    protected void onResume() {
        super.onResume();
        SetStudyLogFromDB("START");
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}