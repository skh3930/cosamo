package com.example.solugate.icanspeak;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.hardware.Camera;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Handler;
import android.os.Bundle;
import android.view.Display;
import android.view.SurfaceHolder;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import android.widget.VideoView;

import java.io.IOException;
import java.util.List;


public class StudySyllableActivity extends Activity implements SurfaceHolder.Callback, View.OnClickListener {

    private String default_path = "http://211.210.32.57:9099/icanspeak/video_file/";
    private VideoView video_std;
    private VideoView video_user;
    private TextView text_syl_text;
    private TextView text_syl_explanation;
    private Button btn_close;
    private ToggleButton btn_start_end;
    private Handler updateHandler = new Handler();

    LoginActivity login;
    private SharedPreferences pref;

    Camera camera = null;
    private VideoView mVideoView;
    SurfaceHolder holder;

    AudioRecording audio_recording;
    //학습 정보 저장
    private String s_no;
    private String s_txt;
    private String s_std_pron;
    private String s_sound_path;
    private String u_no,  sl_no, type, category, ca_txt, s_feedback;
    private int now, max;
    private boolean isFinish;

    private int accuracy_sum;
    private int accuracy_now;
    private int wa_no, ca_no;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_study_syllable);

        pref = getSharedPreferences(login.PREFS_NAME, 0);   // 프리퍼런스 설정
        u_no = pref.getString("userNo", "");                // pref 에서 사용자 정보 가져오기
        sl_no = "";                                         // 학습 고유 번호

        Intent intent = getIntent();
        type = intent.getExtras().getString("type");
        category = intent.getExtras().getString("category");
        if(category.equals("single"))
            ca_txt = intent.getExtras().getString("ca_txt");
        accuracy_sum = intent.getExtras().getInt("accuracy_sum");
        now = intent.getExtras().getInt("now"); // 현재 학습 진행도
        max = intent.getExtras().getInt("max"); // 해당 카테고리의 총 학습 개수

        //초기에만 한번 스터디 전체갯수 가져옴
        if (now == 0)
            SelectStudyMaxFromDB(category);

        SelectStudyInfoFromDB(now, category); // 해당 카테고리에서 현재 진행하고 있는 학습 정보 가져오기


        /*******나가기 버튼********/
        btn_close = (Button) findViewById(R.id.btn_close);
        btn_close.setOnClickListener(this);

        /*********모범 영상********/
        video_std = (VideoView) findViewById(R.id.video_std_view);
        loadVideo();

        /*********음절 설명*******/
        text_syl_text = (TextView) findViewById(R.id.text_syl_text);
        text_syl_explanation = (TextView) findViewById(R.id.text_syl_explanation);
        text_syl_text.setText(s_txt);
        text_syl_explanation.setText(s_feedback);

        /*********사용자 카메라 영상**********/
        mVideoView = (VideoView) findViewById(R.id.video_user_view);
        holder = mVideoView.getHolder();
        holder.addCallback(this);

        /**********학습 시작/종료 버튼*******/
        btn_start_end = (ToggleButton) findViewById(R.id.btn_start_end);
        btn_start_end.setOnClickListener(this);
    }

    /******
     * 비디오 관련 함수
     ************/
    public void loadVideo() {
        String video_file = getVideoFilePathFromDB();
        String url = video_file;
        video_std.setVideoURI(Uri.parse(url));
        video_std.requestFocus();
        video_std.start();

        // 토스트 다이얼로그를 이용하여 버퍼링중임을 알린다.
        video_std.setOnInfoListener(new MediaPlayer.OnInfoListener() {
            @Override
            public boolean onInfo(MediaPlayer mp, int what, int extra) {
                switch (what) {
                    case MediaPlayer.MEDIA_INFO_BUFFERING_START:
                        // Progress Diaglog 출력
                        //Toast.makeText(getApplicationContext(), "Buffering", Toast.LENGTH_LONG).show();
                        break;
                    case MediaPlayer.MEDIA_INFO_BUFFERING_END:
                        // Progress Dialog 삭제
                        //Toast.makeText(getApplicationContext(), "Buffering finished.\nResume playing", Toast.LENGTH_LONG).show();
                        video_std.start();
                        break;
                }
                return false;
            }
        });

        //비디오가 종료되면 다시 재생 (반복 재생)
        video_std.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                video_std.start();
            }
        });
    }

    /**************
     * 카메라 관련 함수
     *****************/

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
    // TODO Auto-generated method stub

        if (camera != null) {
            Camera.Parameters params = camera.getParameters();
        //    params.setPreviewSize(width, height);
            params.setPreviewSize(1920, 1080);
            params.setZoom(params.getMaxZoom()); // 현재 가장 멀리 있는 상태
            camera.setParameters(params);
            camera.startPreview();
        }
    }

    @SuppressLint("NewApi")
    @Override
    public void surfaceCreated(SurfaceHolder holder) {
    // TODO Auto-generated method stub

        int cameraId = 0;
        /* 카메라가 여러개 일 경우 그 수를 가져옴 */
        int numberOfCameras = Camera.getNumberOfCameras();
        Camera.CameraInfo cameraInfo = new Camera.CameraInfo();

        for (int i = 0; i < numberOfCameras; i++) {
            Camera.getCameraInfo(i, cameraInfo);

            if (cameraInfo.facing == Camera.CameraInfo.CAMERA_FACING_FRONT)
                cameraId = i;
        }
        /* open시 camera id를 주어 선택 */
        camera = Camera.open(cameraId);

        List<Camera.Size> previewSizes = camera.getParameters().getSupportedPreviewSizes();

        Camera.Parameters params = camera.getParameters();
        params.setPreviewSize(1920, 1080);
        params.setZoom(params.getMaxZoom()); // 현재 가장 멀리 있는 상태
        camera.setParameters(params);
        camera.startPreview();

        camera.setPreviewCallback(new Camera.PreviewCallback() {
            public void onPreviewFrame(byte[] data, Camera camera) {
            }
        });

        /* surface 사용시 카메라가 회전되어 있어 그에 대한 보정 */
        camera.setDisplayOrientation(90);
        try {
            camera.setPreviewDisplay(holder);
        } catch (IOException e) {
            e.printStackTrace();
            camera.release();
            camera = null;
        }
    }


    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        // TODO Auto-generated method stub
        holder.removeCallback(this);
        camera.stopPreview();
      //  camera.release();
    //   camera = null;
    }

    @Override
    protected void onDestroy() {
        // TODO Auto-generated method stub
        super.onDestroy();
      //  if(camera!=null) {
      //      camera.release();
      //      camera = null;
     //   }
    }
    @Override
    protected void onStop(){
        super.onStop();
      //  if(camera!=null){
     //       camera.release();
    //    }
    }
    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_close:
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setMessage("학습을 중지하시겠습니까?");
                builder.setPositiveButton("네", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        onBackPressed();
                    }
                });
                builder.setNegativeButton("아니오", null);
                builder.show();
                break;

            case R.id.btn_start_end:
                if (btn_start_end.isChecked()) { // 시작

                    Toast.makeText(StudySyllableActivity.this, "발음하신 후에 완료 버튼을 눌러주세요.", Toast.LENGTH_SHORT).show();
                    btn_start_end.setBackgroundDrawable(getResources().getDrawable(R.drawable.btn_done_disabled));

                    audio_recording = new AudioRecording();

                    // 음성 녹음 시작
                    audio_recording.setUpAudioRecording();
                    audio_recording.record();

                } else if(!btn_start_end.isChecked()) {
                    //                   btn_close.setEnabled(false);
                    btn_start_end.setBackgroundDrawable(getResources().getDrawable(R.drawable.btn_done_enabled));

                    audio_recording.stopRecording();
                    audio_recording.waitBackground();

                    Intent intent2 = new Intent(StudySyllableActivity.this, StudyResultActivity.class);
                    intent2.putExtra("type", type);
                    intent2.putExtra("category", category);
                    intent2.putExtra("s_no", s_no);
                    intent2.putExtra("s_std_pron", s_std_pron);
                    intent2.putExtra("s_sound_path", s_sound_path);
                    intent2.putExtra("max", max);
                    intent2.putExtra("accuracy_sum", accuracy_sum);
                    intent2.putExtra("STT_RESULT", audio_recording.stt_result);

                    wa_no = ca_no = accuracy_now = 0;   // 초기화
                    checkResultAndGetAccuracy(audio_recording.stt_result);

                    if (wa_no > 0 | ca_no > 0) {
                        if (wa_no > 0)
                            intent2.putExtra("result", "wrong");
                        else
                            intent2.putExtra("result", "correct");

                        intent2.putExtra("accuracy_now", accuracy_now);
                        intent2.putExtra("now", now);//++now
                        SetStudyLogFromDB("FINISH");
                        isFinish = true;

                        saveStudyResultToDB();

                        startActivity(intent2);
                    } else {
                        Toast.makeText(StudySyllableActivity.this, "음성 인식에 실패하였습니다. 다시 실행해 주세요.", Toast.LENGTH_SHORT).show();
                    }
                }
                btn_start_end.setEnabled(true);
                break;
        }
    }
    // 디비에 현재 학습 로그 설정
    private void SetStudyLogFromDB(String s_flag) {
        DBManager dbManager = new DBManager();

        dbManager.setAParameter("FLAG", s_flag);
        dbManager.setAParameter("U_NO", u_no);
        dbManager.setAParameter("S_NO", s_no);
        dbManager.setAParameter("S_NO", s_no);
        dbManager.setAParameter("SL_NO", sl_no);

        dbManager.db_connect("http://211.210.32.57:9907/COSAMO/set_study_log.php");

        if (s_flag.equals("START")) {
            sl_no = dbManager.getResult();
        }
    }

    private void saveStudyResultToDB() {
        DBManager dbManager = new DBManager();

        dbManager.setAParameter("STUDY_TYPE", type);
        dbManager.setAParameter("U_NO", u_no);
        dbManager.setAParameter("S_NO", s_no);
        dbManager.setAParameter("W_NO", Integer.toString(wa_no));
        dbManager.setAParameter("W_ACC", Integer.toString(accuracy_now));
        dbManager.setAParameter("R_SOUND_PATH", audio_recording.file_path);

        dbManager.db_connect("http://211.210.32.57:9907/COSAMO/save_study_result.php");
    }


    // 현재 학습 카테고리에 있는 학습들의 총 개수 가져오기
    private void SelectStudyMaxFromDB(String s_category) {

        DBManager dbManager = new DBManager();

        dbManager.setAParameter("CATEGORY", s_category);
        dbManager.db_connect("http://211.210.32.57:9907/COSAMO/get_study_num.php");

        max = Integer.parseInt(dbManager.getResult("STUDY_NUM"));
    }

    // 디비에서 해당 학습 정보 가져오기
    private void SelectStudyInfoFromDB(int n_count, String s_category) {
        DBManager dbManager = new DBManager();

        if(s_category.equals("single"))
            dbManager.setAParameter("CA_TXT", ca_txt);
        else
            dbManager.setAParameter("COUNT", Integer.toString(n_count));    // 학습 순서
        dbManager.setAParameter("CATEGORY", s_category);                // 현재 카테고리 정보

        dbManager.db_connect("http://211.210.32.57:9907/COSAMO/get_study_info.php");

        s_no = dbManager.getResult("CA_NO");
        s_txt = dbManager.getResult("CA_TXT");
        s_std_pron = dbManager.getResult("CA_STD_PRON");
        s_sound_path = dbManager.getResult("CA_SOUND_PATH");
        s_feedback = dbManager.getResult("CA_FB");
    }

    // 디비에서 정확도 체크
    private void checkResultAndGetAccuracy(String result) {

        DBManager dbManager = new DBManager();

        dbManager.setAParameter("WA_TXT", result);
        dbManager.setAParameter("CA_NO", s_no);     // 학습 고유 번호

        dbManager.db_connect("http://211.210.32.57:9907/COSAMO/check_wrong_answer.php");
        String no = dbManager.getResult("WA_NO");
        String accuracy = dbManager.getResult("WA_ACCURACY");

        wa_no = Integer.parseInt(no);
        accuracy_now = Integer.parseInt(accuracy);

        // 오답 테이블에 결과가 존재하지 않으면
        if (wa_no < 0) {
            DBManager dbManager2 = new DBManager();

            dbManager2.setAParameter("CA_TXT", result);
            dbManager2.setAParameter("CA_NO", s_no);     // 학습 고유 번호

            dbManager2.db_connect("http://211.210.32.57:9907/COSAMO/check_correct_answer.php");

            ca_no = Integer.parseInt(dbManager2.getResult("CA_NO"));

            // 텍스트에 매치되는 correct answer가 존재하면
            if (ca_no > 0)
                accuracy_now = 100;  // 정확도 100으로 지정
        }
    }
    private String getVideoFilePathFromDB() {
        DBManager dbManager = new DBManager();      // 학습 정보 테이블에서

        dbManager.setAParameter("CA_NO", s_no);   // 학습 고유 번호

        dbManager.db_connect("http://211.210.32.57:9907/COSAMO/get_video_path.php");

        String result = dbManager.getResult();
        return result;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}