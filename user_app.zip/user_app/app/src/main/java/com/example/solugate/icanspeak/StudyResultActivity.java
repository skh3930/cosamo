package com.example.solugate.icanspeak;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

public class StudyResultActivity extends Activity implements View.OnClickListener {

    //플레이, 즐겨찾기 버튼
    private ImageButton btn_play_sound;
    private ToggleButton btn_favorites;

    //음성 재생
    private final String default_path = "http://211.210.32.57:9099/icanspeak/std_voice_file/";

    //정확도
    private ProgressBar progress_accuracy;
    private TextView text_accuracy;
    private String accuracy;

    //인식 결과
    private TextView text_rec_result;
    private TextView text_std_result;

    //오답 음절
    ArrayList<String> syll_item;
    char result[], standard[];
    boolean match;  // 매치하는 음절이 있는지 체크

    //학습 정보 저장
    private String s_no;
    private String s_std_pron;
    private String s_sound_path;
    private String type, category;
    private int max;
    private int now;
    private int accuracy_sum;
    private int accuracy_now;
    private String stt_result, favorite_flag;

    private Button btn_again, btn_continue;
    LoginActivity login;
    private SharedPreferences pref;
    String userNum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_result_dialog);

        pref = getSharedPreferences(login.PREFS_NAME, 0);   // 프리퍼런스 설정
        userNum = pref.getString("userNo", "");             // 사용자 고유번호

        // 전 activity에서 값 가져옴
        Intent intent = getIntent();
        type = intent.getExtras().getString("type");
        category = intent.getExtras().getString("category");
        now = intent.getExtras().getInt("now");
        max = intent.getExtras().getInt("max");
        s_no = intent.getExtras().getString("s_no");
        s_std_pron = intent.getExtras().getString("s_std_pron");
        s_sound_path = intent.getExtras().getString("s_sound_path");
        accuracy_sum = intent.getExtras().getInt("accuracy_sum");
        accuracy_now = intent.getExtras().getInt("accuracy_now");
        stt_result = intent.getExtras().getString("STT_RESULT");

        // 모범 발음 음성 플레이 버튼
        btn_play_sound = (ImageButton) findViewById(R.id.btn_play_sound);
        btn_play_sound.setOnClickListener(this);

        // 즐겨찾기 버튼
        btn_favorites = (ToggleButton) findViewById(R.id.btn_favorites);
        if (isFavoriteAddedToDB()) {
            btn_favorites.setChecked(true);
            favorite_flag = "DELETE";
        }
        else {
            btn_favorites.setChecked(false);
            favorite_flag = "ADD";
        }
        btn_favorites.setText(null);
        btn_favorites.setTextOn(null);
        btn_favorites.setTextOff(null);
        btn_favorites.setBackgroundResource(R.drawable.btn_favorites_toggle);
        btn_favorites.setOnClickListener(this);

        // accuaracy 축적
        accuracy_sum += accuracy_now;

        //정확도 원형 바 설정
        progress_accuracy = (ProgressBar) findViewById(R.id.progress_accuracy);
        progress_accuracy.setRotation(-90);
        progress_accuracy.setProgress(accuracy_now);

        text_accuracy = (TextView) findViewById(R.id.text_accuracy);
        text_accuracy.setText(accuracy_now + "%");

        // 학습 결과 텍스트
        text_rec_result = (TextView) findViewById(R.id.text_rec_result);
        text_rec_result.setText(stt_result);

        // 모범 발음 텍스트
        text_std_result = (TextView) findViewById(R.id.text_std_result);
        text_std_result.setText(s_std_pron);

        // 오답 음절 리스트 추가
        syll_item = new ArrayList<String>();
        result = stt_result.toCharArray();
        standard = s_std_pron.toCharArray();

        for (int i = 0; i < standard.length; i++) {
            match = false;
            for (int j = 0; j < result.length; j++)
                if (standard[i] == result[j])
                    match = true;
            if (!match)
                syll_item.add(Character.toString(standard[i]));
        }

        //오답 음절 리스트 뷰 어뎁터 연결
        ResultListAdapter apapter = new ResultListAdapter(this, R.layout.layout_result_item, syll_item);
        ListView list_wor_syl = (ListView) findViewById(R.id.list_wor_syl);
        list_wor_syl.setAdapter(apapter);
        list_wor_syl.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (syll_item.get(position).length()!= 0) { //빈 리스트가 아닐때
                    Intent intent = new Intent(StudyResultActivity.this, StudyActivity.class);
                    intent.putExtra("type", "syllable");
                    intent.putExtra("category", "single");
                    intent.putExtra("ca_txt", syll_item.get(position));
                    startActivity(intent);
                    Toast.makeText(StudyResultActivity.this, syll_item.get(position), Toast.LENGTH_SHORT).show();
                }
            }
        });

        btn_again = (Button) findViewById(R.id.btn_again);
        btn_again.setOnClickListener(this);

        btn_continue = (Button) findViewById(R.id.btn_continue);
        btn_continue.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_play_sound:
                // 모범 발음 음성 재생
                try {
                    MediaPlayer player = new MediaPlayer();
                    player.setAudioStreamType(AudioManager.STREAM_MUSIC);
                    String url = getSoundFilePathFromDB();  // DB 에서 모범 발음 음성 파일 명을 가져온다.
                    player.setDataSource(default_path + url);
                    player.prepare();
                    player.start();

                    Toast.makeText(StudyResultActivity.this, "모범 발음을 재생 중입니다.", Toast.LENGTH_LONG).show();

                } catch (IOException e) {
                    e.printStackTrace();
                }
                break;
            case R.id.btn_favorites:
                if (isFavoriteAddedToDB())
                    favorite_flag = "DELETE";
                else
                    favorite_flag = "ADD";
                addFavoritesToDB(favorite_flag);
                break;
            case R.id.btn_again:
                onBackPressed();
                break;
            case R.id.btn_continue:
                if (++now == max) {
                    Intent intent = new Intent(this, StudyFinishActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    intent.putExtra("type", type);
                    intent.putExtra("category", category);
                    intent.putExtra("max", max);
                    intent.putExtra("accuracy_sum", accuracy_sum);
                    overridePendingTransition(0, 0);
                    startActivity(intent);
                    finish();
                }
                else {
                    Intent intent = new Intent(this, StudyActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    intent.putExtra("type", type);
                    intent.putExtra("category", category);
                    intent.putExtra("now", now);//now
                    intent.putExtra("max", max);
                    intent.putExtra("accuracy_sum", accuracy_sum);
                    overridePendingTransition(0, 0);
                    startActivity(intent);
                    finish();
                }
                break;
        }
    }

    // 즐겨찾기에 추가 및 삭제
    public void addFavoritesToDB(String flag) {
        DBManager dbManager = new DBManager();      // 학습 정보 테이블에서

        dbManager.setAParameter("U_NO", userNum);   // 사용자 고유번호
        dbManager.setAParameter("CA_NO", s_no);     // 학습 고유 번호
        dbManager.setAParameter("FLAG", flag);      // 즐겨찾기 추가/해제

        dbManager.db_connect("http://211.210.32.57:9907/COSAMO/set_favorites.php");
    }

    // 사용자가 즐겨찾기에 추가했는지 확인
    public boolean isFavoriteAddedToDB() {
        DBManager dbManager = new DBManager();      // 학습 정보 테이블에서

        dbManager.setAParameter("U_NO", userNum);   // 사용자 고유번호
        dbManager.setAParameter("CA_NO", s_no);     // 학습 고유 번호

        dbManager.db_connect("http://211.210.32.57:9907/COSAMO/check_favorites.php");

        String result = dbManager.getResult();
        if (result.equals("true"))
            return true;
        else
            return false;
    }

    public String getSoundFilePathFromDB() {
        DBManager dbManager = new DBManager();      // 학습 정보 테이블에서

        dbManager.setAParameter("CA_NO", s_no);   // 학습 고유 번호

        dbManager.db_connect("http://211.210.32.57:9907/COSAMO/get_sound_file_path.php");

        String result = dbManager.getResult();
        return result;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}