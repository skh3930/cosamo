package com.example.solugate.icanspeak;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

/**
 * Created by solugate on 2016-07-27.
 */
public class StatusMainActivity extends AppCompatActivity implements View.OnClickListener {

    // 어플리케이션 종료 handler
    private BackPressCloseHandler backPressCloseHandler;

    // 액션바
    private Button btn1, btn2;
    private ImageView actionBarTitle;

    // 탭
    private Button btn_tab1, btn_tab2, btn_tab3;

    private TextView text_user_name;

    //음절
    private TextView text_ave_syl, text_progress_syl;
    private ImageButton btn_fav_syl;
    private ImageButton btn_wea_syl;
    private ProgressBar progressbar_syl;

    //단어
    private TextView text_ave_wor, text_progress_wor;
    private ImageButton btn_fav_wor;
    private ImageButton btn_wea_wor;
    private ProgressBar progressbar_wor;

    //문장
    private TextView text_ave_sen, text_progress_sen;
    private ImageButton btn_fav_sen;
    private ImageButton btn_wea_sen;
    private ProgressBar progressbar_sen;

    //임시 저장
    private int s_syl_acc, s_wor_acc, s_sen_acc;

    private int n_syl_max;
    private int n_syl_study_num;
    private int n_wor_max;
    private int n_wor_study_num;
    private int n_sen_max;
    private int n_sen_study_num;

    LoginActivity login;
    private String u_id;
    private String u_no;
    private String u_name;
    SharedPreferences pref;

    MyPageMainActivity app_finish;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_status_main);

        pref = getSharedPreferences(login.PREFS_NAME, 0);

        // pref 에서 사용자 정보 가져오기
        u_id = pref.getString("userID", "");
        u_no = pref.getString("userNo", "");
        u_name = pref.getString("userName", "");

        // 두번 클릭 시 어플리케이션 종료
        backPressCloseHandler = new BackPressCloseHandler(this);

        app_finish = new MyPageMainActivity();

        setCustomActionbar();   // 커스텀 액션 바 적용
        setCustomTab();     // 커스텀 탭 적용

        selectUserInfoFromDB();
        selectUserStudyInfoFromDB();

        text_user_name = (TextView) findViewById(R.id.text_user_name);
        text_user_name.setText(u_name+"님의 연습 현황");

        //음절
        text_ave_syl = (TextView) findViewById(R.id.syllable_average);
        text_ave_syl.setOnClickListener(this);
        text_ave_syl.setText(s_syl_acc+"%");
        btn_fav_syl = (ImageButton) findViewById(R.id.syllable_favorites);
        btn_fav_syl.setOnClickListener(this);
        btn_wea_syl = (ImageButton) findViewById(R.id.syllable_weak_studies);
        btn_wea_syl.setOnClickListener(this);
        progressbar_syl = (ProgressBar)findViewById(R.id.progressBar_syllable);
        progressbar_syl.setMax(n_syl_max);
        progressbar_syl.setProgress(n_syl_study_num);
        text_progress_syl = (TextView) findViewById(R.id.progress_syllable);
        text_progress_syl.setText(Integer.toString(n_syl_study_num)+"/"+Integer.toString(n_syl_max));

        //단어
        text_ave_wor = (TextView) findViewById(R.id.word_average);
        text_ave_wor.setOnClickListener(this);
        text_ave_wor.setText(s_wor_acc+"%");
        btn_fav_wor = (ImageButton) findViewById(R.id.word_favorites);
        btn_fav_wor.setOnClickListener(this);
        btn_wea_wor = (ImageButton) findViewById(R.id.word_weak_studies);
        btn_wea_wor.setOnClickListener(this);
        progressbar_wor = (ProgressBar)findViewById(R.id.progressBar_word);
        progressbar_wor.setMax(n_wor_max);
        progressbar_wor.setProgress(n_wor_study_num);
        text_progress_wor = (TextView) findViewById(R.id.progress_word);
        text_progress_wor.setText(Integer.toString(n_wor_study_num)+"/"+Integer.toString(n_wor_max));

        //문장
        text_ave_sen = (TextView) findViewById(R.id.sentence_average);
        text_ave_sen.setOnClickListener(this);
        text_ave_sen.setText(s_sen_acc+"%");
        btn_fav_sen = (ImageButton) findViewById(R.id.sentence_favorites);
        btn_fav_sen.setOnClickListener(this);
        btn_wea_sen = (ImageButton) findViewById(R.id.sentence_weak_studies);
        btn_wea_sen.setOnClickListener(this);
        progressbar_sen = (ProgressBar)findViewById(R.id.progressBar_sentencess);
        progressbar_sen.setMax(n_sen_max);
        progressbar_sen.setProgress(n_sen_study_num);
        text_progress_sen = (TextView) findViewById(R.id.progress_sentence);
        text_progress_sen.setText(Integer.toString(n_sen_study_num)+"/"+Integer.toString(n_sen_max));
    }

    // 커스텀 액션 바
    private void setCustomActionbar() {
        ActionBar actionBar = getSupportActionBar();

        // Custom Action bar를 사용하기 위한 설정
        actionBar.setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        actionBar.setDisplayShowCustomEnabled(true);
        actionBar.setCustomView(R.layout.layout_actionbar);

        // Set Custom view layout
        View mCustomView = getSupportActionBar().getCustomView();

        // 액션바 뒤로가기 버튼 비활성화
        btn1 = (Button) findViewById(R.id.btn_back);
        btn1.setVisibility(View.INVISIBLE);

        // 액션바 타이틀
        actionBarTitle = (ImageView) findViewById(R.id.actionbar_title);
        actionBarTitle.setImageResource(R.drawable.app_title);

        // 액션바 음성테스트 버튼
        btn2 = (Button) findViewById(R.id.btn_check);
        btn2.setVisibility(View.INVISIBLE);

        // set action bar layout layoutparams
        ActionBar.LayoutParams params = new ActionBar.LayoutParams(
                ActionBar.LayoutParams.MATCH_PARENT, ActionBar.LayoutParams.MATCH_PARENT);
        actionBar.setCustomView(mCustomView, params);

        Toolbar parent = (Toolbar) mCustomView.getParent();
        parent.setContentInsetsAbsolute(0, 0);
    }

    private void setCustomTab() {
        btn_tab1 = (Button) findViewById(R.id.tab_01);
        btn_tab1.setOnClickListener(this);

        btn_tab2 = (Button) findViewById(R.id.tab_02);
        btn_tab2.setOnClickListener(this);

        btn_tab3 = (Button) findViewById(R.id.tab_03);
        btn_tab3.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tab_01:
                Intent intent1 = new Intent(this, StudyMainActivity.class);
                startActivity(intent1);
                finish();
                break;
            case R.id.tab_02:
                Intent intent2 = new Intent(this, StatusMainActivity.class);
                startActivity(intent2);
                finish();
                break;
            case R.id.tab_03:
                Intent intent3 = new Intent(this, MyPageMainActivity.class);
                startActivity(intent3);
                finish();
                break;
            case R.id.syllable_average:
                Intent intent4 = new Intent(this, StatusListActivity.class);
                intent4.putExtra("para", "syllable_average");
                overridePendingTransition(0, 0);
                startActivity(intent4);
                break;
            case R.id.syllable_favorites:
                Intent intent5 = new Intent(this, StatusListActivity.class);
                intent5.putExtra("para", "syllable_favorites");
                overridePendingTransition(0, 0);
                startActivity(intent5);
                break;
            case R.id.syllable_weak_studies:
                Intent intent6 = new Intent(this, StatusListActivity.class);
                intent6.putExtra("para", "syllable_weak_studies");
                overridePendingTransition(0, 0);
                startActivity(intent6);
                break;
            case R.id.word_average:
                Intent intent7 = new Intent(this, StatusListActivity.class);
                intent7.putExtra("para", "word_average");
                overridePendingTransition(0, 0);
                startActivity(intent7);
                break;
            case R.id.word_favorites:
                Intent intent8 = new Intent(this, StatusListActivity.class);
                intent8.putExtra("para", "word_favorites");
                overridePendingTransition(0, 0);
                startActivity(intent8);
                break;
            case R.id.word_weak_studies:
                Intent intent9 = new Intent(this, StatusListActivity.class);
                intent9.putExtra("para", "word_weak_studies");
                overridePendingTransition(0, 0);
                startActivity(intent9);
                break;
            case R.id.sentence_average:
                Intent intent10 = new Intent(this, StatusListActivity.class);
                intent10.putExtra("para", "sentence_average");
                overridePendingTransition(0, 0);
                startActivity(intent10);
                break;
            case R.id.sentence_favorites:
                Intent intent11 = new Intent(this, StatusListActivity.class);
                intent11.putExtra("para", "sentence_favorites");
                overridePendingTransition(0, 0);
                startActivity(intent11);
                break;
            case R.id.sentence_weak_studies:
                Intent intent12 = new Intent(this, StatusListActivity.class);
                intent12.putExtra("para", "sentence_weak_studies");
                overridePendingTransition(0, 0);
                startActivity(intent12);
                break;
        }
    }

    //유저의 음절, 단어, 문장 누적 평균 정확도 가져옴.
    public void selectUserInfoFromDB(){
        DBManager dbManager = new DBManager();

        dbManager.setAParameter("U_ID", u_id);

        dbManager.db_connect("http://211.210.32.57:9907/COSAMO/get_user_info.php");

        s_syl_acc = Integer.parseInt(dbManager.getResult("SYL_ACC")) / Integer.parseInt(dbManager.getResult("SYL_CNT"));
        s_wor_acc = Integer.parseInt(dbManager.getResult("WOR_ACC")) / Integer.parseInt(dbManager.getResult("WOR_CNT"));
        s_sen_acc = Integer.parseInt(dbManager.getResult("SEN_ACC")) / Integer.parseInt(dbManager.getResult("SEN_CNT"));
    }

    //유저의 음절,단어, 문장의 학습 갯수를 가져옴
    public void selectUserStudyInfoFromDB(){
        DBManager dbManager = new DBManager();

        dbManager.setAParameter("U_NO", u_no);

        dbManager.db_connect("http://211.210.32.57:9907/COSAMO/get_study_status.php");

        n_syl_study_num = Integer.valueOf(dbManager.getResult("SYL_STUDY_NUM"));
        n_syl_max = Integer.valueOf(dbManager.getResult("SYL_TOTAL_NUM"));
        n_wor_study_num = Integer.valueOf(dbManager.getResult("WOR_STUDY_NUM"));
        n_wor_max = Integer.valueOf(dbManager.getResult("WOR_TOTAL_NUM"));
        n_sen_study_num = Integer.valueOf(dbManager.getResult("SEN_STUDY_NUM"));
        n_sen_max = Integer.valueOf(dbManager.getResult("SEN_TOTAL_NUM"));
    }

    @Override
    public void onBackPressed() {
        app_finish.updateUserLogToDB(app_finish.FINISH);
        backPressCloseHandler.onBackPressed();
    }
}