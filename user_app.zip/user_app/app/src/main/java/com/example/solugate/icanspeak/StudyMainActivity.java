package com.example.solugate.icanspeak;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by solugate on 2016-07-22.
 */

public class StudyMainActivity extends AppCompatActivity implements View.OnClickListener {

    SharedPreferences studyPref;
    SharedPreferences.Editor studyEditor;

    private GlobalVariable m_gVar = null;

    // 어플리케이션 종료 handler
    private BackPressCloseHandler backPressCloseHandler;

    // 액션바
    private Button btn_goBack, btn_soundTest;
    private ImageView actionBarTitle;

    // 탭
    private Button btn_tab1, btn_tab2, btn_tab3;

    // 학습 버튼
    private ImageButton btn_syllable_01;

    // 여러개의 버튼을 배열로 처리하기 위해 버튼에 대해 배열 선언을 함
    private ImageButton[] btn_study;
    // 각각 다르게 출력할 스트링을 넣어둘 리스트
    private ArrayList<String> mDataImageList;

    private String[] mWordList, mSentenceList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_study_main);

        // 프리퍼런스 설정
        studyPref = getSharedPreferences("study", 0);
        studyEditor = studyPref.edit();

        // 두번 클릭 시 어플리케이션 종료
        backPressCloseHandler = new BackPressCloseHandler(this);

        m_gVar = (GlobalVariable) getApplicationContext();  // 전역 변수 사용하기 위해
        Resources res = getResources();                     // resources 에 접근하기 위해
        mWordList = res.getStringArray(R.array.word_array); // word string array 가져오기 (단어 세부 카테고리 명 저장)
        mSentenceList = res.getStringArray(R.array.sentence_array); // sentence string array 가져오기 (문장 세부 카테고리 명 저장)

        setCustomActionbar();   // 커스텀 액션 바 적용
        setCustomTab();     // 커스텀 탭 적용
        setStudyButton();
    }

    // 커스텀 액션 바
    private void setCustomActionbar() {
        ActionBar actionBar = getSupportActionBar();

        // Custom Action bar를 사용하기 위한 설정
        actionBar.setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        actionBar.setDisplayShowCustomEnabled(true);
        actionBar.setCustomView(R.layout.layout_actionbar);

        // Set Custom view layout
        View mCustomView = getSupportActionBar().getCustomView();

        // 액션바 뒤로가기 버튼 비활성화
        btn_goBack = (Button) findViewById(R.id.btn_back);
        btn_goBack.setVisibility(View.INVISIBLE);

        // 액션바 타이틀
        actionBarTitle = (ImageView) findViewById(R.id.actionbar_title);
        actionBarTitle.setImageResource(R.drawable.app_title);

        // 액션바 음성테스트 버튼
        btn_soundTest = (Button) findViewById(R.id.btn_check);
        btn_soundTest.setBackgroundResource(R.drawable.btn_sound_test);
        btn_soundTest.setOnClickListener(this);

        // set action bar layout layoutparams
        ActionBar.LayoutParams params = new ActionBar.LayoutParams(ActionBar.LayoutParams.MATCH_PARENT, ActionBar.LayoutParams.MATCH_PARENT);
        actionBar.setCustomView(mCustomView, params);

        Toolbar parent = (Toolbar) mCustomView.getParent();
        parent.setContentInsetsAbsolute(0, 0);

    }

    // 하단 탭 설정
    private void setCustomTab() {
        btn_tab1 = (Button) findViewById(R.id.tab_01);
        btn_tab1.setOnClickListener(this);

        btn_tab2 = (Button) findViewById(R.id.tab_02);
        btn_tab2.setOnClickListener(this);

        btn_tab3 = (Button) findViewById(R.id.tab_03);
        btn_tab3.setOnClickListener(this);
    }

    // 학습 버튼 설정
    private void setStudyButton() {
        // 학습 이미지 버튼 배열
        btn_study = new ImageButton[17];
        // 각 버튼의 타이틀 이미지 파일명을 저장할 배열
        mDataImageList = new ArrayList<String>();

        btn_study[1] = (ImageButton) findViewById(R.id.syllable_01);
        btn_study[2] = (ImageButton) findViewById(R.id.syllable_02);
        btn_study[3] = (ImageButton) findViewById(R.id.syllable_03);
        btn_study[4] = (ImageButton) findViewById(R.id.syllable_04);
        btn_study[5] = (ImageButton) findViewById(R.id.word_01);
        btn_study[6] = (ImageButton) findViewById(R.id.word_02);
        btn_study[7] = (ImageButton) findViewById(R.id.word_03);
        btn_study[8] = (ImageButton) findViewById(R.id.word_04);
        btn_study[9] = (ImageButton) findViewById(R.id.word_05);
        btn_study[10] = (ImageButton) findViewById(R.id.word_06);
        btn_study[11] = (ImageButton) findViewById(R.id.sentence_01);
        btn_study[12] = (ImageButton) findViewById(R.id.sentence_02);
        btn_study[13] = (ImageButton) findViewById(R.id.sentence_03);
        btn_study[14] = (ImageButton) findViewById(R.id.sentence_04);
        btn_study[15] = (ImageButton) findViewById(R.id.sentence_05);
        btn_study[16] = (ImageButton) findViewById(R.id.sentence_06);

        // 버튼들에 대한 클릭리스너 설정 및 데이터 설정
        for (int i = 1; i < 17; i++) {
            // 버튼의 포지션(배열에서의 index)를 태그로 저장
            btn_study[i].setTag(i);
            // 클릭 리스너 등록
            btn_study[i].setOnClickListener(this);
            // 타이틀 이미지 파일명
            mDataImageList.add("title" + i);
        }
    }

    // 버튼 클릭 리스너
    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.btn_check:
                Intent intent = new Intent(this, SoundTestActivity.class);
                startActivity(intent);
                break;

            case R.id.tab_01:
                Intent intent1 = new Intent(this, StudyMainActivity.class);
                startActivity(intent1);
                finish();
                break;

            case R.id.tab_02:
                Intent intent2 = new Intent(this, StatusMainActivity.class);
                startActivity(intent2);
                finish();
                break;

            case R.id.tab_03:
                Intent intent3 = new Intent(this, MyPageMainActivity.class);
                startActivity(intent3);
                finish();
                break;

            // 학습 버튼일 경우
            default:
                // 클릭된 뷰를 버튼으로 받아옴.
                ImageButton newButton = (ImageButton) v;

                for (ImageButton tempButton : btn_study) {
                    if (tempButton == newButton) {
                        int position = (Integer) v.getTag();    // 해당 버튼의 태그를 가져온다

                        Intent intent4 = new Intent(this, StudyInitActivity.class);
                        // 해당 버튼의 타이틀 이미지 파일명을 pugExtra 에 추가
                        studyEditor.putString("IMAGE_FILE_NAME", mDataImageList.get(position - 1));

                        // 학습의 타입을 putExtra 로 지정
                        if (position >= 1 && position <= 4) {
                            m_gVar.setStudyType("음절");  // 학습 종료 화면: 학습 종류 - 음절
                            studyEditor.putString("STUDY_TYPE", "syllable");
                            if (position == 1) {
                                studyEditor.putInt("NUMBER_OF_SUB_CATEGORY", 3);
                                m_gVar.setImageFileName("finish_syllable_1");
                            } else if (position == 2) {
                                studyEditor.putInt("NUMBER_OF_SUB_CATEGORY", 5);
                                m_gVar.setImageFileName("finish_syllable_2");
                            } else if (position == 3) {
                                studyEditor.putInt("NUMBER_OF_SUB_CATEGORY", 2);
                                m_gVar.setImageFileName("finish_syllable_3");
                            } else {
                                studyEditor.putInt("NUMBER_OF_SUB_CATEGORY", 1);
                                m_gVar.setImageFileName("finish_syllable_4");
                            }
                        } else if (position >= 5 && position <= 10) {
                            m_gVar.setStudyType("단어");  // 학습 종료 화면: 학습 종류 - 단어
                            String studyCategory = mWordList[position - 5];   // 학습 종료 화면: 단어 - 세부 학습 카테고리
                            m_gVar.setStudyCategory(studyCategory);         // 학습 종료 화면: 단어 - 세부 학습 카테고리
                            m_gVar.setImageFileName("finish_word_" + (position - 4));  // 학습 종료 화면: 단어 - 이미지 파일 명
                            studyEditor.putString("STUDY_TYPE", "word");
                            studyEditor.putInt("NUMBER_OF_SUB_CATEGORY", 1);
                            studyEditor.putString("STUDY_INIT_IMAGE_FILE", "init_word_" + (position - 4));
                        } else {
                            m_gVar.setStudyType("문장");  // 학습 종료 화면: 학습 종류 - 문장
                            String studyCategory = mSentenceList[position - 11];  // 학습 종료 화면: 문장 - 세부 학습 카테고리
                            m_gVar.setStudyCategory(studyCategory);             // 학습 종료 화면: 문장 - 세부 학습 카테고리
                            m_gVar.setImageFileName("finish_sentence_" + (position - 10));  // 학습 종료 화면: 문장 - 이미지 파일 명
                            studyEditor.putString("STUDY_TYPE", "sentence");
                            studyEditor.putInt("NUMBER_OF_SUB_CATEGORY", 1);
                            studyEditor.putString("STUDY_INIT_IMAGE_FILE", "init_sentence_" + (position - 10));
                        }
                        if(position<=12) {
                            studyEditor.commit();
                            startActivity(intent4);
                        } else {
                            Toast.makeText(StudyMainActivity.this, "선행학습을 완료해주세요.", Toast.LENGTH_SHORT).show();
                        }
                        break;
                    }
                }
        }
    }

    // 뒤로가기 두번 클릭 시 종료
    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        backPressCloseHandler.onBackPressed();
    }
}