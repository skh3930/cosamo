package com.example.solugate.icanspeak;

import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.AsyncTask;
import android.os.Environment;
import android.util.Log;

import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.concurrent.ExecutionException;

/**
 * Created by solugate on 2016-07-21.
 */

public class AudioRecording {

    RecordAudio recordTask;
    File recordingFile;
    boolean isRecording = false;

    static int frequency = 8000, channelConfiguration = AudioFormat.CHANNEL_IN_MONO;
    static int audioEncoding = AudioFormat.ENCODING_PCM_16BIT;
    // the minimum buffer size needed for audio recording
    static int bufferSize = AudioRecord.getMinBufferSize(
            frequency, channelConfiguration, audioEncoding);

    InetAddress serverAddress;
    private String SERVER = "211.210.32.57"; // 서버 IP
    private String udpPortNumber;
    int portNum;

    public TCPSocket tcp;
    public DatagramSocket udp;

    public AudioRecord audioRecord;
    public DataOutputStream dos;

    public String stt_result, file_path;

    public void setUpAudioRecording() {

        //TCP 소켓 통신
        tcp = new TCPSocket();
        tcp.start();

        File path = new File(
                Environment.getExternalStorageDirectory().getAbsolutePath()
                        + "/Android/data/com.apress.proandroidmedia.ch07.altaudiorecorder/files/");
        path.mkdirs();

        try {
            recordingFile = File.createTempFile("recording", ".pcm", path);
        } catch (IOException e) {
            throw new RuntimeException("Couldn't create file on SD card", e);
        }
    }

    // 녹음 버튼 클릭 시
    public void record() {
        recordTask = new RecordAudio();
        recordTask.execute();
    }

    // 녹음 중지 버튼 클릭 시
    public void stopRecording() {

        isRecording = false;
    }

    // 소켓 통신이 완료될 때까지 기다리기
    public void waitBackground() {
        try {
            recordTask.get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
    }

    // 음성 녹음 시작
    private class RecordAudio extends AsyncTask<Void, Integer, Void> {
        @Override
        protected Void doInBackground(Void... params) {
            isRecording = true;

            audioRecord = new AudioRecord(
                    MediaRecorder.AudioSource.MIC, frequency,
                    channelConfiguration, audioEncoding, bufferSize);

            int bytes_read = 0;
            udp = null;

            // UDP 통신에 사용될 버퍼 선언
            byte[] buf;

            try {
                Log.d("ERROR1", "1");
                dos = new DataOutputStream(
                        new BufferedOutputStream(new FileOutputStream(
                                recordingFile)));
                Log.d("ERROR1", "2");

                short[] buffer = new short[bufferSize]; // 사용자의 음성은 short형 버퍼에 저장
                Log.d("ERROR1", "3");

                // 음성 전송할 UDP 소켓 생성
                udp = new DatagramSocket();
                // 음성 녹음 시작
                Log.d("ERROR1", "4");

                audioRecord.startRecording();
                Log.d("ERROR1", "5");

                int cnt = 0;
                int end_cnt = 0;
                Log.d("ERROR1", "6");

                while (true) {
                    Log.d("ERROR1", "7");

                    cnt++;
                    Log.d("ERROR1", "8");

                    bytes_read = audioRecord.read(buffer, 0, bufferSize);
                    Log.d("ERROR1", "9");

                    for (int i = 0; i < bytes_read; i++)
                        dos.writeShort(buffer[i]);
                    Log.d("ERROR1", "10");

                    // buffer: short형 배열, buf: byte형 배열
                    buf = ShortToByte_ByteBuffer_Method(buffer);    // short형 배열을 byte형 배열로 변경
                    Log.d("ERROR1", "11");

                    serverAddress = InetAddress.getByName(SERVER);
                    Log.d("ERROR1", "12");

                    // udp 주소 받아오기
                    udpPortNumber = tcp.queue.get(0);
                    Log.d("ERROR1", "13");

                    portNum = Integer.parseInt(udpPortNumber);
                    Log.d("ERROR1", "14");

                    Log.i("TAG", "udp: " + portNum);
                    Log.i("BUF", cnt + "  " + byteArrayToHex(buf));
                    Log.d("ERROR1", "15");

                    // 패킷 생성
                    DatagramPacket packet = new DatagramPacket(buf, buf.length, serverAddress, portNum);
                    Log.d("ERROR1", "16");

                    udp.send(packet);
                    Log.d("ERROR1", "17");

                    Log.i("PacketLength", "length:" + bytes_read);

                    if (!isRecording){
                        Log.d("ERROR1", "18");
                        if (end_cnt++ > 10) {
                            Log.d("ERROR1", "19");
                            break;
                        }
                    }
                }
                Log.d("ERROR1", "20");

                // 음성 완료 패킷 전송
                ByteBuffer end_buf = ByteBuffer.allocate(100);
                Log.d("ERROR1", "21");

                end_buf.putInt(-1);
                Log.d("ERROR1", "22");

                byte[] end;
                Log.d("ERROR1", "23");

                end = end_buf.array();
                Log.d("ERROR1", "24");

                DatagramPacket end_packet = new DatagramPacket(end, end.length, serverAddress, portNum);
                Log.d("ERROR1", "25");

                udp.send(end_packet);
                Log.d("ERROR1", "26");

                audioRecord.stop();
                Log.d("ERROR1", "27");

                audioRecord.release();
                Log.d("ERROR1", "28");

                dos.close();
                Log.d("ERROR1", "29");

                tcp.checkUpdate.join();
                Log.d("ERROR1", "30");

                file_path = tcp.queue.get(1);
                Log.d("ERROR1", "31");

                Log.i("TAG", "file_path: " + file_path);

                stt_result = "default";
                stt_result = tcp.queue.get(2);
                stt_result = stt_result.trim();
                Log.i("TAG", "stt_result: " + stt_result);
                Log.d("ERROR1", "32");

                // UDP 소켓 통신 종료
                disconnectSocket();
                Log.d("ERROR1", "33");

                tcp.closeSocket();//////10/29
                Log.d("ERROR1", "34");

            } catch (Throwable t) {
                Log.e("AudioRecord", "Recording Failed");
                udp.disconnect();
                udp.close();
            }

            return null;
        }
    }

    public void disconnectSocket() {
        udp.disconnect();
        udp.close();
    }

    // byte[] to hex
    private String byteArrayToHex(byte[] ba) {
        if (ba == null || ba.length == 0) {
            return null;
        }
        StringBuffer sb = new StringBuffer(ba.length * 2);
        String hexNumber;
        for (int x = 0; x < ba.length; x++) {
            hexNumber = "0" + Integer.toHexString(0xff & ba[x]);
            sb.append(hexNumber.substring(hexNumber.length() - 2));
        }
        return sb.toString();
    }

    // short 형 버퍼를 byte 형 버퍼로 변환
    byte[] ShortToByte_ByteBuffer_Method(short[] input) {
        int index;
        int iterations = input.length;

        ByteBuffer bb = ByteBuffer.allocate(input.length * 2);

        bb.order(ByteOrder.LITTLE_ENDIAN);

        for (index = 0; index != iterations; ++index) {
            bb.putShort(input[index]);
        }
        return bb.array();
    }
}