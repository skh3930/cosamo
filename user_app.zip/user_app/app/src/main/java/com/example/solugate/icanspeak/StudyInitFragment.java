package com.example.solugate.icanspeak;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

/**
 * Created by Samsung on 2016-07-31.
 */
public class StudyInitFragment extends Fragment {
    String resName, resType, packageName;
    int resId;

    private GlobalVariable m_gVar = null;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_study_init, container, false);

        // study init activity에서 받아온 이미지 파일 명 drawable에서 이미지 찾아 변경
        ImageButton btn_img = (ImageButton) v.findViewById(R.id.imageSubCategory);
        resName = "@drawable/" + getArguments().getString("image");    // resource 이름
        resType = "drawable";                                        // resource 타입
        packageName = "com.example.solugate.icanspeak";              // package 이름
        resId = getResources().getIdentifier(resName, resType, packageName);
        btn_img.setImageResource(resId);    // 해당하는 이미지로 image button 변경

        // study init activity 에서 받아온 학습 종류가 음절인 경우
        // 음절의 세부 카테고리인 모음연습에서도 개수가 여러 개이므로 각 학습들을 구분해주기 위한 text 변경해준다.
        if (getArguments().getString("type").equals("syllable")) {
            TextView text_title = (TextView) v.findViewById(R.id.textSubCategory);
            resName = getArguments().getString("text");
            resType = "string";
            resId = getResources().getIdentifier(resName, resType, packageName);
            text_title.setText(resId);
            final String str = text_title.getText().toString();

            // 음절 학습의 경우 종료화면에서 학습한 세부 카테고리의 학습 명을 디스플레이해주기 위해
            // 전역변수에 study category 를 설정해준다.
            btn_img.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    m_gVar = (GlobalVariable) getActivity().getApplicationContext();
                    m_gVar.setStudyCategory(str);
                    if(str.equals("조합 연습")){
                        Intent intent = new Intent(getActivity(), StudyCombinationActivity.class);
                        startActivity(intent);
                    } else {
                        Intent intent = new Intent(getActivity(), StudySyllableActivity.class);
                        intent.putExtra("type", getArguments().getString("type"));
                        intent.putExtra("category", str);
                        intent.putExtra("accuracy_sum", 0);
                        intent.putExtra("now", 0);
                        startActivity(intent);
                    }
                }
            });
        } else {
            btn_img.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(getActivity(), StudyActivity.class);
                    intent.putExtra("type", getArguments().getString("type"));
                    intent.putExtra("category", getArguments().getString("image"));
                    intent.putExtra("accuracy_sum", 0);
                    intent.putExtra("now", 0);
                    startActivity(intent);
                }
            });
        }

        return v;
    }

    public static StudyInitFragment newInstance(String image, String text, String studyType) {

        StudyInitFragment f = new StudyInitFragment();
        Bundle b = new Bundle();
        b.putString("image", image);
        b.putString("text", text);
        b.putString("type", studyType);
        f.setArguments(b);

        return f;
    }
}