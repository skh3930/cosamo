package com.example.solugate.icanspeak;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.aigestudio.wheelpicker.WheelPicker;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Created by solugate on 2016-08-10.
 */
public class StudyCombinationActivity extends Activity implements View.OnClickListener {

    private char characterValue;
    private Button btn_close, btn_study;
    private TextViewPlus syllableCombination;
    private WheelPicker wheel_first, wheel_middle, wheel_last;      // 음절 조합 wheel picker
    private ArrayList<String> mFirstList, mMiddleList, mLastList;   // array.xml 에 있는 초성, 중성, 종성 리스트
    private int firstPosition, middlePosition, lastPosition;        // 초성, 종성, 중성의 index

    // ㄱ ㄲ ㄴ ㄷ ㄸ ㄹ ㅁ ㅂ ㅃ ㅅ ㅆ ㅇ ㅈ ㅉ ㅊ ㅋ ㅌ ㅍ ㅎ
    private static final char[] CHO =
            {0x3131, 0x3132, 0x3134, 0x3137, 0x3138, 0x3139, 0x3141,
                    0x3142, 0x3143, 0x3145, 0x3146, 0x3147, 0x3148,
                    0x3149, 0x314a, 0x314b, 0x314c, 0x314d, 0x314e};

    //ㅏㅐㅑㅒㅓㅔㅕㅖ ㅗ ㅘ ㅙ ㅚ ㅛ ㅜ ㅝ ㅞ ㅟ ㅠ ㅡ ㅢ ㅣ
    private static final char[] JUN =
            {0x314f, 0x3150, 0x3151, 0x3152, 0x3153, 0x3154, 0x3155,
                    0x3156, 0x3157, 0x3158, 0x3159, 0x315a, 0x315b,
                    0x315c, 0x315d, 0x315e, 0x315f, 0x3160, 0x3161,
                    0x3162, 0x3163};

    // ㄱㄲㄳㄴㄵㄶㄷㄹㄺ ㄻ ㄼ ㄽ ㄾ ㄿ ㅀ ㅁ ㅂ ㅄ ㅅ ㅆ ㅇ ㅈ ㅊ ㅋ ㅌ ㅍ ㅎ
    private static final char[] JON =
            {0x0000, 0x3131, 0x3132, 0x3133, 0x3134, 0x3135, 0x3136,
                    0x3137, 0x3139, 0x313a, 0x313b, 0x313c, 0x313d,
                    0x313e, 0x313f, 0x3140, 0x3141, 0x3142, 0x3144,
                    0x3145, 0x3146, 0x3147, 0x3148, 0x314a, 0x314b,
                    0x314c, 0x314d, 0x314e};

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_study_combination);

        // 초성 중성 종성 위치 초기화
        firstPosition = middlePosition = lastPosition = 0;

        // 나가기 버튼
        btn_close = (Button) findViewById(R.id.btn_close);
        btn_close.setOnClickListener(this);

        // 학습하기 버튼
        btn_study = (Button) findViewById(R.id.btn_study);
        btn_study.setOnClickListener(this);

        // 조합된 음절
        syllableCombination = (TextViewPlus) findViewById(R.id.syllable_combination);

        /**
         * 초성 wheel view 설정
         */
        wheel_first = (WheelPicker) findViewById(R.id.first);

        mFirstList = new ArrayList<String>(Arrays.asList
                (getResources().getStringArray(R.array.first_array)));

        wheel_first.setData(mFirstList);
        wheel_first.setVisibleItemCount(5);
        wheel_first.setSelectedItemTextColor(Color.parseColor("#7F7F7F"));
        wheel_first.setItemTextColor(Color.parseColor("#BDBDBD"));
        wheel_first.setBackgroundResource(R.drawable.round_login);
        wheel_first.setCurved(true);

        /**
         * 중성 wheel view 설정
         */
        wheel_middle = (WheelPicker) findViewById(R.id.middle);

        mMiddleList = new ArrayList<String>(Arrays.asList
                (getResources().getStringArray(R.array.middle_1)));

        wheel_middle.setData(mMiddleList);
        wheel_middle.setVisibleItemCount(5);
        wheel_middle.setSelectedItemTextColor(Color.parseColor("#7F7F7F"));
        wheel_middle.setItemTextColor(Color.parseColor("#BDBDBD"));
        wheel_middle.setBackgroundResource(R.drawable.round_login);
        wheel_middle.setCurved(true);

        /**
         * 종성 wheel view 설정
         */
        wheel_last = (WheelPicker) findViewById(R.id.last);

        mLastList = new ArrayList<String>(Arrays.asList
                (getResources().getStringArray(R.array.last_1_1)));

        wheel_last.setData(mLastList);
        wheel_last.setVisibleItemCount(5);
        wheel_last.setSelectedItemTextColor(Color.parseColor("#7F7F7F"));
        wheel_last.setItemTextColor(Color.parseColor("#BDBDBD"));
        wheel_last.setBackgroundResource(R.drawable.round_login);
        wheel_last.setCurved(true);

        // 초성 wheel picker 리스너
        wheel_first.setOnItemSelectedListener(new WheelPicker.OnItemSelectedListener() {
            @Override
            public void onItemSelected(WheelPicker wheelPicker, Object o, int position) {

                firstPosition = position;   // 초성 리스트에서 선택된 위치

                // 선택된 초성에 맞는 중성 string array 가져오기
                String resName = "middle_" + (position + 1);
                String resType = "array";
                String packageName = getPackageName();
                int resId = getResources().getIdentifier(resName, resType, packageName);

                mMiddleList = new ArrayList<String>(Arrays.asList(getResources().getStringArray(resId)));
                wheel_middle.setData(mMiddleList);

                setSyllableCombination();
            }
        });

        // 중성 wheel picker 리스너
        wheel_middle.setOnItemSelectedListener(new WheelPicker.OnItemSelectedListener() {
            @Override
            public void onItemSelected(WheelPicker wheelPicker, Object o, int position) {

                middlePosition = position;  // 중성 리스트에서 선택된 위치

                // 초성과 중성에 맞는 종성 string array 가져오기
                String resName = "last_" + (firstPosition + 1) + "_" + (middlePosition + 1);
                String resType = "array";
                String packageName = getPackageName();
                int resId = getResources().getIdentifier(resName, resType, packageName);

                mLastList = new ArrayList<String>(Arrays.asList(getResources().getStringArray(resId)));
                wheel_last.setData(mLastList);

                setSyllableCombination();
            }
        });

        // 종성 wheel picker 리스너
        wheel_last.setOnItemSelectedListener(new WheelPicker.OnItemSelectedListener() {
            @Override
            public void onItemSelected(WheelPicker wheelPicker, Object o, int position) {

                lastPosition = position;  // 종성 리스트에서 선택된 위치

                setSyllableCombination();
            }
        });
    }

    // 사용자가 선택한 초성, 중성, 종성 조합
    public void setSyllableCombination() {

        if (mFirstList.toArray().length < firstPosition)
            firstPosition = 0;
        else if (mMiddleList.toArray().length < middlePosition)
            middlePosition = 0;
        else if (mLastList.toArray().length < lastPosition)
            lastPosition = 0;

        mFirstList.get(firstPosition);
        mMiddleList.get(middlePosition);
        mLastList.get(lastPosition);

        char first = ((mFirstList.get(firstPosition)).charAt(0));
        char middle = ((mMiddleList.get(middlePosition)).charAt(0));
        char last = ((mLastList.get(lastPosition)).charAt(0));


        int first_index = new String(CHO).indexOf(first);
        int middle_index = new String(JUN).indexOf(middle);
        int last_index = new String(JON).indexOf(last);

        if((mLastList.get(lastPosition)).equals("-"))
            last_index = 0;

        characterValue = (char) ((((first_index * 21) + middle_index) * 28 + last_index) + 0xAC00);

        Log.i("TAG", "한글 조합 : " + characterValue);
        Log.i("TAG", "초성 : " + first);
        Log.i("TAG", "중성 : " + middle);
        Log.i("TAG", "종성 : " + last);

        syllableCombination.setText(characterValue + "");
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_close:
                onBackPressed();
                break;

            case R.id.btn_study:
                Intent intent = new Intent(this, StudySyllableActivity.class);
                startActivity(intent);
                finish();
                break;
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}