package com.example.solugate.icanspeak;

import android.content.Intent;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by solugate on 2016-07-22.
 * 사용자 음성 테스트 액티비티
 */
public class SoundTestActivity extends AppCompatActivity implements View.OnClickListener {

    private AudioReader audioReader;
    private Button btn_back, btn_check;         // 액션 바 버튼
    private Button btn_tab1, btn_tab2, btn_tab3;// 탭 버튼

    private ImageView actionBarTitle;       // 현재 화면 타이틀
    private TextView txtVoice;              // 음성인식 상태 텍스트
    private TextView txtRestartTip;
    private ImageView image_mic, image_study_background;

    private Thread mThread = null;           // 화면 UI 변경 스레드
    private boolean thread_run = false;

    private int sampleRate = 8000;
    private int inputBlockSize = 256;
    private int sampleDecimate = 1;

    private int decibel, cnt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sound_test);

        setCustomActionbar();   // 커스텀 액션 바 적용
        setCustomTab();     // 커스텀 탭 적용

        decibel = -50;
        cnt = 0;

        txtVoice = (TextView) findViewById(R.id.status);
        txtRestartTip = (TextView) findViewById(R.id.restart_tip);
        image_study_background = (ImageView) findViewById(R.id.ImageView01);
        image_mic = (ImageView) findViewById(R.id.ImageView02);
        image_mic.setOnClickListener(this);

        // 화면 변경 스레드
        mThread = new MyThread();
        mThread.start();
        thread_run = true;

        // 사용자 음성 받아오기
        audioReader = new AudioReader();
        setVolumeControlStream(AudioManager.STREAM_MUSIC);
        doStart();
    }

    class MyThread extends Thread {
        @Override
        public void run() {
            boolean isStop = false;
            int decibel_cnt = 0;    // count 값 초기화

            while (true) {

                System.out.println("max_decibel:" + decibel + " cnt: " + cnt);

                ++cnt;

                Message msg = mHandler.obtainMessage();

                if (0 > decibel && decibel >= -7) {
                    msg.obj = Integer.toString(7);
                } else if (-7 > decibel && decibel >= -9) {
                    msg.obj = Integer.toString(6);
                } else if (-9 > decibel && decibel >= -11) {
                    msg.obj = Integer.toString(5);
                } else if(-11 > decibel && decibel >= -15) {
                    msg.obj = Integer.toString(4);
                } else if (-15 > decibel && decibel >= -23) {
                    msg.obj = Integer.toString(3);
                } else if (-23 > decibel && decibel >= -30) {
                    msg.obj = Integer.toString(2);
                } else {
                    msg.obj = Integer.toString(1);
                }


                if (decibel >= -7) {  //계속 일정 횟수 큰소리가 나면 종료
                    if (++decibel_cnt > 3) {
                        msg.obj = "success";
                        isStop = true;
                    }
                } else if (cnt > 100) { //일정 시간이 성공하지 못하면 종료
                    msg.obj = "fail";
                    isStop = true;
                } else {
                    System.out.println("ing!");
                }

                mHandler.sendMessage(msg);

                if (isStop) {
                    //다시 쓰레드를 시작할때를 대비하여 초기화
                    isStop = false;
                    decibel_cnt = 0;
                    decibel = -50;
                    thread_run = false;
                    cnt = 0;

                    try {
                        synchronized (mThread) {
                            mThread.wait();
                        }
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

                try {
                    Thread.sleep(50);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }


    // UI 변경 핸들러
    private final Handler mHandler = new Handler() {    //핸들러를 통해 UI스레드에 접근
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if (msg.obj.equals("1")) {
                image_mic.setImageResource(R.drawable.study_mic1);
            } else if (msg.obj.equals("2")) {
                image_mic.setImageResource(R.drawable.study_mic2);
            } else if (msg.obj.equals("3")) {
                image_mic.setImageResource(R.drawable.study_mic3);
            } else if (msg.obj.equals("4")) {
                image_mic.setImageResource(R.drawable.study_mic4);
            } else if (msg.obj.equals("5")) {
                image_mic.setImageResource(R.drawable.study_mic5);
            } else if (msg.obj.equals("6")) {
                image_mic.setImageResource(R.drawable.study_mic6);
            } else if (msg.obj.equals("7")) {
                image_mic.setImageResource(R.drawable.study_mic7);
            }else if (msg.obj.equals("fail")) {
                //실패했을 때 UI로 변경
                image_study_background.setImageResource(R.drawable.study_background_fail);
                image_mic.setImageResource(R.drawable.study_mic1);
                txtRestartTip.setVisibility(View.VISIBLE);
                txtVoice.setText("음성 인식 실패");
            } else if (msg.obj.equals("success")) {
                //성공했을 때 UI로 변경
                image_study_background.setImageResource(R.drawable.study_background_success);
                image_mic.setImageResource(R.drawable.study_mic1);
                txtRestartTip.setVisibility(View.VISIBLE);
                txtVoice.setText("음성 인식 성공");
            }
        }
    };

    public void doStart() {
        audioReader.startReader(sampleRate, inputBlockSize * sampleDecimate, new AudioReader.Listener() {
            @Override
            public final void onReadComplete(int dB) {
                decibel = dB;
            }

            @Override
            public int onReadError(int error) {
                return 0;
            }
        });
    }

    public void doStop() {
        audioReader.stopReader();
    }

    public void threadStop() {
        doStop();
        synchronized (this) {
            mThread.interrupt();
        }
    }

    // 커스텀 액션 바
    private void setCustomActionbar() {
        ActionBar actionBar = getSupportActionBar();

        // Custom Action bar를 사용하기 위한 설정
        actionBar.setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        actionBar.setDisplayShowCustomEnabled(true);
        actionBar.setCustomView(R.layout.layout_actionbar);
        //    actionBar.setDisplayHomeAsUpEnabled(false);
        //   actionBar.setDisplayShowTitleEnabled(false);

        // Set Custom view layout
        View mCustomView = getSupportActionBar().getCustomView();

        // 액션바 뒤로가기 버튼
        btn_back = (Button) findViewById(R.id.btn_back);
        btn_back.setOnClickListener(this);

        // 액션 바 타이틀
        actionBarTitle = (ImageView) findViewById(R.id.actionbar_title);
        actionBarTitle.setImageResource(R.drawable.actionbar_sound_test);
        actionBarTitle.setVisibility(View.VISIBLE);

        // 액션바 확인 버튼 비활성화
        btn_check = (Button) findViewById(R.id.btn_check);
        btn_check.setVisibility(View.INVISIBLE);

        // set action bar layout layoutparams
        ActionBar.LayoutParams params = new ActionBar.LayoutParams(ActionBar.LayoutParams.MATCH_PARENT, ActionBar.LayoutParams.MATCH_PARENT);
        actionBar.setCustomView(mCustomView, params);

        Toolbar parent = (Toolbar) mCustomView.getParent();
        parent.setContentInsetsAbsolute(0, 0);

    }

    // 하단 탭 설정
    private void setCustomTab() {
        btn_tab1 = (Button) findViewById(R.id.tab_01);
        btn_tab1.setOnClickListener(this);

        btn_tab2 = (Button) findViewById(R.id.tab_02);
        btn_tab2.setOnClickListener(this);

        btn_tab3 = (Button) findViewById(R.id.tab_03);
        btn_tab3.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_back:
                onBackPressed();
                break;

            case R.id.tab_01:
                Intent intent1 = new Intent(this, StudyMainActivity.class);
                startActivity(intent1);
                threadStop();
                finish();
                break;

            case R.id.tab_02:
                Intent intent2 = new Intent(this, StatusMainActivity.class);
                startActivity(intent2);
                threadStop();
                finish();
                break;

            case R.id.tab_03:
                Intent intent3 = new Intent(this, MyPageMainActivity.class);
                startActivity(intent3);
                threadStop();
                finish();
                break;
            case R.id.ImageView02:
                //음성인식 상태의 ui로 변경
                image_study_background.setImageResource(R.drawable.study_background);
                image_mic.setImageResource(R.drawable.study_mic1);
                txtRestartTip.setVisibility(View.INVISIBLE);
                txtVoice.setText("음성 인식 중");

                //쓰레드 재시작
                synchronized (mThread) {
                    if (!thread_run) {
                        mThread.notify();
                    }
                }
                break;
        }
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}